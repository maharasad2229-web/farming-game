import React, { useRef, useState, useEffect } from 'react';
import {
  Tractor,
  Volume2,
  Wrench,
  Zap,
  ArrowLeft,
  ArrowRight,
  Hand,
  RotateCcw,
  Sparkles,
  UserCheck
} from 'lucide-react';

interface TouchControlsProps {
  inVehicle: boolean;
  implementLowered?: boolean;
  onJoystickMove: (x: number, y: number) => void;
  onJoystickEnd: () => void;
  onCameraRotate?: (deltaX: number, deltaY: number) => void;
  onResetCamera?: () => void;
  onToggleVehicle: () => void;
  onTriggerAction: () => void;
  onToggleImplement: () => void;
  onHonkHorn: () => void;
  onThrottle?: (active: boolean) => void;
  onBrake?: (active: boolean) => void;
  onSteerLeft?: (active: boolean) => void;
  onSteerRight?: (active: boolean) => void;
  onHandbrake?: (active: boolean) => void;
  onSprint?: (active: boolean) => void;
}

export const TouchControls: React.FC<TouchControlsProps> = ({
  inVehicle,
  implementLowered = false,
  onJoystickMove,
  onJoystickEnd,
  onCameraRotate,
  onResetCamera,
  onToggleVehicle,
  onTriggerAction,
  onToggleImplement,
  onHonkHorn,
  onThrottle,
  onBrake,
  onSteerLeft,
  onSteerRight,
  onHandbrake,
  onSprint
}) => {
  const joystickBaseRef = useRef<HTMLDivElement>(null);
  const [knobPos, setKnobPos] = useState({ x: 0, y: 0 });
  const [isJoystickActive, setIsJoystickActive] = useState(false);
  const [controlMode, setControlMode] = useState<'joystick' | 'pedals'>('pedals');
  const [isHandbrakeActive, setIsHandbrakeActive] = useState(false);
  const [isSprintActive, setIsSprintActive] = useState(false);

  // Camera Drag State
  const cameraTouchRef = useRef<{ id: number; lastX: number; lastY: number } | null>(null);

  // --- VIRTUAL JOYSTICK (POINTER EVENTS) ---
  const handleJoystickPointerDown = (e: React.PointerEvent) => {
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
    setIsJoystickActive(true);
    updateJoystickFromPointer(e.clientX, e.clientY);
  };

  const handleJoystickPointerMove = (e: React.PointerEvent) => {
    if (!isJoystickActive) return;
    updateJoystickFromPointer(e.clientX, e.clientY);
  };

  const handleJoystickPointerUp = (e: React.PointerEvent) => {
    try {
      (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
    } catch {
      // Ignored
    }
    setIsJoystickActive(false);
    setKnobPos({ x: 0, y: 0 });
    onJoystickEnd();
  };

  const updateJoystickFromPointer = (clientX: number, clientY: number) => {
    if (!joystickBaseRef.current) return;
    const rect = joystickBaseRef.current.getBoundingClientRect();
    const centerX = rect.left + rect.width / 2;
    const centerY = rect.top + rect.height / 2;

    const dx = clientX - centerX;
    const dy = clientY - centerY;
    const dist = Math.sqrt(dx * dx + dy * dy);
    const maxRadius = rect.width / 2;

    const clampedDist = Math.min(dist, maxRadius);
    const angle = Math.atan2(dy, dx);

    const x = Math.cos(angle) * clampedDist;
    const y = Math.sin(angle) * clampedDist;

    setKnobPos({ x, y });

    // Normalized -1 to 1
    const normX = x / maxRadius;
    const normY = y / maxRadius;
    onJoystickMove(normX, normY);
  };

  // --- CAMERA DRAG POINTER EVENTS ---
  const handleCameraPointerDown = (e: React.PointerEvent) => {
    if (cameraTouchRef.current) return;
    cameraTouchRef.current = { id: e.pointerId, lastX: e.clientX, lastY: e.clientY };
    (e.target as HTMLElement).setPointerCapture?.(e.pointerId);
  };

  const handleCameraPointerMove = (e: React.PointerEvent) => {
    if (!cameraTouchRef.current || cameraTouchRef.current.id !== e.pointerId) return;
    const deltaX = e.clientX - cameraTouchRef.current.lastX;
    const deltaY = e.clientY - cameraTouchRef.current.lastY;
    cameraTouchRef.current.lastX = e.clientX;
    cameraTouchRef.current.lastY = e.clientY;
    onCameraRotate?.(deltaX, deltaY);
  };

  const handleCameraPointerUp = (e: React.PointerEvent) => {
    if (cameraTouchRef.current && cameraTouchRef.current.id === e.pointerId) {
      cameraTouchRef.current = null;
      try {
        (e.target as HTMLElement).releasePointerCapture?.(e.pointerId);
      } catch {
        // Ignored
      }
    }
  };

  return (
    <div className="pointer-events-none fixed inset-0 z-20 select-none overflow-hidden touch-none">
      {/* 1. Camera Touch Swivel Zone (Center-top screen drag for 360 degree viewing) */}
      <div
        onPointerDown={handleCameraPointerDown}
        onPointerMove={handleCameraPointerMove}
        onPointerUp={handleCameraPointerUp}
        onPointerCancel={handleCameraPointerUp}
        className="pointer-events-auto absolute inset-x-0 top-16 bottom-56 flex items-start justify-center"
      >
        <div className="mt-2 rounded-full border border-stone-700/30 bg-stone-900/40 px-3 py-1 text-[11px] font-medium text-stone-300 backdrop-blur-sm shadow-sm pointer-events-none opacity-60">
          Touch & Drag to rotate camera 360° | کیمرہ گھمانے کے لیے اسکرین پر سوائپ کریں
        </div>
      </div>

      {/* 2. Controls Mode & Reset Camera Bar (Above touch panels) */}
      <div className="pointer-events-auto absolute bottom-52 inset-x-4 flex justify-between items-center text-xs">
        {/* Switch Steering Style */}
        <div className="flex items-center gap-1 rounded-xl border border-stone-700/60 bg-stone-900/80 p-1 backdrop-blur-md shadow-lg">
          <button
            type="button"
            onClick={() => setControlMode('pedals')}
            className={`rounded-lg px-2.5 py-1 font-bold transition-all ${
              controlMode === 'pedals'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            {inVehicle ? 'ریس/بریک (Pedals)' : 'بٹن (Buttons)'}
          </button>
          <button
            type="button"
            onClick={() => setControlMode('joystick')}
            className={`rounded-lg px-2.5 py-1 font-bold transition-all ${
              controlMode === 'joystick'
                ? 'bg-emerald-600 text-white shadow-sm'
                : 'text-stone-300 hover:text-white'
            }`}
          >
            جوائسٹک (Joystick)
          </button>
        </div>

        {/* Reset Camera Orbit */}
        {onResetCamera && (
          <button
            type="button"
            onClick={onResetCamera}
            className="flex items-center gap-1 rounded-xl border border-stone-700/60 bg-stone-900/80 px-2.5 py-1.5 font-semibold text-stone-200 backdrop-blur-md hover:bg-stone-800 active:scale-95 shadow-md"
            title="Reset Camera View"
          >
            <RotateCcw className="h-3.5 w-3.5 text-amber-400" />
            <span className="text-[11px]">کیمرہ ری سیٹ</span>
          </button>
        )}
      </div>

      {/* 3. Bottom Controls Row */}
      <div className="pointer-events-none absolute inset-x-0 bottom-2 flex h-48 justify-between px-3 md:px-6">
        {/* --- LEFT CLUSTER: STEERING / JOYSTICK --- */}
        <div className="pointer-events-auto flex items-end gap-2 pb-1">
          {controlMode === 'joystick' ? (
            /* Virtual Analog Joystick */
            <div
              ref={joystickBaseRef}
              onPointerDown={handleJoystickPointerDown}
              onPointerMove={handleJoystickPointerMove}
              onPointerUp={handleJoystickPointerUp}
              onPointerCancel={handleJoystickPointerUp}
              className="relative flex h-36 w-36 items-center justify-center rounded-full border-2 border-emerald-500/50 bg-stone-950/75 shadow-2xl backdrop-blur-md touch-none"
            >
              {/* Directional Guides */}
              <div className="absolute top-2 text-[10px] font-bold text-stone-400">▲ آگے</div>
              <div className="absolute bottom-2 text-[10px] font-bold text-stone-400">▼ پیچھے</div>
              <div className="absolute left-2 text-[10px] font-bold text-stone-400">◀ بائیں</div>
              <div className="absolute right-2 text-[10px] font-bold text-stone-400">دائیں ▶</div>

              {/* Thumb Knob */}
              <div
                className="flex h-16 w-16 items-center justify-center rounded-full border-2 border-emerald-300 bg-gradient-to-br from-emerald-500 to-emerald-700 shadow-xl transition-transform duration-75"
                style={{
                  transform: `translate(${knobPos.x}px, ${knobPos.y}px)`
                }}
              >
                <div className="h-6 w-6 rounded-full bg-emerald-200/40" />
              </div>
            </div>
          ) : (
            /* Direct Steering / Movement Buttons */
            <div className="flex flex-col gap-2">
              {/* Steer Left & Right Buttons */}
              <div className="flex gap-2">
                <button
                  type="button"
                  onPointerDown={() => onSteerLeft?.(true)}
                  onPointerUp={() => onSteerLeft?.(false)}
                  onPointerCancel={() => onSteerLeft?.(false)}
                  className="flex h-16 w-18 flex-col items-center justify-center rounded-2xl border-2 border-stone-600 bg-stone-900/90 text-white shadow-xl active:bg-amber-600 active:border-amber-400 active:scale-95 transition-all touch-none"
                >
                  <ArrowLeft className="h-6 w-6 text-amber-400" />
                  <span className="text-[10px] font-bold mt-0.5">بائیں (A)</span>
                </button>

                <button
                  type="button"
                  onPointerDown={() => onSteerRight?.(true)}
                  onPointerUp={() => onSteerRight?.(false)}
                  onPointerCancel={() => onSteerRight?.(false)}
                  className="flex h-16 w-18 flex-col items-center justify-center rounded-2xl border-2 border-stone-600 bg-stone-900/90 text-white shadow-xl active:bg-amber-600 active:border-amber-400 active:scale-95 transition-all touch-none"
                >
                  <ArrowRight className="h-6 w-6 text-amber-400" />
                  <span className="text-[10px] font-bold mt-0.5">دائیں (D)</span>
                </button>
              </div>

              {/* Walking sprint or horn */}
              {!inVehicle && onSprint && (
                <button
                  type="button"
                  onPointerDown={() => {
                    setIsSprintActive(true);
                    onSprint(true);
                  }}
                  onPointerUp={() => {
                    setIsSprintActive(false);
                    onSprint(false);
                  }}
                  onPointerCancel={() => {
                    setIsSprintActive(false);
                    onSprint(false);
                  }}
                  className={`flex h-12 w-full items-center justify-center gap-1.5 rounded-xl border font-bold transition-all active:scale-95 shadow-lg ${
                    isSprintActive
                      ? 'border-yellow-400 bg-yellow-600 text-stone-950'
                      : 'border-stone-600 bg-stone-900/90 text-yellow-400'
                  }`}
                >
                  <Zap className="h-4 w-4" />
                  <span className="text-xs">دوڑیں / Sprint</span>
                </button>
              )}
            </div>
          )}
        </div>

        {/* --- RIGHT CLUSTER: REALISTIC PEDALS & ACTION BUTTONS --- */}
        <div className="pointer-events-auto flex items-end gap-2 pb-1">
          {inVehicle ? (
            /* Vehicle Driving Pedals */
            <div className="flex items-end gap-2">
              {/* Auxiliary driving controls (Horn, Implement, Handbrake) */}
              <div className="flex flex-col gap-1.5 pb-1">
                {/* Horn */}
                <button
                  type="button"
                  onClick={onHonkHorn}
                  className="flex h-11 w-11 items-center justify-center rounded-xl border border-stone-600 bg-stone-900/90 text-amber-400 shadow-md active:scale-95 active:bg-stone-800"
                  title="Horn / ہارن (H)"
                >
                  <Volume2 className="h-5 w-5" />
                </button>

                {/* Hitch Implement Up/Down */}
                <button
                  type="button"
                  onClick={onToggleImplement}
                  className={`flex h-11 w-11 items-center justify-center rounded-xl border shadow-md active:scale-95 transition-all ${
                    implementLowered
                      ? 'border-emerald-400 bg-emerald-700 text-white'
                      : 'border-stone-600 bg-stone-900/90 text-stone-300'
                  }`}
                  title="Lower / Raise Implement / ہل اوپر یا نیچے (V)"
                >
                  <Wrench className="h-5 w-5" />
                </button>

                {/* Handbrake */}
                <button
                  type="button"
                  onClick={() => {
                    const next = !isHandbrakeActive;
                    setIsHandbrakeActive(next);
                    onHandbrake?.(next);
                  }}
                  className={`flex h-11 w-11 items-center justify-center rounded-xl border shadow-md active:scale-95 transition-all ${
                    isHandbrakeActive
                      ? 'border-red-500 bg-red-800 text-white'
                      : 'border-stone-600 bg-stone-900/90 text-stone-300'
                  }`}
                  title="Handbrake / ہینڈ بریک (Space)"
                >
                  <Hand className="h-5 w-5" />
                </button>

                {/* Exit Tractor */}
                <button
                  type="button"
                  onClick={onToggleVehicle}
                  className="flex h-11 w-11 items-center justify-center rounded-xl border border-amber-500/60 bg-amber-600 text-white shadow-md active:scale-95 hover:bg-amber-500"
                  title="Exit Tractor / اتریں (E)"
                >
                  <Tractor className="h-5 w-5" />
                </button>
              </div>

              {/* Large Foot Brake Pedal (Red) */}
              <button
                type="button"
                onPointerDown={() => onBrake?.(true)}
                onPointerUp={() => onBrake?.(false)}
                onPointerCancel={() => onBrake?.(false)}
                className="flex h-32 w-16 flex-col items-center justify-between rounded-2xl border-2 border-red-500/70 bg-gradient-to-t from-red-900 to-red-800 p-2 text-white shadow-2xl active:from-red-700 active:to-red-600 active:scale-95 transition-all touch-none"
              >
                <div className="h-1.5 w-8 rounded-full bg-red-400/60" />
                <div className="flex flex-col items-center">
                  <span className="text-sm font-black tracking-wider">بریک</span>
                  <span className="text-[10px] font-bold text-red-200">BRAKE</span>
                  <span className="text-[9px] text-red-300">(S)</span>
                </div>
                <div className="h-1.5 w-8 rounded-full bg-red-400/60" />
              </button>

              {/* Large Accelerator Pedal (Green) */}
              <button
                type="button"
                onPointerDown={() => onThrottle?.(true)}
                onPointerUp={() => onThrottle?.(false)}
                onPointerCancel={() => onThrottle?.(false)}
                className="flex h-36 w-20 flex-col items-center justify-between rounded-2xl border-2 border-emerald-400/80 bg-gradient-to-t from-emerald-800 to-emerald-600 p-2.5 text-white shadow-2xl active:from-emerald-600 active:to-emerald-500 active:scale-95 transition-all touch-none"
              >
                <div className="h-2 w-10 rounded-full bg-emerald-300/60" />
                <div className="flex flex-col items-center">
                  <span className="text-base font-black tracking-wider">ریس</span>
                  <span className="text-[11px] font-bold text-emerald-100">GAS / RACE</span>
                  <span className="text-[10px] text-emerald-200">(W)</span>
                </div>
                <div className="h-2 w-10 rounded-full bg-emerald-300/60" />
              </button>
            </div>
          ) : (
            /* Farmer Walking Buttons */
            <div className="flex flex-col items-end gap-2.5">
              {/* Context Action Button (F - کام کریں) */}
              <button
                type="button"
                onClick={onTriggerAction}
                className="flex h-16 w-32 items-center justify-center gap-2 rounded-2xl border-2 border-emerald-400 bg-gradient-to-r from-emerald-700 to-emerald-600 px-3 text-white shadow-2xl active:scale-95 hover:from-emerald-600 hover:to-emerald-500 transition-all font-bold"
              >
                <Sparkles className="h-5 w-5 text-emerald-200" />
                <div className="flex flex-col items-start leading-tight">
                  <span className="text-xs font-black">کام کریں (F)</span>
                  <span className="text-[10px] text-emerald-100">Interact</span>
                </div>
              </button>

              {/* Drive Tractor Button (E - ٹریکٹر چلائیں) */}
              <button
                type="button"
                onClick={onToggleVehicle}
                className="flex h-16 w-32 items-center justify-center gap-2 rounded-2xl border-2 border-amber-400 bg-gradient-to-r from-amber-600 to-amber-700 px-3 text-white shadow-2xl active:scale-95 hover:from-amber-500 hover:to-amber-600 transition-all font-bold"
              >
                <Tractor className="h-6 w-6 text-amber-200" />
                <div className="flex flex-col items-start leading-tight">
                  <span className="text-xs font-black">ٹریکٹر (E)</span>
                  <span className="text-[10px] text-amber-100">Drive MF</span>
                </div>
              </button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
