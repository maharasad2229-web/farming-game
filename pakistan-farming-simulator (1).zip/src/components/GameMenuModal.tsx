import React, { useState } from 'react';
import {
  X,
  Tractor,
  MapPin,
  Coins,
  Sparkles,
  ShoppingBag,
  Wrench,
  Droplets,
  Sprout,
  CheckCircle2,
  TrendingUp,
  TrendingDown,
  Volume2,
  Sun,
  CloudRain,
  Save,
  HelpCircle,
  Milk,
  Egg,
  ShieldCheck,
  Building,
  RotateCcw
} from 'lucide-react';
import {
  CropType,
  FieldData,
  ImplementType,
  MachineryItem,
  AnimalPen,
  Mission,
  PlayerStats,
  WeatherType
} from '../types';
import { CROPS_DATA, TRACTOR_UPGRADES } from '../game/constants';
import { sound } from '../audio/SoundEngine';

interface GameMenuModalProps {
  isOpen: boolean;
  onClose: () => void;
  stats: PlayerStats;
  fields: FieldData[];
  machinery: MachineryItem[];
  currentImplement: ImplementType;
  selectedCrop: CropType;
  animals: AnimalPen[];
  missions: Mission[];
  tractorUpgradeLevel: number;
  onSelectCrop: (crop: CropType) => void;
  onHitchImplement: (implement: ImplementType) => void;
  onBuyMachinery: (item: MachineryItem) => void;
  onUnlockField: (field: FieldData) => void;
  onUpgradeTractor: (level: number) => void;
  onFeedAnimals: (animalId: string) => void;
  onCollectAnimalProduct: (animalId: string) => void;
  onBuyAnimal: (animalId: string) => void;
  onClaimMissionReward: (missionId: string) => void;
  onSetWeather: (weather: WeatherType) => void;
  onSaveGame: () => void;
  onResetGame: () => void;
}

export const GameMenuModal: React.FC<GameMenuModalProps> = ({
  isOpen,
  onClose,
  stats,
  fields,
  machinery,
  currentImplement,
  selectedCrop,
  animals,
  missions,
  tractorUpgradeLevel,
  onSelectCrop,
  onHitchImplement,
  onBuyMachinery,
  onUnlockField,
  onUpgradeTractor,
  onFeedAnimals,
  onCollectAnimalProduct,
  onBuyAnimal,
  onClaimMissionReward,
  onSetWeather,
  onSaveGame,
  onResetGame
}) => {
  const [activeTab, setActiveTab] = useState<
    'fields' | 'machinery' | 'tractor' | 'market' | 'animals' | 'missions' | 'map' | 'settings'
  >('fields');

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/80 p-2 sm:p-4 backdrop-blur-md">
      <div className="flex h-[92vh] w-full max-w-5xl flex-col overflow-hidden rounded-2xl border border-stone-700 bg-stone-900 shadow-2xl">
        {/* Header */}
        <div className="flex items-center justify-between border-b border-stone-800 bg-stone-950 px-4 py-3 sm:px-6">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 font-black text-white shadow-md">
              <Tractor className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-lg font-black text-white tracking-tight">
                Pakistan Farming Simulator
              </h2>
              <p className="text-xs text-stone-400">
                Punjab & Sindh Zamindari Management Console
              </p>
            </div>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 rounded-xl bg-stone-900 px-3 py-1.5 border border-emerald-500/30">
              <Coins className="h-4 w-4 text-emerald-400" />
              <span className="text-sm font-bold text-white">
                Rs. {stats.money.toLocaleString()}
              </span>
            </div>
            <button
              onClick={onClose}
              className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-800 hover:text-white"
            >
              <X className="h-6 w-6" />
            </button>
          </div>
        </div>

        {/* Tab Navigation */}
        <div className="flex overflow-x-auto border-b border-stone-800 bg-stone-950/60 px-4 scrollbar-none">
          {[
            { id: 'fields', label: 'Fields & Crops', icon: Sprout },
            { id: 'machinery', label: 'Machinery & Tools', icon: Wrench },
            { id: 'tractor', label: 'Tractor Garage', icon: Tractor },
            { id: 'market', label: 'Village Mandi', icon: TrendingUp },
            { id: 'animals', label: 'Livestock Haveli', icon: Milk },
            { id: 'missions', label: 'Missions', icon: CheckCircle2 },
            { id: 'map', label: 'Farm Map', icon: MapPin },
            { id: 'settings', label: 'Settings & Save', icon: Save }
          ].map((tab) => {
            const Icon = tab.icon;
            const isActive = activeTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => {
                  sound.playUIClick();
                  setActiveTab(tab.id as typeof activeTab);
                }}
                className={`flex items-center gap-2 border-b-2 px-4 py-3 text-xs sm:text-sm font-bold whitespace-nowrap transition-colors ${
                  isActive
                    ? 'border-emerald-500 text-emerald-400'
                    : 'border-transparent text-stone-400 hover:text-stone-200'
                }`}
              >
                <Icon className="h-4 w-4" />
                {tab.label}
              </button>
            );
          })}
        </div>

        {/* Tab Content */}
        <div className="flex-1 overflow-y-auto p-4 sm:p-6 bg-stone-900/40">
          {/* --- TAB 1: FIELDS & CROPS --- */}
          {activeTab === 'fields' && (
            <div className="space-y-6">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2">
                  <Sprout className="h-5 w-5 text-emerald-400" />
                  Crop Seed Selection (Active Seed for Drill)
                </h3>
                <p className="text-xs text-stone-400 mb-3">
                  Select which Pakistani crop seed to drill when operating the seed drill machine:
                </p>

                <div className="grid grid-cols-2 sm:grid-cols-5 gap-2.5">
                  {(Object.keys(CROPS_DATA) as CropType[]).map((cropKey) => {
                    const c = CROPS_DATA[cropKey];
                    const isSel = selectedCrop === cropKey;
                    return (
                      <button
                        key={cropKey}
                        onClick={() => {
                          sound.playUIClick();
                          onSelectCrop(cropKey);
                        }}
                        className={`flex flex-col items-start rounded-xl p-3 text-left transition-all border ${
                          isSel
                            ? 'border-emerald-500 bg-emerald-950/40 shadow-md ring-2 ring-emerald-500/50'
                            : 'border-stone-800 bg-stone-900 hover:bg-stone-800'
                        }`}
                      >
                        <div className="flex w-full items-center justify-between">
                          <span className="text-sm font-bold text-white">{c.name.split(' ')[0]}</span>
                          <span className="text-xs text-stone-400 font-urdu">{c.urduName}</span>
                        </div>
                        <div className="mt-1 text-[11px] text-emerald-400 font-semibold">
                          Rs. {c.baseMarketPricePer40Kg} / 40kg
                        </div>
                        <div className="text-[10px] text-stone-400 mt-0.5">
                          Growth: {c.growthTimeSeconds}s
                        </div>
                      </button>
                    );
                  })}
                </div>
              </div>

              {/* Farm Fields List */}
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-3">
                  <MapPin className="h-5 w-5 text-emerald-400" />
                  Your Agricultural Fields & Land Expansion
                </h3>

                <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
                  {fields.map((field) => (
                    <div
                      key={field.id}
                      className="rounded-xl border border-stone-800 bg-stone-900 p-4 shadow-md flex flex-col justify-between"
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <div className="font-bold text-white text-base">{field.name}</div>
                          <span className="rounded-full bg-stone-800 px-2 py-0.5 text-xs text-stone-300 font-semibold">
                            {field.acres} Acres
                          </span>
                        </div>

                        {field.unlocked ? (
                          <div className="mt-3 space-y-2 text-xs">
                            <div className="flex justify-between text-stone-300">
                              <span>Soil Preparation:</span>
                              <span className="font-bold capitalize text-amber-400">
                                {field.soilState.replace('_', ' ')}
                              </span>
                            </div>

                            <div className="flex justify-between text-stone-300">
                              <span>Planted Crop:</span>
                              <span className="font-bold text-emerald-400">
                                {field.plantedCrop ? CROPS_DATA[field.plantedCrop].name : 'None'}
                              </span>
                            </div>

                            <div>
                              <div className="flex justify-between text-stone-400 mb-1">
                                <span>Growth Maturity:</span>
                                <span className="font-bold text-white">{Math.round(field.growthProgress)}%</span>
                              </div>
                              <div className="h-2 w-full overflow-hidden rounded-full bg-stone-800">
                                <div
                                  className="h-full bg-amber-500 transition-all"
                                  style={{ width: `${field.growthProgress}%` }}
                                />
                              </div>
                            </div>

                            <div className="grid grid-cols-2 gap-2 pt-1 text-[11px]">
                              <div className="rounded bg-stone-800/80 p-1.5 text-center">
                                <span className="text-stone-400">Moisture:</span>{' '}
                                <span className="font-bold text-sky-400">{Math.round(field.moistureLevel)}%</span>
                              </div>
                              <div className="rounded bg-stone-800/80 p-1.5 text-center">
                                <span className="text-stone-400">Fertilizer:</span>{' '}
                                <span className="font-bold text-lime-400">{Math.round(field.fertilizerLevel)}%</span>
                              </div>
                            </div>
                          </div>
                        ) : (
                          <div className="mt-4 rounded-lg bg-stone-950/60 p-3 text-center">
                            <div className="text-xs text-stone-400 mb-2">
                              Unclaimed fertile land ready for purchase.
                            </div>
                            <button
                              disabled={stats.money < field.unlockCost}
                              onClick={() => onUnlockField(field)}
                              className="w-full rounded-xl bg-emerald-600 py-2 text-xs font-bold text-white transition-all hover:bg-emerald-500 disabled:opacity-50"
                            >
                              Buy Acreage for Rs. {field.unlockCost.toLocaleString()}
                            </button>
                          </div>
                        )}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* --- TAB 2: MACHINERY & IMPLEMENTS --- */}
          {activeTab === 'machinery' && (
            <div>
              <h3 className="text-base font-bold text-white flex items-center gap-2 mb-1">
                <Wrench className="h-5 w-5 text-emerald-400" />
                Pakistani Tractor Implements & Attachments
              </h3>
              <p className="text-xs text-stone-400 mb-4">
                Hitch implements to the 3-point tractor hitch to plough, cultivate, seed, fertilize, spray, harvest, and haul crops.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {machinery.map((item) => {
                  const isHitched = currentImplement === item.id;
                  return (
                    <div
                      key={item.id}
                      className={`rounded-xl border p-3.5 shadow-md flex flex-col justify-between ${
                        isHitched
                          ? 'border-amber-500 bg-amber-950/20'
                          : 'border-stone-800 bg-stone-900'
                      }`}
                    >
                      <div>
                        <div className="flex items-center justify-between">
                          <span className="font-bold text-white text-sm">{item.name}</span>
                          <span className="text-xs text-stone-400 font-urdu">{item.urduName}</span>
                        </div>
                        <p className="text-xs text-stone-400 mt-1">{item.description}</p>
                        <div className="mt-2 text-[11px] text-stone-300">
                          Working Width: <span className="font-bold text-amber-400">{item.workWidth}m</span>
                        </div>
                      </div>

                      <div className="mt-4">
                        {item.owned ? (
                          <button
                            onClick={() => onHitchImplement(item.id)}
                            className={`w-full rounded-xl py-2 text-xs font-bold transition-all ${
                              isHitched
                                ? 'bg-amber-500 text-stone-950 ring-2 ring-amber-400'
                                : 'bg-stone-800 text-stone-200 hover:bg-stone-700'
                            }`}
                          >
                            {isHitched ? 'Currently Hitched' : 'Hitch to Tractor'}
                          </button>
                        ) : (
                          <button
                            disabled={stats.money < item.price}
                            onClick={() => onBuyMachinery(item)}
                            className="w-full rounded-xl bg-emerald-600 py-2 text-xs font-bold text-white transition-all hover:bg-emerald-500 disabled:opacity-50"
                          >
                            Buy for Rs. {item.price.toLocaleString()}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* --- TAB 3: TRACTOR GARAGE UPGRADES --- */}
          {activeTab === 'tractor' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Tractor className="h-5 w-5 text-emerald-400" />
                Pakistani Tractor Fleet Upgrades
              </h3>
              <p className="text-xs text-stone-400">
                Upgrade from the 50 HP Millat Massey Ferguson 240 up to the powerful 85 HP MF 385 Turbo for faster tillage and pulling heavier payloads.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-4 mt-3">
                {TRACTOR_UPGRADES.map((upgrade) => {
                  const isCurrent = tractorUpgradeLevel === upgrade.level;
                  const isOwnedOrPassed = tractorUpgradeLevel >= upgrade.level;
                  return (
                    <div
                      key={upgrade.level}
                      className={`rounded-xl border p-4 shadow-md flex flex-col justify-between ${
                        isCurrent
                          ? 'border-amber-500 bg-amber-950/20'
                          : 'border-stone-800 bg-stone-900'
                      }`}
                    >
                      <div>
                        <div className="font-bold text-white text-base">{upgrade.name}</div>
                        <div className="mt-2 space-y-1 text-xs text-stone-300">
                          <div>
                            Power: <span className="font-bold text-emerald-400">{upgrade.enginePowerHp} HP</span>
                          </div>
                          <div>
                            Fuel Tank: <span className="font-bold text-sky-400">{upgrade.fuelTankMax} Liters</span>
                          </div>
                          <div>
                            Top Speed: <span className="font-bold text-amber-400">{upgrade.speedMax} km/h</span>
                          </div>
                        </div>
                      </div>

                      <div className="mt-4">
                        {isCurrent ? (
                          <div className="rounded-xl bg-amber-500/20 py-2 text-center text-xs font-bold text-amber-400">
                            Active Tractor
                          </div>
                        ) : isOwnedOrPassed ? (
                          <button
                            onClick={() => onUpgradeTractor(upgrade.level)}
                            className="w-full rounded-xl bg-stone-800 py-2 text-xs font-bold text-stone-300 hover:bg-stone-700"
                          >
                            Switch to This Tractor
                          </button>
                        ) : (
                          <button
                            disabled={stats.money < upgrade.upgradeCost}
                            onClick={() => onUpgradeTractor(upgrade.level)}
                            className="w-full rounded-xl bg-emerald-600 py-2 text-xs font-bold text-white transition-all hover:bg-emerald-500 disabled:opacity-50"
                          >
                            Purchase for Rs. {upgrade.upgradeCost.toLocaleString()}
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* --- TAB 4: VILLAGE MANDI / COMMODITY MARKET --- */}
          {activeTab === 'market' && (
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <h3 className="text-base font-bold text-white flex items-center gap-2">
                    <TrendingUp className="h-5 w-5 text-emerald-400" />
                    Punjab & Sindh Grain Mandi (Official Rates)
                  </h3>
                  <p className="text-xs text-stone-400">
                    Live market commodity rates per 40 kg Maund (من). Prices adjust dynamically based on season.
                  </p>
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                {(Object.keys(CROPS_DATA) as CropType[]).map((cropKey) => {
                  const crop = CROPS_DATA[cropKey];
                  return (
                    <div
                      key={cropKey}
                      className="rounded-xl border border-stone-800 bg-stone-900 p-3.5 flex items-center justify-between"
                    >
                      <div>
                        <div className="font-bold text-white text-sm">{crop.name}</div>
                        <div className="text-xs text-stone-400 font-urdu">{crop.urduName}</div>
                      </div>
                      <div className="text-right">
                        <div className="text-base font-black text-emerald-400">
                          Rs. {crop.baseMarketPricePer40Kg.toLocaleString()}
                        </div>
                        <div className="text-[10px] text-stone-400">per 40 kg Maund</div>
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* --- TAB 5: LIVESTOCK HAVELI --- */}
          {activeTab === 'animals' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <Milk className="h-5 w-5 text-emerald-400" />
                Village Cattle Shed (Haveli)
              </h3>
              <p className="text-xs text-stone-400">
                Raise authentic Pakistani dairy animals (Nili-Ravi Buffaloes, Sahiwal Cows, Beetal Goats, Desi Chickens) to generate daily farm income.
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-3">
                {animals.map((pen) => (
                  <div
                    key={pen.id}
                    className="rounded-xl border border-stone-800 bg-stone-900 p-4 shadow-md flex flex-col justify-between"
                  >
                    <div>
                      <div className="flex items-center justify-between">
                        <div className="font-bold text-white text-base">{pen.name}</div>
                        <div className="text-xs text-stone-400 font-urdu">{pen.urduName}</div>
                      </div>

                      <div className="mt-3 grid grid-cols-3 gap-2 text-center text-xs">
                        <div className="rounded bg-stone-800 p-2">
                          <div className="text-[10px] text-stone-400">Herd Count</div>
                          <div className="font-bold text-white">{pen.count} Animals</div>
                        </div>
                        <div className="rounded bg-stone-800 p-2">
                          <div className="text-[10px] text-stone-400">Feed Level</div>
                          <div className="font-bold text-emerald-400">{pen.feedLevel}%</div>
                        </div>
                        <div className="rounded bg-stone-800 p-2">
                          <div className="text-[10px] text-stone-400">Ready Product</div>
                          <div className="font-bold text-amber-400">
                            {pen.productReady} {pen.productType.split(' ')[0]}
                          </div>
                        </div>
                      </div>
                    </div>

                    <div className="mt-4 flex gap-2">
                      <button
                        onClick={() => onCollectAnimalProduct(pen.id)}
                        className="flex-1 rounded-xl bg-amber-600 py-2 text-xs font-bold text-white transition-all hover:bg-amber-500"
                      >
                        Collect & Sell {pen.productType.split(' ')[0]}
                      </button>
                      <button
                        onClick={() => onFeedAnimals(pen.id)}
                        className="rounded-xl bg-stone-800 px-3 py-2 text-xs font-bold text-stone-200 hover:bg-stone-700"
                      >
                        Feed Barseem
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {/* --- TAB 6: MISSIONS & CONTRACTS --- */}
          {activeTab === 'missions' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <CheckCircle2 className="h-5 w-5 text-emerald-400" />
                Zamindari Farming Missions & Contracts
              </h3>
              <p className="text-xs text-stone-400">
                Complete agricultural tasks across your fields to earn substantial Pakistani Rupee bonuses and Farmer XP!
              </p>

              <div className="space-y-3 mt-3">
                {missions.map((m) => {
                  const progressPct = Math.min(100, Math.round((m.currentValue / m.targetValue) * 100));
                  const isReady = m.currentValue >= m.targetValue && !m.completed;
                  return (
                    <div
                      key={m.id}
                      className={`rounded-xl border p-4 shadow-md ${
                        m.completed
                          ? 'border-emerald-800/40 bg-stone-900/40 opacity-70'
                          : 'border-stone-800 bg-stone-900'
                      }`}
                    >
                      <div className="flex items-start justify-between">
                        <div>
                          <div className="font-bold text-white text-sm">{m.title}</div>
                          <div className="text-xs text-stone-400 font-urdu">{m.urduTitle}</div>
                          <p className="text-xs text-stone-300 mt-1">{m.description}</p>
                        </div>
                        <div className="text-right">
                          <div className="font-black text-emerald-400 text-sm">
                            +Rs. {m.rewardMoney.toLocaleString()}
                          </div>
                          <div className="text-[10px] text-amber-400">+{m.rewardXp} XP</div>
                        </div>
                      </div>

                      <div className="mt-3 flex items-center justify-between gap-4">
                        <div className="flex-1">
                          <div className="flex justify-between text-[11px] text-stone-400 mb-1">
                            <span>Progress</span>
                            <span>{progressPct}%</span>
                          </div>
                          <div className="h-2 w-full overflow-hidden rounded-full bg-stone-800">
                            <div
                              className="h-full bg-emerald-500 transition-all"
                              style={{ width: `${progressPct}%` }}
                            />
                          </div>
                        </div>

                        {isReady && (
                          <button
                            onClick={() => onClaimMissionReward(m.id)}
                            className="rounded-xl bg-emerald-600 px-4 py-1.5 text-xs font-bold text-white shadow-lg transition-all hover:bg-emerald-500 active:scale-95"
                          >
                            Claim Reward
                          </button>
                        )}
                        {m.completed && (
                          <span className="text-xs font-bold text-emerald-400 flex items-center gap-1">
                            <CheckCircle2 className="h-4 w-4" /> Completed
                          </span>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>
          )}

          {/* --- TAB 7: REGION MAP --- */}
          {activeTab === 'map' && (
            <div className="space-y-4">
              <h3 className="text-base font-bold text-white flex items-center gap-2">
                <MapPin className="h-5 w-5 text-emerald-400" />
                Village & Agricultural Estate Map
              </h3>
              <p className="text-xs text-stone-400">
                Key landmarks in your Pakistani rural farming environment:
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 mt-3">
                <div className="rounded-xl border border-stone-800 bg-stone-900 p-3">
                  <div className="font-bold text-amber-400 text-sm">Pakistani Dera & Farm House</div>
                  <div className="text-xs text-stone-300 mt-0.5">Location: Center West (-25, -25)</div>
                  <p className="text-xs text-stone-400 mt-1">
                    Your residential haveli, charpais, water pitchers, and tractor shed.
                  </p>
                </div>

                <div className="rounded-xl border border-stone-800 bg-stone-900 p-3">
                  <div className="font-bold text-sky-400 text-sm">Tube Well Pump Station (Peter Engine)</div>
                  <div className="text-xs text-stone-300 mt-0.5">Location: Central North (-5, -35)</div>
                  <p className="text-xs text-stone-400 mt-1">
                    Heavy single-cylinder diesel motor and concrete water houz irrigating all field channels.
                  </p>
                </div>

                <div className="rounded-xl border border-stone-800 bg-stone-900 p-3">
                  <div className="font-bold text-emerald-400 text-sm">Village Grain Mandi (Market Platform)</div>
                  <div className="text-xs text-stone-300 mt-0.5">Location: South East (40, 50)</div>
                  <p className="text-xs text-stone-400 mt-1">
                    Covered auction shed with weighing scale (kanda) where you sell harvested crops for cash.
                  </p>
                </div>

                <div className="rounded-xl border border-stone-800 bg-stone-900 p-3">
                  <div className="font-bold text-blue-400 text-sm">Petrol Pump & Diesel Station</div>
                  <div className="text-xs text-stone-300 mt-0.5">Location: South West (-45, 45)</div>
                  <p className="text-xs text-stone-400 mt-1">
                    Refuel your Millat or Fiat tractor diesel tank.
                  </p>
                </div>
              </div>
            </div>
          )}

          {/* --- TAB 8: SETTINGS & SAVE --- */}
          {activeTab === 'settings' && (
            <div className="space-y-6 max-w-xl">
              <div>
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
                  <CloudRain className="h-5 w-5 text-emerald-400" />
                  Dynamic Weather Simulator
                </h3>
                <div className="grid grid-cols-2 sm:grid-cols-4 gap-2">
                  {(['sunny', 'cloudy', 'rain', 'storm'] as WeatherType[]).map((w) => (
                    <button
                      key={w}
                      onClick={() => onSetWeather(w)}
                      className={`rounded-xl py-2 text-xs font-bold capitalize transition-all border ${
                        stats.weather === w
                          ? 'border-emerald-500 bg-emerald-950/40 text-emerald-300'
                          : 'border-stone-800 bg-stone-900 text-stone-300 hover:bg-stone-800'
                      }`}
                    >
                      {w === 'rain' ? 'Monsoon Rain' : w}
                    </button>
                  ))}
                </div>
              </div>

              <div className="border-t border-stone-800 pt-4">
                <h3 className="text-base font-bold text-white flex items-center gap-2 mb-2">
                  <Save className="h-5 w-5 text-emerald-400" />
                  Game Progress & Save File
                </h3>
                <div className="flex gap-3">
                  <button
                    onClick={onSaveGame}
                    className="flex items-center gap-2 rounded-xl bg-emerald-600 px-4 py-2.5 text-xs font-bold text-white shadow-md hover:bg-emerald-500 active:scale-95"
                  >
                    <Save className="h-4 w-4" /> Save Game Progress
                  </button>

                  <button
                    onClick={onResetGame}
                    className="flex items-center gap-2 rounded-xl bg-red-950/40 border border-red-800/60 px-4 py-2.5 text-xs font-bold text-red-300 hover:bg-red-900/50 active:scale-95"
                  >
                    <RotateCcw className="h-4 w-4" /> Reset New Farm
                  </button>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
