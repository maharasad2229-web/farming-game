import React from 'react';
import {
  Volume2,
  VolumeX,
  Camera,
  MapPin,
  Tractor,
  Droplets,
  Sprout,
  CheckCircle2,
  Menu,
  Sparkles,
  Gauge,
  Fuel,
  Sun,
  CloudRain,
  Cloud,
  Coins,
  Film,
  Smartphone
} from 'lucide-react';
import {
  PlayerStats,
  FieldData,
  ImplementType,
  CropType
} from '../types';
import { InteractionPrompt } from '../game/GameEngine';
import { CROPS_DATA } from '../game/constants';

interface HUDProps {
  stats: PlayerStats;
  inVehicle: boolean;
  speed: number;
  gear: number;
  currentImplement: ImplementType;
  implementLowered: boolean;
  trolleyCargo: { crop: CropType | null; amountKg: number };
  activeField: FieldData | null;
  interactionPrompt: InteractionPrompt | null;
  cameraMode: 1 | 2 | 3;
  isMuted: boolean;
  isTouchControlsVisible?: boolean;
  onToggleTouchControls?: () => void;
  onToggleMute: () => void;
  onCycleCamera: () => void;
  onOpenMenu: () => void;
  onOpenVideoDemo?: () => void;
  onTriggerAction: () => void;
  onToggleVehicle: () => void;
  onToggleImplement: () => void;
  onHonkHorn: () => void;
}

export const HUD: React.FC<HUDProps> = ({
  stats,
  inVehicle,
  speed,
  gear,
  currentImplement,
  implementLowered,
  trolleyCargo,
  activeField,
  interactionPrompt,
  cameraMode,
  isMuted,
  isTouchControlsVisible,
  onToggleTouchControls,
  onToggleMute,
  onCycleCamera,
  onOpenMenu,
  onOpenVideoDemo,
  onTriggerAction,
  onToggleVehicle,
  onToggleImplement,
  onHonkHorn
}) => {
  // Format game time (mins -> HH:MM AM/PM)
  const hours = Math.floor(stats.gameTimeMinutes / 60);
  const minutes = Math.floor(stats.gameTimeMinutes % 60);
  const period = hours >= 12 ? 'PM' : 'AM';
  const displayHours = hours % 12 === 0 ? 12 : hours % 12;
  const timeString = `${displayHours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')} ${period}`;

  // Speed in km/h
  const speedKmh = Math.abs(Math.round(speed * 3.6));

  return (
    <div className="pointer-events-none absolute inset-0 select-none overflow-hidden font-sans">
      {/* --- TOP BAR --- */}
      <div className="pointer-events-auto flex items-center justify-between p-3 sm:p-4">
        {/* Left: Player Zamindar Info & Wealth */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2 rounded-xl border border-emerald-500/30 bg-stone-900/85 px-3 py-2 text-white shadow-lg backdrop-blur-md">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-emerald-600 font-bold text-white shadow">
              <Coins className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-emerald-400 font-semibold">
                Pakistani Rupees
              </div>
              <div className="text-base sm:text-lg font-black tracking-tight text-white">
                Rs. {stats.money.toLocaleString()}
              </div>
            </div>
          </div>

          <div className="hidden sm:flex items-center gap-2 rounded-xl border border-amber-500/30 bg-stone-900/85 px-3 py-2 text-white shadow-lg backdrop-blur-md">
            <div className="flex h-9 w-9 items-center justify-center rounded-lg bg-amber-600 font-bold text-white shadow">
              <Sparkles className="h-5 w-5" />
            </div>
            <div>
              <div className="text-[10px] uppercase tracking-wider text-amber-400 font-semibold">
                Rank: {stats.farmerTitle}
              </div>
              <div className="text-sm font-bold text-white">
                Level {stats.level} <span className="text-xs text-stone-400">({stats.xp} XP)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Center: Rural Clock & Weather Badge */}
        <div className="flex items-center gap-2 rounded-full border border-stone-700/60 bg-stone-900/80 px-4 py-1.5 text-white shadow-lg backdrop-blur-md">
          {stats.weather === 'rain' || stats.weather === 'storm' ? (
            <CloudRain className="h-4 w-4 text-sky-400 animate-pulse" />
          ) : stats.weather === 'cloudy' ? (
            <Cloud className="h-4 w-4 text-stone-300" />
          ) : (
            <Sun className="h-4 w-4 text-amber-400" />
          )}
          <span className="text-xs font-semibold text-stone-200">{timeString}</span>
          <span className="text-stone-500">•</span>
          <span className="text-xs capitalize text-emerald-300 font-medium">
            {stats.weather === 'rain' ? 'Monsoon Rain' : stats.weather}
          </span>
          {stats.waterPumpRunning && (
            <span className="hidden md:inline-flex items-center gap-1 rounded-full bg-cyan-900/60 px-2 py-0.5 text-[10px] font-bold text-cyan-300">
              <Droplets className="h-3 w-3 animate-bounce" /> Tube Well Running
            </span>
          )}
        </div>

        {/* Right: Quick Settings & Menu button */}
        <div className="flex items-center gap-2">
          <button
            onClick={onToggleMute}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-700/60 bg-stone-900/85 text-stone-200 transition-colors hover:bg-stone-800 hover:text-white"
            title={isMuted ? 'Unmute Sound' : 'Mute Sound'}
          >
            {isMuted ? <VolumeX className="h-5 w-5" /> : <Volume2 className="h-5 w-5 text-emerald-400" />}
          </button>

          <button
            onClick={onCycleCamera}
            className="flex h-10 w-10 items-center justify-center rounded-xl border border-stone-700/60 bg-stone-900/85 text-stone-200 transition-colors hover:bg-stone-800 hover:text-white"
            title="Switch Camera (1, 2, 3)"
          >
            <Camera className="h-5 w-5 text-amber-400" />
          </button>

          {onToggleTouchControls && (
            <button
              onClick={onToggleTouchControls}
              className={`flex h-10 items-center gap-1.5 rounded-xl border px-2.5 transition-all active:scale-95 ${
                isTouchControlsVisible
                  ? 'border-emerald-500 bg-emerald-700 text-white shadow-md'
                  : 'border-stone-700/60 bg-stone-900/85 text-stone-300 hover:bg-stone-800'
              }`}
              title="Toggle Mobile & Touchscreen Laptop Controls (ٹچ کنٹرولز)"
            >
              <Smartphone className={`h-5 w-5 ${isTouchControlsVisible ? 'text-white' : 'text-amber-400'}`} />
              <span className="hidden sm:inline text-xs font-bold">
                {isTouchControlsVisible ? 'Touch ON' : 'Touch'}
              </span>
            </button>
          )}

          {onOpenVideoDemo && (
            <button
              onClick={onOpenVideoDemo}
              className="flex items-center gap-1.5 rounded-xl border border-amber-500/40 bg-gradient-to-r from-amber-600 to-amber-700 px-3 py-2 font-bold text-white shadow-md transition-all hover:from-amber-500 hover:to-amber-600 active:scale-95"
              title="Watch Video Demo & Gameplay Walkthrough"
            >
              <Film className="h-4 w-4" />
              <span className="hidden md:inline text-xs">Video Demo</span>
            </button>
          )}

          <button
            onClick={onOpenMenu}
            className="flex items-center gap-2 rounded-xl border border-emerald-600/40 bg-emerald-700 px-3.5 py-2 font-bold text-white shadow-md transition-all hover:bg-emerald-600 active:scale-95"
          >
            <Menu className="h-5 w-5" />
            <span className="hidden sm:inline text-sm">Farm Menu</span>
          </button>
        </div>
      </div>

      {/* --- ACTIVE FIELD STATUS BANNER (When inside a field) --- */}
      {activeField && (
        <div className="pointer-events-auto mx-auto mt-1 max-w-xl rounded-xl border border-amber-600/40 bg-stone-900/90 p-3 text-white shadow-2xl backdrop-blur-md">
          <div className="flex items-center justify-between border-b border-stone-800 pb-1.5">
            <div className="flex items-center gap-2">
              <MapPin className="h-4 w-4 text-emerald-400" />
              <span className="font-bold text-sm text-emerald-300">{activeField.name}</span>
              <span className="rounded bg-stone-800 px-1.5 py-0.5 text-[10px] text-stone-400">
                {activeField.acres} Acres
              </span>
            </div>
            <div className="text-xs font-semibold capitalize text-amber-300">
              State: {activeField.soilState.replace('_', ' ')}
            </div>
          </div>

          <div className="mt-2 grid grid-cols-4 gap-2 text-center text-xs">
            <div className="rounded-lg bg-stone-800/80 p-1.5">
              <div className="text-[10px] text-stone-400">Planted Crop</div>
              <div className="font-bold text-emerald-400">
                {activeField.plantedCrop ? CROPS_DATA[activeField.plantedCrop].name.split(' ')[0] : 'None'}
              </div>
            </div>
            <div className="rounded-lg bg-stone-800/80 p-1.5">
              <div className="text-[10px] text-stone-400">Growth</div>
              <div className="font-bold text-amber-400">{Math.round(activeField.growthProgress)}%</div>
            </div>
            <div className="rounded-lg bg-stone-800/80 p-1.5">
              <div className="text-[10px] text-stone-400">Moisture</div>
              <div className="font-bold text-sky-400">{Math.round(activeField.moistureLevel)}%</div>
            </div>
            <div className="rounded-lg bg-stone-800/80 p-1.5">
              <div className="text-[10px] text-stone-400">Fertilizer</div>
              <div className="font-bold text-lime-400">{Math.round(activeField.fertilizerLevel)}%</div>
            </div>
          </div>
        </div>
      )}

      {/* --- CENTER INTERACTION PROMPT --- */}
      {interactionPrompt && (
        <div className="pointer-events-auto absolute bottom-24 left-1/2 -translate-x-1/2">
          <button
            onClick={onTriggerAction}
            className="flex items-center gap-3 rounded-2xl border-2 border-amber-400 bg-stone-900/95 px-5 py-3 text-white shadow-2xl backdrop-blur-md transition-all hover:scale-105 active:scale-95"
          >
            <span className="flex h-7 w-7 items-center justify-center rounded-lg bg-amber-500 font-black text-stone-950 text-sm">
              {interactionPrompt.keyLabel}
            </span>
            <span className="text-sm sm:text-base font-bold text-amber-200">
              {interactionPrompt.action}
            </span>
          </button>
        </div>
      )}

      {/* --- BOTTOM VEHICLE COCKPIT / CLUSTER (When Driving Tractor) --- */}
      {inVehicle && (
        <div className="pointer-events-auto absolute bottom-4 right-4 flex items-end gap-3">
          {/* Implement Controller */}
          <div className="flex flex-col items-center gap-1.5 rounded-2xl border border-stone-700/60 bg-stone-900/90 p-3 shadow-xl backdrop-blur-md">
            <div className="text-[10px] font-bold uppercase tracking-wider text-stone-400">
              Implement (G)
            </div>
            <button
              onClick={onToggleImplement}
              className={`rounded-xl px-3 py-1.5 text-xs font-bold transition-all ${
                implementLowered
                  ? 'bg-amber-500 text-stone-950 shadow-md ring-2 ring-amber-400'
                  : 'bg-stone-800 text-stone-300 hover:bg-stone-700'
              }`}
            >
              {currentImplement.replace('_', ' ').toUpperCase()} • {implementLowered ? 'LOWERED' : 'RAISED'}
            </button>
            <button
              onClick={onHonkHorn}
              className="mt-1 flex w-full items-center justify-center gap-1 rounded-lg bg-rose-600/80 px-2 py-1 text-[11px] font-bold text-white hover:bg-rose-500 active:scale-95"
            >
              Horn (H)
            </button>
          </div>

          {/* Speedometer & Gear */}
          <div className="flex items-center gap-3 rounded-2xl border border-stone-700/60 bg-stone-900/90 p-4 shadow-xl backdrop-blur-md">
            <div className="text-center">
              <div className="text-3xl font-black tracking-tight text-white">{speedKmh}</div>
              <div className="text-[10px] font-bold uppercase text-stone-400">KM / H</div>
            </div>

            <div className="h-10 w-px bg-stone-700" />

            <div className="text-center">
              <div className="text-lg font-black text-amber-400">
                {gear === 1 ? 'LOW' : gear === 2 ? 'HIGH' : 'REV'}
              </div>
              <div className="text-[10px] font-bold text-stone-400">GEAR</div>
            </div>

            <div className="h-10 w-px bg-stone-700" />

            {/* Fuel Gauge */}
            <div className="w-16">
              <div className="flex items-center justify-between text-[10px] text-stone-400 mb-1">
                <Fuel className="h-3 w-3 text-amber-400" />
                <span>{Math.round(stats.fuel)} L</span>
              </div>
              <div className="h-2 w-full overflow-hidden rounded-full bg-stone-800">
                <div
                  className={`h-full transition-all ${
                    stats.fuel < 10 ? 'bg-red-500 animate-pulse' : 'bg-amber-500'
                  }`}
                  style={{ width: `${(stats.fuel / stats.maxFuel) * 100}%` }}
                />
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- TROLLEY CARGO INDICATOR (Bottom Left) --- */}
      {trolleyCargo.amountKg > 0 && (
        <div className="pointer-events-auto absolute bottom-4 left-4 rounded-2xl border border-amber-600/40 bg-stone-900/90 p-3 text-white shadow-xl backdrop-blur-md">
          <div className="text-[10px] font-bold uppercase tracking-wider text-amber-400">
            Trolley Cargo (Tractor Haul)
          </div>
          <div className="flex items-center gap-2 mt-1">
            <Tractor className="h-5 w-5 text-emerald-400" />
            <div>
              <div className="text-sm font-bold text-stone-100">
                {trolleyCargo.amountKg.toLocaleString()} kg{' '}
                {trolleyCargo.crop ? CROPS_DATA[trolleyCargo.crop].name : ''}
              </div>
              <div className="text-[11px] text-emerald-400">
                Take to Mandi to sell for Cash!
              </div>
            </div>
          </div>
        </div>
      )}

      {/* --- CONTROLS HINT (Top Left desktop) --- */}
      <div className="hidden lg:block absolute left-4 top-20 rounded-xl bg-stone-950/70 p-3 text-[11px] text-stone-300 backdrop-blur-sm">
        <div className="font-bold text-stone-100 mb-1">Controls Guide</div>
        <div>W, A, S, D = Drive / Walk</div>
        <div>E = Enter / Exit Tractor</div>
        <div>F = Action (Tube well, Refuel, Mandi)</div>
        <div>G = Lower / Raise Plough/Tiller</div>
        <div>H = Tractor Horn</div>
        <div>Space = Brake</div>
        <div>1, 2, 3 = Camera Views</div>
      </div>
    </div>
  );
};
