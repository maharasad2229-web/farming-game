import React, { useState, useEffect, useRef } from 'react';
import {
  Play,
  Pause,
  RotateCcw,
  Volume2,
  VolumeX,
  Tractor,
  Droplets,
  Sprout,
  Coins,
  ChevronRight,
  ChevronLeft,
  X,
  Sparkles,
  CheckCircle2,
  ArrowRight,
  Gauge,
  HelpCircle,
  Film
} from 'lucide-react';
import { sound } from '../audio/SoundEngine';

interface VideoDemoModalProps {
  isOpen: boolean;
  onClose: () => void;
  onStartGame?: () => void;
}

interface DemoScene {
  id: number;
  titleEn: string;
  titleUr: string;
  duration: number; // in seconds
  badge: string;
  descriptionUr: string;
  descriptionEn: string;
  instructions: { key: string; action: string }[];
}

const DEMO_SCENES: DemoScene[] = [
  {
    id: 1,
    titleEn: '1. Tractor Driving & Controls',
    titleUr: '۱۔ ٹریکٹر چلانا اور ڈرائیونگ کنٹرولز',
    duration: 10,
    badge: 'Step 1: Driving (ڈرائیونگ)',
    descriptionUr: 'Mobile / Touch pe Green pedal se Race dein, Red pedal se Break. Keyboard pe W se race, S se break/reverse, A/D se steering, aur E se tractor me baithna.',
    descriptionEn: 'On Mobile/Touch: Hold Green pedal to Race, Red to Brake. On Keyboard: Use W to accelerate, S to reverse, A/D to steer, and E to enter/exit tractor.',
    instructions: [
      { key: 'Touch Pedals', action: 'Green Pedal = Race | Red Pedal = Brake' },
      { key: 'Joystick / AD', action: 'Left Joystick ya Buttons se tractor moro' },
      { key: 'E / Button', action: 'Tractor me baitho ya utro' },
      { key: 'H / Horn', action: 'Desi Punjabi truck horn bajao' }
    ]
  },
  {
    id: 2,
    titleEn: '2. Hitching Implements (Hal & Tiller)',
    titleUr: '۲۔ زرعی اوزار جوڑنا (ہل اور ٹلر)',
    duration: 11,
    badge: 'Step 2: Machinery (اوزار)',
    descriptionUr: 'Farm Menu khol kr Machinery tab se Hal (Plough) ya Rotavator jorein. Hal ko zameen me utarne k liye V ka button dabayein.',
    descriptionEn: 'Open Farm Menu to hitch the Heavy Cultivator or Rotavator. Press V button to lower tines into soil or raise for driving on road.',
    instructions: [
      { key: 'Menu', action: 'Farm Menu se Hal (Plough) ya Tiller joro' },
      { key: 'V / Button', action: 'Hal zameen me utaro / uthao (Lower/Raise)' },
      { key: 'Handbrake', action: 'Handbrake button se tractor ko khara kro' }
    ]
  },
  {
    id: 3,
    titleEn: '3. Field Plowing & Seed Sowing',
    titleUr: '۳۔ زمین کی تیاری اور بیج بونا',
    duration: 12,
    badge: 'Step 3: Plowing & Seeds (کاشتکاری)',
    descriptionUr: 'Hal neeche rakh kr khet k andar tractor chalao taake mitti naram ho jaye. Phir Seed Drill se Gandum (Wheat) ya Chawal k beej bo do.',
    descriptionEn: 'Lower the plow into your field and drive straight lines to till dark fertile soil. Then use Seed Drill to sow wheat or basmati rice.',
    instructions: [
      { key: 'Hal Chalao', action: 'Khet k andar seedhi lines me tractor chalao' },
      { key: 'Soil Ploughed', action: 'Mitti naram or kali ho jayegi' },
      { key: 'Beej Bona', action: 'Crops tab se Gandum ya Chawal select kro' }
    ]
  },
  {
    id: 4,
    titleEn: '4. Tube Well Water Irrigation',
    titleUr: '۴۔ پیٹر انجن ٹیوب ویل سے پانی لگانا',
    duration: 10,
    badge: 'Step 4: Irrigation (پانی لگانا)',
    descriptionUr: 'Khet k paas Tube Well k kamre k paas jao or Kaam (F) ka button dabao. Peter engine thak thak chalega or thanda paani khet me behna shuru ho jayega.',
    descriptionEn: 'Walk to the concrete tube well pump station and press F. The heavy diesel Peter engine chugs to life and pumps fresh water to irrigate crops.',
    instructions: [
      { key: 'F / Button', action: 'Tube Well k paas Kaam (F) button dabao' },
      { key: 'Peter Engine', action: 'Motor start hogi or paani khoob bahega' },
      { key: 'Fasal Growth', action: 'Paani milne se fasal 2x tezi se barhegi' }
    ]
  },
  {
    id: 5,
    titleEn: '5. Crop Harvesting & Trolley Loading',
    titleUr: '۵۔ سنہری فصل کی کٹائی اور ٹرالی بھرنا',
    duration: 11,
    badge: 'Step 5: Harvesting (کٹائی)',
    descriptionUr: 'Jab fasal sunhari pak jaye to Harvester cutter se kaato. Phir desi Pakistani trolley jor kr saari fasal trolley me load kr lo.',
    descriptionEn: 'When crops ripen into gold, attach the harvester cutter to harvest. Hitch the Pakistani trolley to load thousands of kg of fresh crops.',
    instructions: [
      { key: 'Cutter', action: 'Pakki hui gandum par cutter chala kr kaato' },
      { key: 'Trolley', action: 'Menu se Pakistani Trolley jor lo' },
      { key: 'Load Cargo', action: 'Fasal trolley me load ho jayegi (kg wazan)' }
    ]
  },
  {
    id: 6,
    titleEn: '6. Selling at Ghalla Mandi & Upgrading',
    titleUr: '۶۔ غلہ منڈی میں فروخت اور نئے ٹریکٹر',
    duration: 12,
    badge: 'Step 6: Mandi Profit (کمائی)',
    descriptionUr: 'Bhari hui trolley chala kr Ghalla Mandi le jao. Kante (weighbridge) par khari kr k becho, lakhoon rupay kamao or naye tractor khareedo.',
    descriptionEn: 'Drive the loaded trolley to the Ghalla Mandi weighbridge. Sell your harvest for cash Rupees and upgrade to Fiat 640 & Belarus 820.',
    instructions: [
      { key: 'Drive to Mandi', action: 'Road par trolley chala kr Mandi le jao' },
      { key: 'Sell Crop', action: 'Sell button daba kr lakhoon cash rupay kamao' },
      { key: 'Upgrade', action: 'Naye Fiat 640 or Belarus tractor khareedo' }
    ]
  }
];

export const VideoDemoModal: React.FC<VideoDemoModalProps> = ({
  isOpen,
  onClose,
  onStartGame
}) => {
  const [activeTab, setActiveTab] = useState<'video' | 'guide'>('video');
  const [currentSceneIndex, setCurrentSceneIndex] = useState<number>(0);
  const [isPlaying, setIsPlaying] = useState<boolean>(true);
  const [progress, setProgress] = useState<number>(0); // 0 to 100
  const [isAudioMuted, setIsAudioMuted] = useState<boolean>(false);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const animFrameRef = useRef<number>(0);
  const sceneTimerRef = useRef<number>(0);

  const currentScene = DEMO_SCENES[currentSceneIndex];

  // Sound effects per scene
  useEffect(() => {
    if (!isOpen || activeTab !== 'video') return;

    if (!isAudioMuted) {
      if (currentScene.id === 1) {
        sound.startTractorEngine();
        setTimeout(() => sound.playTractorHorn(), 2000);
      } else if (currentScene.id === 2) {
        sound.playHitchImplement();
      } else if (currentScene.id === 4) {
        sound.setTubeWellState(true);
      } else if (currentScene.id === 6) {
        sound.playCashRegister();
      }
    }

    return () => {
      sound.setTubeWellState(false);
      sound.stopTractorEngine();
    };
  }, [currentSceneIndex, isOpen, activeTab, isAudioMuted]);

  // Scene timer loop
  useEffect(() => {
    if (!isOpen || !isPlaying || activeTab !== 'video') return;

    const interval = 50; // ms
    const step = (interval / (currentScene.duration * 1000)) * 100;

    const timer = setInterval(() => {
      setProgress((prev) => {
        if (prev >= 100) {
          // Next scene or loop
          setCurrentSceneIndex((idx) => (idx + 1) % DEMO_SCENES.length);
          return 0;
        }
        return prev + step;
      });
    }, interval);

    return () => clearInterval(timer);
  }, [isOpen, isPlaying, currentSceneIndex, currentScene.duration, activeTab]);

  // Canvas visual rendering for the animated demo video
  useEffect(() => {
    if (!isOpen || activeTab !== 'video') return;
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    let time = 0;

    const render = () => {
      time += 0.03;
      const w = canvas.width;
      const h = canvas.height;

      // Clear
      ctx.clearRect(0, 0, w, h);

      // Draw Sky with gradient
      const skyGrad = ctx.createLinearGradient(0, 0, 0, h * 0.65);
      skyGrad.addColorStop(0, '#38bdf8');
      skyGrad.addColorStop(1, '#fed7aa');
      ctx.fillStyle = skyGrad;
      ctx.fillRect(0, 0, w, h * 0.65);

      // Sun
      ctx.fillStyle = '#fef08a';
      ctx.beginPath();
      ctx.arc(w - 70, 50, 26, 0, Math.PI * 2);
      ctx.fill();

      // Distant Punjab Village Silhouettes (Kikar trees, mud brick haveli)
      ctx.fillStyle = '#166534';
      ctx.beginPath();
      ctx.ellipse(w * 0.2, h * 0.62, 120, 45, 0, 0, Math.PI * 2);
      ctx.ellipse(w * 0.5, h * 0.63, 160, 50, 0, 0, Math.PI * 2);
      ctx.ellipse(w * 0.85, h * 0.62, 140, 48, 0, 0, Math.PI * 2);
      ctx.fill();

      // Ground / Field
      const groundGrad = ctx.createLinearGradient(0, h * 0.62, 0, h);
      if (currentScene.id === 3) {
        // Tilled rich dark furrowed brown soil
        groundGrad.addColorStop(0, '#59341b');
        groundGrad.addColorStop(1, '#3b2010');
      } else if (currentScene.id === 4) {
        // Waterlogged lush green paddy
        groundGrad.addColorStop(0, '#15803d');
        groundGrad.addColorStop(1, '#0e7490');
      } else if (currentScene.id === 5) {
        // Golden ripe wheat field
        groundGrad.addColorStop(0, '#eab308');
        groundGrad.addColorStop(1, '#ca8a04');
      } else {
        // Village clay roadside
        groundGrad.addColorStop(0, '#78522f');
        groundGrad.addColorStop(1, '#452d19');
      }
      ctx.fillStyle = groundGrad;
      ctx.fillRect(0, h * 0.62, w, h * 0.38);

      // SCENE SPECIFIC ANIMATIONS
      if (currentScene.id === 1) {
        // SCENE 1: TRACTOR DRIVING ON ROAD
        const tractorX = (w * 0.35) + Math.sin(time * 2) * 20;
        const tractorY = h * 0.68 + Math.sin(time * 12) * 2.5;

        // Exhaust smoke puffs
        for (let i = 0; i < 4; i++) {
          const smokeAge = (time * 4 + i * 1.5) % 3;
          const smokeX = tractorX + 65 - smokeAge * 30;
          const smokeY = tractorY - 75 - smokeAge * 20;
          ctx.fillStyle = `rgba(100, 116, 139, ${Math.max(0, 0.4 - smokeAge * 0.12)})`;
          ctx.beginPath();
          ctx.arc(smokeX, smokeY, 8 + smokeAge * 7, 0, Math.PI * 2);
          ctx.fill();
        }

        // Tractor Red Hood
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(tractorX - 10, tractorY - 45, 90, 42);
        // White grill
        ctx.fillStyle = '#f8fafc';
        ctx.fillRect(tractorX + 70, tractorY - 43, 14, 38);
        // Engine block
        ctx.fillStyle = '#1e293b';
        ctx.fillRect(tractorX - 25, tractorY - 32, 35, 34);

        // Driver with Pagri
        ctx.fillStyle = '#1e40af'; // Blue Kurta
        ctx.fillRect(tractorX - 5, tractorY - 58, 26, 26);
        ctx.fillStyle = '#d97706'; // Golden Turban
        ctx.beginPath();
        ctx.arc(tractorX + 8, tractorY - 68, 14, 0, Math.PI * 2);
        ctx.fill();
        // Shamla
        ctx.fillStyle = '#f59e0b';
        ctx.fillRect(tractorX + 8, tractorY - 84, 8, 16);

        // Big Back Wheel
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(tractorX - 15, tractorY + 6, 32, 0, Math.PI * 2);
        ctx.fill();
        // Red rim with spinning spokes
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(tractorX - 15, tractorY + 6, 16, 0, Math.PI * 2);
        ctx.fill();
        ctx.strokeStyle = '#ffffff';
        ctx.lineWidth = 2.5;
        ctx.beginPath();
        ctx.moveTo(tractorX - 15 + Math.cos(time * 6) * 15, tractorY + 6 + Math.sin(time * 6) * 15);
        ctx.lineTo(tractorX - 15 - Math.cos(time * 6) * 15, tractorY + 6 - Math.sin(time * 6) * 15);
        ctx.stroke();

        // Small Front Wheel
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(tractorX + 68, tractorY + 14, 19, 0, Math.PI * 2);
        ctx.fill();
        ctx.fillStyle = '#dc2626';
        ctx.beginPath();
        ctx.arc(tractorX + 68, tractorY + 14, 9, 0, Math.PI * 2);
        ctx.fill();

        // White Canopy Roof
        ctx.fillStyle = '#ffffff';
        ctx.fillRect(tractorX - 35, tractorY - 92, 75, 8);
        ctx.strokeStyle = '#475569';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(tractorX - 25, tractorY - 92);
        ctx.lineTo(tractorX - 20, tractorY - 35);
        ctx.moveTo(tractorX + 30, tractorY - 92);
        ctx.lineTo(tractorX + 25, tractorY - 35);
        ctx.stroke();

        // Speedometer UI Overlay in demo
        ctx.fillStyle = 'rgba(15, 23, 42, 0.85)';
        ctx.roundRect(w - 180, 20, 160, 65, 12);
        ctx.fill();
        ctx.strokeStyle = '#22c55e';
        ctx.stroke();
        ctx.fillStyle = '#86efac';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText('SPEEDOMETER', w - 165, 38);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'black 22px sans-serif';
        ctx.fillText('32 km/h', w - 165, 66);
      } else if (currentScene.id === 2) {
        // SCENE 2: HITCHING ROTAVATOR & TILLER
        const tractorX = w * 0.42;
        const tractorY = h * 0.68;

        // Tractor Body
        ctx.fillStyle = '#dc2626';
        ctx.fillRect(tractorX, tractorY - 45, 85, 42);
        // Back Wheel
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(tractorX + 10, tractorY + 6, 32, 0, Math.PI * 2);
        ctx.fill();

        // Hitching Linkage Arms
        ctx.strokeStyle = '#64748b';
        ctx.lineWidth = 5;
        ctx.beginPath();
        ctx.moveTo(tractorX, tractorY - 10);
        ctx.lineTo(tractorX - 55, tractorY + (Math.sin(time * 3) > 0 ? 12 : -6));
        ctx.stroke();

        // Rotavator / Tiller (Orange frame with rotating C-blades)
        const implY = tractorY + (Math.sin(time * 3) > 0 ? 12 : -6);
        ctx.fillStyle = '#ea580c';
        ctx.fillRect(tractorX - 95, implY - 24, 45, 24);
        ctx.fillStyle = '#0284c7'; // Sonalika blue arms
        ctx.fillRect(tractorX - 100, implY - 10, 55, 6);

        // Rotating Blades at bottom
        for (let b = 0; b < 4; b++) {
          const bladeAngle = time * 12 + (b * Math.PI) / 2;
          ctx.strokeStyle = '#0f172a';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(tractorX - 75, implY);
          ctx.lineTo(tractorX - 75 + Math.cos(bladeAngle) * 14, implY + Math.sin(bladeAngle) * 14);
          ctx.stroke();
        }

        // [G] Lowering Indicator
        ctx.fillStyle = 'rgba(234, 88, 12, 0.9)';
        ctx.roundRect(tractorX - 120, implY - 60, 100, 26, 8);
        ctx.fill();
        ctx.fillStyle = '#ffffff';
        ctx.font = 'bold 11px sans-serif';
        ctx.fillText('Press [G] Lower', tractorX - 110, implY - 43);
      } else if (currentScene.id === 3) {
        // SCENE 3: TILLING SOIL & SOWING WHEAT
        // Furrows in soil
        ctx.strokeStyle = '#2b160b';
        ctx.lineWidth = 6;
        for (let f = 0; f < 8; f++) {
          const fy = h * 0.65 + f * 18;
          ctx.beginPath();
          ctx.moveTo(0, fy);
          ctx.lineTo(w, fy);
          ctx.stroke();
        }

        // Dust clouds rising from blades
        for (let d = 0; d < 6; d++) {
          const dustX = w * 0.3 + (d * 25) - ((time * 80) % 150);
          const dustY = h * 0.72 - (d * 5);
          ctx.fillStyle = 'rgba(120, 82, 47, 0.45)';
          ctx.beginPath();
          ctx.arc(dustX, dustY, 12 + d * 3, 0, Math.PI * 2);
          ctx.fill();
        }

        // Sowing seed sparkles
        ctx.fillStyle = '#fef08a';
        for (let s = 0; s < 12; s++) {
          const sx = (time * 120 + s * 35) % w;
          const sy = h * 0.76 + (s % 3) * 12;
          ctx.fillRect(sx, sy, 4, 4);
        }

        // Notification badge
        ctx.fillStyle = 'rgba(22, 101, 52, 0.9)';
        ctx.roundRect(30, 25, 230, 48, 10);
        ctx.fill();
        ctx.fillStyle = '#86efac';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('FIELD PREPARED: 100%', 45, 45);
        ctx.fillStyle = '#ffffff';
        ctx.font = '11px sans-serif';
        ctx.fillText('Golden Wheat Seeds Sown', 45, 62);
      } else if (currentScene.id === 4) {
        // SCENE 4: TUBE WELL RUNNING WITH FRESH WATER
        const pumpX = w * 0.35;
        const pumpY = h * 0.55;

        // Brick Room
        ctx.fillStyle = '#b45309';
        ctx.fillRect(pumpX - 70, pumpY - 45, 80, 75);
        ctx.fillStyle = '#78350f';
        ctx.fillRect(pumpX - 45, pumpY - 15, 30, 45);

        // Concrete Houz (Pool)
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(pumpX + 15, pumpY + 5, 110, 50);

        // Gushing Water Stream from Big Iron Pipe
        ctx.fillStyle = '#38bdf8';
        ctx.fillRect(pumpX - 10, pumpY - 5, 35, 14); // Pipe

        // Splashing Water Arc
        ctx.strokeStyle = '#67e8f9';
        ctx.lineWidth = 12;
        ctx.beginPath();
        ctx.moveTo(pumpX + 25, pumpY + 2);
        ctx.quadraticCurveTo(pumpX + 60, pumpY - 10, pumpX + 80, pumpY + 22);
        ctx.stroke();

        // Water ripple in pool
        ctx.fillStyle = '#0284c7';
        ctx.fillRect(pumpX + 20, pumpY + 18, 100, 32);

        // Water Drops Splash
        for (let drop = 0; drop < 10; drop++) {
          const dropX = pumpX + 80 + Math.sin(time * 8 + drop) * 16;
          const dropY = pumpY + 18 - Math.abs(Math.cos(time * 10 + drop)) * 18;
          ctx.fillStyle = '#e0f2fe';
          ctx.beginPath();
          ctx.arc(dropX, dropY, 3.5, 0, Math.PI * 2);
          ctx.fill();
        }

        // Irrigation Watercourse (Khaal) running across fields
        ctx.fillStyle = '#0284c7';
        ctx.beginPath();
        ctx.moveTo(pumpX + 125, pumpY + 30);
        ctx.lineTo(w, pumpY + 45);
        ctx.lineTo(w, pumpY + 68);
        ctx.lineTo(pumpX + 125, pumpY + 50);
        ctx.fill();
      } else if (currentScene.id === 5) {
        // SCENE 5: GOLDEN WHEAT & HARVESTING
        // Ripe Wheat Stalks
        for (let x = 10; x < w; x += 18) {
          const stalkH = 45 + Math.sin(x + time * 4) * 8;
          ctx.strokeStyle = '#ca8a04';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.moveTo(x, h * 0.75);
          ctx.lineTo(x + Math.sin(time * 3 + x) * 6, h * 0.75 - stalkH);
          ctx.stroke();

          // Golden Ear / Baali
          ctx.fillStyle = '#facc15';
          ctx.beginPath();
          ctx.ellipse(x + Math.sin(time * 3 + x) * 6, h * 0.75 - stalkH - 4, 5, 10, 0.2, 0, Math.PI * 2);
          ctx.fill();
        }

        // Pakistani High-Cage Trolley
        const trolX = w * 0.55;
        const trolY = h * 0.65;
        ctx.fillStyle = '#1d4ed8'; // Blue body
        ctx.fillRect(trolX, trolY - 40, 110, 50);
        // Yellow steel cage pipes (Jalli)
        ctx.strokeStyle = '#facc15';
        ctx.lineWidth = 2.5;
        for (let p = trolX; p <= trolX + 110; p += 15) {
          ctx.beginPath();
          ctx.moveTo(p, trolY - 65);
          ctx.lineTo(p, trolY - 40);
          ctx.stroke();
        }
        ctx.beginPath();
        ctx.moveTo(trolX, trolY - 65);
        ctx.lineTo(trolX + 110, trolY - 65);
        ctx.stroke();

        // Heaped Golden Grain inside trolley
        ctx.fillStyle = '#fef08a';
        ctx.beginPath();
        ctx.ellipse(trolX + 55, trolY - 50, 48, 16, 0, 0, Math.PI * 2);
        ctx.fill();

        // Trolley Wheels
        ctx.fillStyle = '#0f172a';
        ctx.beginPath();
        ctx.arc(trolX + 30, trolY + 18, 22, 0, Math.PI * 2);
        ctx.arc(trolX + 80, trolY + 18, 22, 0, Math.PI * 2);
        ctx.fill();
      } else if (currentScene.id === 6) {
        // SCENE 6: GHALLA MANDI MARKET & SELLING FOR CASH
        // Mandi Arch Gate
        ctx.fillStyle = '#047857';
        ctx.fillRect(50, h * 0.38, 22, 140);
        ctx.fillRect(230, h * 0.38, 22, 140);
        ctx.fillStyle = '#065f46';
        ctx.fillRect(40, h * 0.38, 225, 30);
        ctx.fillStyle = '#facc15';
        ctx.font = 'black 14px sans-serif';
        ctx.fillText('GHALLA MANDI (غلہ منڈی)', 65, h * 0.38 + 20);

        // Money falling animation
        for (let m = 0; m < 8; m++) {
          const my = ((time * 60 + m * 45) % (h * 0.7));
          const mx = w * 0.6 + Math.sin(time * 3 + m) * 45;
          ctx.fillStyle = '#10b981';
          ctx.roundRect(mx, my, 32, 18, 4);
          ctx.fill();
          ctx.fillStyle = '#ffffff';
          ctx.font = 'bold 9px sans-serif';
          ctx.fillText('Rs.', mx + 4, my + 12);
        }

        // Big Cash Earning Banner
        ctx.fillStyle = 'rgba(15, 23, 42, 0.9)';
        ctx.roundRect(w * 0.5, 30, 220, 85, 14);
        ctx.fill();
        ctx.strokeStyle = '#10b981';
        ctx.lineWidth = 2;
        ctx.stroke();
        ctx.fillStyle = '#34d399';
        ctx.font = 'bold 12px sans-serif';
        ctx.fillText('HARVEST SOLD!', w * 0.5 + 16, 52);
        ctx.fillStyle = '#ffffff';
        ctx.font = 'black 22px sans-serif';
        ctx.fillText('+ Rs. 185,000', w * 0.5 + 16, 80);
        ctx.fillStyle = '#94a3b8';
        ctx.font = '10px sans-serif';
        ctx.fillText('Tractor Upgrade Unlocked: Fiat 640', w * 0.5 + 16, 100);
      }

      animFrameRef.current = requestAnimationFrame(render);
    };

    render();

    return () => {
      cancelAnimationFrame(animFrameRef.current);
    };
  }, [isOpen, currentScene.id, activeTab]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/90 p-2 sm:p-4 backdrop-blur-lg font-sans">
      <div className="flex flex-col w-full max-w-4xl h-[92vh] max-h-[820px] rounded-3xl border border-amber-600/40 bg-stone-900 shadow-2xl overflow-hidden">
        {/* Header Bar */}
        <div className="flex items-center justify-between border-b border-stone-800 bg-stone-950/80 px-4 sm:px-6 py-3.5">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white shadow-md">
              <Film className="h-6 w-6" />
            </div>
            <div>
              <h2 className="text-base sm:text-lg font-black text-white flex items-center gap-2">
                Pakistan Farming Simulator — Video Demo & Guide
              </h2>
              <p className="text-xs text-amber-300 font-semibold">
                گیم کھیلنے کا طریقہ اور مکمل ویڈیو ڈیمو
              </p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            {/* Tab switch */}
            <div className="flex rounded-xl bg-stone-800 p-1 border border-stone-700">
              <button
                onClick={() => {
                  sound.playUIClick();
                  setActiveTab('video');
                }}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                  activeTab === 'video'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <Play className="h-3.5 w-3.5 fill-current" />
                <span>Video Demo (ویڈیو)</span>
              </button>
              <button
                onClick={() => {
                  sound.playUIClick();
                  setActiveTab('guide');
                }}
                className={`flex items-center gap-1.5 rounded-lg px-3 py-1.5 text-xs font-bold transition-all ${
                  activeTab === 'guide'
                    ? 'bg-emerald-600 text-white shadow'
                    : 'text-stone-300 hover:text-white'
                }`}
              >
                <HelpCircle className="h-3.5 w-3.5" />
                <span>Written Guide (تحریری گائیڈ)</span>
              </button>
            </div>

            <button
              onClick={onClose}
              className="flex h-9 w-9 items-center justify-center rounded-xl border border-stone-700 bg-stone-800 text-stone-400 hover:bg-stone-700 hover:text-white transition-colors"
            >
              <X className="h-5 w-5" />
            </button>
          </div>
        </div>

        {/* Content Area */}
        {activeTab === 'video' ? (
          <div className="flex-1 flex flex-col overflow-hidden bg-stone-950">
            {/* Video Canvas Display */}
            <div className="relative flex-1 bg-stone-950 overflow-hidden flex items-center justify-center">
              <canvas
                ref={canvasRef}
                width={800}
                height={450}
                className="w-full h-full object-contain"
              />

              {/* Top Scene Pill Overlay */}
              <div className="absolute top-3 left-4 flex items-center gap-2">
                <span className="rounded-full bg-amber-500/90 px-3 py-1 text-xs font-black text-stone-950 shadow-md backdrop-blur-sm">
                  {currentScene.badge}
                </span>
                <span className="rounded-full bg-stone-900/80 px-3 py-1 text-xs font-bold text-white border border-stone-700 backdrop-blur-sm">
                  Scene {currentSceneIndex + 1} of {DEMO_SCENES.length}
                </span>
              </div>

              {/* Sound Mute Toggle */}
              <button
                onClick={() => setIsAudioMuted(!isAudioMuted)}
                className="absolute top-3 right-4 flex h-9 w-9 items-center justify-center rounded-full bg-stone-900/80 text-white border border-stone-700 hover:bg-stone-800 backdrop-blur-sm"
              >
                {isAudioMuted ? <VolumeX className="h-4 w-4" /> : <Volume2 className="h-4 w-4 text-emerald-400" />}
              </button>

              {/* Subtitles Overlay */}
              <div className="absolute bottom-4 inset-x-4 mx-auto max-w-2xl rounded-2xl bg-stone-950/85 p-3 sm:p-4 text-center border border-amber-500/30 backdrop-blur-md shadow-2xl">
                <p className="text-sm sm:text-base font-bold text-amber-300 leading-relaxed dir-rtl" dir="rtl">
                  {currentScene.descriptionUr}
                </p>
                <p className="mt-1 text-xs text-stone-300 leading-normal">
                  {currentScene.descriptionEn}
                </p>
              </div>
            </div>

            {/* Video Player Timeline & Controls Bar */}
            <div className="border-t border-stone-800 bg-stone-900 p-3 sm:p-4">
              {/* Timeline Progress Bar */}
              <div className="w-full h-2 bg-stone-800 rounded-full overflow-hidden mb-3 cursor-pointer">
                <div
                  className="h-full bg-gradient-to-r from-emerald-500 to-amber-500 transition-all duration-75"
                  style={{ width: `${progress}%` }}
                />
              </div>

              <div className="flex items-center justify-between">
                {/* Left: Play/Pause, Prev, Next */}
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => {
                      setCurrentSceneIndex((prev) => (prev > 0 ? prev - 1 : DEMO_SCENES.length - 1));
                      setProgress(0);
                    }}
                    className="p-2 rounded-xl bg-stone-800 text-stone-300 hover:bg-stone-700 hover:text-white transition-colors"
                    title="Previous Scene"
                  >
                    <ChevronLeft className="h-5 w-5" />
                  </button>

                  <button
                    onClick={() => setIsPlaying(!isPlaying)}
                    className="flex h-10 w-10 items-center justify-center rounded-xl bg-emerald-600 text-white hover:bg-emerald-500 shadow-md transition-all active:scale-95"
                  >
                    {isPlaying ? <Pause className="h-5 w-5 fill-current" /> : <Play className="h-5 w-5 fill-current" />}
                  </button>

                  <button
                    onClick={() => {
                      setCurrentSceneIndex((prev) => (prev + 1) % DEMO_SCENES.length);
                      setProgress(0);
                    }}
                    className="p-2 rounded-xl bg-stone-800 text-stone-300 hover:bg-stone-700 hover:text-white transition-colors"
                    title="Next Scene"
                  >
                    <ChevronRight className="h-5 w-5" />
                  </button>

                  <div className="ml-2 hidden sm:block">
                    <div className="text-xs font-bold text-white">
                      {currentScene.titleEn}
                    </div>
                    <div className="text-[11px] text-amber-300 font-semibold">
                      {currentScene.titleUr}
                    </div>
                  </div>
                </div>

                {/* Center: Key Action badges for this step */}
                <div className="hidden md:flex items-center gap-1.5 overflow-x-auto max-w-sm">
                  {currentScene.instructions.map((inst, i) => (
                    <div
                      key={i}
                      className="flex items-center gap-1 rounded-lg bg-stone-950 px-2 py-1 border border-stone-800 text-[10px] text-stone-300 whitespace-nowrap"
                    >
                      <kbd className="rounded bg-amber-500 px-1 py-0.5 font-bold text-stone-950 font-mono">
                        {inst.key}
                      </kbd>
                      <span>{inst.action}</span>
                    </div>
                  ))}
                </div>

                {/* Right: Chapter selector buttons */}
                <div className="flex items-center gap-1">
                  {DEMO_SCENES.map((scene, idx) => (
                    <button
                      key={scene.id}
                      onClick={() => {
                        setCurrentSceneIndex(idx);
                        setProgress(0);
                      }}
                      className={`h-7 px-2.5 rounded-lg text-xs font-bold transition-all ${
                        currentSceneIndex === idx
                          ? 'bg-amber-500 text-stone-950 shadow'
                          : 'bg-stone-800 text-stone-400 hover:bg-stone-700 hover:text-white'
                      }`}
                    >
                      {idx + 1}
                    </button>
                  ))}

                  {onStartGame && (
                    <button
                      onClick={() => {
                        onClose();
                        onStartGame();
                      }}
                      className="ml-2 hidden sm:flex items-center gap-1.5 rounded-xl bg-emerald-600 px-3.5 py-2 text-xs font-bold text-white hover:bg-emerald-500 shadow transition-all"
                    >
                      <span>Play Now</span>
                      <ArrowRight className="h-3.5 w-3.5" />
                    </button>
                  )}
                </div>
              </div>
            </div>
          </div>
        ) : (
          /* Written Gameplay Guide Tab */
          <div className="flex-1 overflow-y-auto p-4 sm:p-6 space-y-6 text-stone-200">
            {/* Big Intro Banner */}
            <div className="rounded-2xl bg-gradient-to-r from-emerald-900/60 to-amber-900/60 p-5 border border-amber-500/30">
              <h3 className="text-xl font-black text-white flex items-center gap-2">
                <Tractor className="h-6 w-6 text-amber-400" />
                پاکستان فارمنگ سمولیٹر کھیلنے کا مکمل طریقہ (Gameplay Manual)
              </h3>
              <p className="mt-1 text-xs sm:text-sm text-stone-300">
                یہ ایک مکمل 3D پاکستانی دیہاتی زراعت کا کھیل ہے۔ اس میں آپ گندم، چاول اور کماد کاشت کریں گے، ٹیوب ویل کا پانی لگائیں گے، جانور پالیں گے اور غلہ منڈی میں فصل بیچ کر امیر زمیندار بنیں گے۔
              </p>
            </div>

            {/* Step-by-Step 6 Stages */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {/* Step 1 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">1</span>
                  ٹریکٹر چلانا اور ہینڈلنگ (Tractor Driving)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li><strong>ٹریکٹر میں بیٹھنا:</strong> ٹریکٹر کے پاس جا کر کی بورڈ پر <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">E</kbd> دبائیں (یا موبائل پر اسٹیرنگ آئیکون)۔</li>
                  <li><strong>ریس اور بریک:</strong> آگے جانے کے لیے <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">W</kbd> یا <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">Up Arrow</kbd>، پیچھے اور بریک کے لیے <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">S</kbd>۔</li>
                  <li><strong>موڑنا (Steering):</strong> دائیں بائیں مڑنے کے لیے <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">A</kbd> اور <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">D</kbd>۔</li>
                  <li><strong>ہارن:</strong> دیسی ٹرک ہارن بجانے کے لیے <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">H</kbd> دبائیں۔</li>
                </ul>
              </div>

              {/* Step 2 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">2</span>
                  زرعی اوزار اور ہل جوڑنا (Hitching Implements)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li>اوپر دائیں طرف <strong>"Farm Menu"</strong> کھولیں اور <strong>Machinery</strong> ٹیب منتخب کریں۔</li>
                  <li><strong>ہل (Plough / Cultivator):</strong> زمین کو چیرنے اور الٹنے کے لیے۔</li>
                  <li><strong>روٹاویدر (Rotavator):</strong> ڈھیلے توڑ کر باریک مٹی بنانے کے لیے۔</li>
                  <li><strong>اوزار اوپر نیچے کرنا:</strong> ٹریکٹر میں بیٹھ کر <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">G</kbd> دبائیں تاکہ ہل زمین میں اتر جائے۔</li>
                </ul>
              </div>

              {/* Step 3 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">3</span>
                  زمین کی تیاری اور بوائی (Field Preparation & Seeding)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li>ہل نیچے کر کے کھیت میں سیدھی لائنوں میں ٹریکٹر چلائیں۔ زمین ہل چل کر سیاڑھوں (Furrows) میں تبدیل ہو جائے گی۔</li>
                  <li>مینو سے <strong>Seed Drill</strong> جوڑیں اور پسندیدہ فصل منتخب کریں (گندم، باسمتی چاول، کپاس یا کماد)۔</li>
                  <li>کھیت کے اوپر بیج ڈرل چلائیں، بیج بونا 100% ہو جائے گا۔</li>
                </ul>
              </div>

              {/* Step 4 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">4</span>
                  ٹیوب ویل سے پانی لگانا (Tube Well Irrigation)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li>کھیتوں کے پاس پکے کوٹھے (Tube Well Pump) کے پاس جائیں۔</li>
                  <li>کی بورڈ پر <kbd className="bg-stone-800 px-1 rounded text-amber-300 font-mono">F</kbd> دبائیں یا اسکرین پر پانی کے آئیکون کو دبائیں۔</li>
                  <li>پیٹر انجن اسٹارٹ ہو جائے گا، حوض میں پانی گرے گا اور کھال کے ذریعے کھیتوں کی نمی (Moisture) 100% ہو جائے گی۔ پانی ملنے سے فصل تیزی سے پکے گی۔</li>
                </ul>
              </div>

              {/* Step 5 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">5</span>
                  فصل کی کٹائی اور ٹرالی بھرنا (Harvest & Trolley)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li>جب کھیت کا اسٹیٹس <strong>"Ripe / Mature"</strong> ہو جائے تو مینو سے ہارویسٹر یا کٹر جوڑیں۔</li>
                  <li>کھیت پر کٹر چلا کر ساری فصل کاٹیں۔</li>
                  <li>پھر مینو سے <strong>Pakistani Farm Trolley</strong> جوڑیں اور کٹی ہوئی فصل ٹرالی میں لوڈ کریں۔ اسکرین پر ٹرالی کا وزن (مثلاً 5,000 کلوگرام گندم) ظاہر ہو جائے گا۔</li>
                </ul>
              </div>

              {/* Step 6 */}
              <div className="rounded-2xl border border-stone-800 bg-stone-950/60 p-4">
                <div className="flex items-center gap-2 font-black text-amber-400 text-sm mb-2">
                  <span className="flex h-6 w-6 items-center justify-center rounded-full bg-amber-500 text-stone-950 text-xs font-black">6</span>
                  غلہ منڈی میں مال بیچنا اور نئے ٹریکٹر (Sell at Mandi)
                </div>
                <ul className="text-xs text-stone-300 space-y-1.5 list-disc list-inside">
                  <li>ٹرالی بھر کر سڑک کے راستے <strong>غلہ منڈی (Ghalla Mandi)</strong> کے کانٹے پر لے جائیں۔</li>
                  <li><strong>"Sell Crop"</strong> دبائیں اور موقع پر کیش روپے وصول کریں۔</li>
                  <li>کمائے گئے پیسوں سے نیا <strong>Fiat 640</strong>، <strong>Belarus 820</strong> یا زیادہ ایکڑ رقبہ ان لاک کریں!</li>
                </ul>
              </div>
            </div>

            {/* Livestock Bonus */}
            <div className="rounded-2xl border border-emerald-500/30 bg-emerald-950/30 p-4">
              <h4 className="text-sm font-bold text-emerald-400 mb-1">
                ڈیری حویلی اور مویشی (Cattle Farm & Haveli)
              </h4>
              <p className="text-xs text-stone-300">
                حویلی کے باڑے میں نیلی راوی بھینسوں اور ساہیوال گائے کو چارہ ڈالیں اور روزانہ خالص دودھ اور دیسی انڈے کلیکٹ کر کے اضافی منافع کمائیں۔
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
