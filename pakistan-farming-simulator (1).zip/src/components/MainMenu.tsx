import React, { useState } from 'react';
import { Play, RotateCcw, BookOpen, Tractor, Film, Smartphone, Sparkles, X } from 'lucide-react';
import { sound } from '../audio/SoundEngine';

interface MainMenuProps {
  hasSaveData: boolean;
  onNewGame: () => void;
  onContinue: () => void;
  onOpenVideoDemo: () => void;
}

export const MainMenu: React.FC<MainMenuProps> = ({
  hasSaveData,
  onNewGame,
  onContinue,
  onOpenVideoDemo
}) => {
  const [showHowToPlay, setShowHowToPlay] = useState(false);

  return (
    <div className="absolute inset-0 z-40 flex items-center justify-center bg-stone-950/85 p-3 sm:p-4 backdrop-blur-md font-sans select-none">
      <div className="w-full max-w-xl overflow-hidden rounded-3xl border border-amber-500/50 bg-stone-900 shadow-2xl">
        {/* Banner */}
        <div className="relative bg-gradient-to-r from-emerald-800 via-emerald-900 to-amber-900 p-6 sm:p-8 text-center border-b border-amber-500/30">
          <div className="mx-auto mb-3 flex h-16 w-16 items-center justify-center rounded-2xl bg-gradient-to-br from-amber-400 to-amber-600 text-stone-950 shadow-xl">
            <Tractor className="h-10 w-10" />
          </div>

          <h1 className="text-2xl sm:text-4xl font-black tracking-tight text-white drop-shadow-md">
            Pakistan Farming Simulator
          </h1>
          <p className="mt-1 text-sm font-bold text-amber-300">
            اصلی دیسی کاشتکاری گیم (Mobile & Touch Laptop Ready)
          </p>
          <p className="mt-2 text-xs sm:text-sm text-emerald-100 max-w-md mx-auto">
            Millat MF 385 tractor chalayein, Peter engine tube well se paani lagayein, faslein beejain aur Mandi me bech kr ameer banein!
          </p>
        </div>

        {/* Buttons in Roman Urdu */}
        <div className="p-5 sm:p-7 space-y-3 bg-stone-900">
          {/* Direct Play Button for Mobile & Touch Laptop */}
          <button
            type="button"
            onClick={() => {
              sound.playUIClick();
              if (hasSaveData) {
                onContinue();
              } else {
                onNewGame();
              }
            }}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-emerald-600 to-emerald-500 py-3.5 sm:py-4 text-base sm:text-lg font-black text-white shadow-xl transition-all hover:from-emerald-500 hover:to-emerald-400 active:scale-95 border border-emerald-400/50"
          >
            <Smartphone className="h-6 w-6 text-amber-300" />
            <span>Abhi Game Khelein (Mobile / Touch Play)</span>
          </button>

          {/* Video Demo Button */}
          <button
            type="button"
            onClick={() => {
              sound.playUIClick();
              onOpenVideoDemo();
            }}
            className="flex w-full items-center justify-center gap-3 rounded-2xl bg-gradient-to-r from-amber-500 to-amber-600 py-3.5 text-base font-black text-stone-950 shadow-xl transition-all hover:from-amber-400 hover:to-amber-500 active:scale-95 border border-amber-300"
          >
            <Film className="h-5 w-5" />
            <span>Video Demo Dekhein (Khelne Ka Treeka)</span>
          </button>

          {/* How to Play Manual in Roman Urdu */}
          <button
            type="button"
            onClick={() => {
              sound.playUIClick();
              setShowHowToPlay(true);
            }}
            className="flex w-full items-center justify-center gap-2 rounded-2xl bg-stone-800 border border-stone-700 py-3 text-sm font-bold text-stone-200 transition-all hover:bg-stone-700 active:scale-95"
          >
            <BookOpen className="h-4 w-4 text-emerald-400" />
            <span>Game Khelne Ka Mukammal Treeka (Guide)</span>
          </button>

          {hasSaveData && (
            <button
              type="button"
              onClick={() => {
                sound.playUIClick();
                onNewGame();
              }}
              className="flex w-full items-center justify-center gap-2 rounded-2xl bg-stone-800/60 border border-stone-700/60 py-2.5 text-xs font-semibold text-stone-400 hover:text-white transition-all"
            >
              <RotateCcw className="h-3.5 w-3.5 text-amber-400" />
              <span>Naya Khel Shuru Karein (New Game)</span>
            </button>
          )}
        </div>
      </div>

      {/* How to Play Modal - Pure Simple Roman Urdu */}
      {showHowToPlay && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-stone-950/90 p-4 backdrop-blur-md select-text">
          <div className="w-full max-w-2xl rounded-2xl border border-amber-500/40 bg-stone-900 p-5 sm:p-6 shadow-2xl text-white max-h-[85vh] overflow-y-auto">
            <div className="flex items-center justify-between border-b border-stone-700 pb-3">
              <h2 className="text-lg sm:text-xl font-black flex items-center gap-2 text-emerald-400">
                <BookOpen className="h-6 w-6 text-amber-400" />
                Game Khelne Ka Asaan Tareeqa
              </h2>
              <button
                onClick={() => setShowHowToPlay(false)}
                className="rounded-lg p-1.5 text-stone-400 hover:bg-stone-800 hover:text-white"
              >
                <X className="h-5 w-5" />
              </button>
            </div>

            <div className="mt-4 space-y-3.5 text-xs sm:text-sm text-stone-300">
              <div className="rounded-xl bg-stone-950/70 p-3.5 border border-stone-800">
                <span className="font-black text-amber-400 text-sm">1. Mobile ya Touch Laptop pe Chalana:</span>
                <p className="mt-1 text-stone-300 leading-relaxed">
                  - <strong>Race (ریس):</strong> Screen pe green button daba kr rakho, tractor aage chalega.<br />
                  - <strong>Brake / Reverse (بریک):</strong> Red pedal dabaoge to tractor rukega or peechay chalega.<br />
                  - <strong>Steering (موڑنا):</strong> Left pe bani Joystick se ya bائیں/دائیں button se tractor ghuma sakte ho.<br />
                  - <strong>Camera 360:</strong> Screen k darmiyan me ungli ya touch pen se swipe kro, camera chaaron taraf ghoomega.
                </p>
              </div>

              <div className="rounded-xl bg-stone-950/70 p-3.5 border border-stone-800">
                <span className="font-black text-amber-400 text-sm">2. Laptop Keyboard se Chalana:</span>
                <p className="mt-1 text-stone-300 leading-relaxed">
                  - <strong>W:</strong> Aage chalana (Race)<br />
                  - <strong>S:</strong> Brake lagana ya peechay krna<br />
                  - <strong>A / D:</strong> Left ya Right murna<br />
                  - <strong>E:</strong> Tractor me baithna ya utarna<br />
                  - <strong>H:</strong> Desi Truck Horn bajana<br />
                  - <strong>F:</strong> Tube well chalana ya mandi me fasal bechna
                </p>
              </div>

              <div className="rounded-xl bg-stone-950/70 p-3.5 border border-stone-800">
                <span className="font-black text-amber-400 text-sm">3. Khet me Hal Chalana aur Beej Bona:</span>
                <p className="mt-1 text-stone-300 leading-relaxed">
                  Top right pe <strong>Farm Menu</strong> kholo, <strong>Machinery</strong> me ja kr Hal (Plough) jodo. Hal ka button (V) daba kr hal zameen me utaro or khet me tractor chalao. Mitti naram ho jaye gi to Seed Drill se Gandum (Wheat) ya Chawal bo do!
                </p>
              </div>

              <div className="rounded-xl bg-stone-950/70 p-3.5 border border-stone-800">
                <span className="font-black text-amber-400 text-sm">4. Tube Well ka Paani Lagana:</span>
                <p className="mt-1 text-stone-300 leading-relaxed">
                  Khet k kone me Tube Well k kamre k paas jao or <strong>Kaam (F)</strong> ka button dabao. Peter engine thak thak chalega or thanda paani khet me behna shuru ho jayega.
                </p>
              </div>

              <div className="rounded-xl bg-stone-950/70 p-3.5 border border-stone-800">
                <span className="font-black text-amber-400 text-sm">5. Fasal Kaatna or Mandi me Bechna:</span>
                <p className="mt-1 text-stone-300 leading-relaxed">
                  Jab fasal sunhari pak jaye to Harvester se kaato, Trolley me bharo or Ghala Mandi ja kr becho, lakhoon rupay kamao!
                </p>
              </div>
            </div>

            <button
              onClick={() => setShowHowToPlay(false)}
              className="mt-5 w-full rounded-xl bg-emerald-600 py-3 text-sm font-bold text-white transition-all hover:bg-emerald-500 shadow-lg"
            >
              Theek Hai, Main Samajh Gaya (Close)
            </button>
          </div>
        </div>
      )}
    </div>
  );
};
