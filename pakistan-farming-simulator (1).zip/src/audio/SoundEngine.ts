/**
 * Web Audio procedural sound synthesizer for Pakistani Farming Simulator.
 * Produces realistic diesel tractor engine sounds, horn, tube well water pump,
 * ambient rural village sounds (birds, wind, rain), and gameplay audio.
 */

class SoundEngine {
  private ctx: AudioContext | null = null;
  private masterGain: GainNode | null = null;
  private isMuted: boolean = false;

  // Engine Audio nodes
  private engineRunning: boolean = false;
  private engineGain: GainNode | null = null;
  private engineOsc: OscillatorNode | null = null;
  private engineOsc2: OscillatorNode | null = null;
  private engineNoiseNode: AudioNode | null = null;

  // Pump Audio nodes
  private pumpRunning: boolean = false;
  private pumpGain: GainNode | null = null;
  private pumpTimer: number | null = null;

  // Ambience
  private ambientGain: GainNode | null = null;
  private rainNoiseNode: AudioNode | null = null;
  private rainGain: GainNode | null = null;

  public init() {
    if (this.ctx) return;
    try {
      const AudioCtx = window.AudioContext || (window as unknown as { webkitAudioContext: typeof AudioContext }).webkitAudioContext;
      this.ctx = new AudioCtx();
      this.masterGain = this.ctx.createGain();
      this.masterGain.gain.setValueAtTime(0.7, this.ctx.currentTime);
      this.masterGain.connect(this.ctx.destination);
      this.startAmbience();
    } catch {
      // Audio context might require user gesture
    }
  }

  public ensureContext() {
    if (!this.ctx) {
      this.init();
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume();
    }
  }

  public toggleMute(): boolean {
    this.isMuted = !this.isMuted;
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(this.isMuted ? 0 : 0.7, this.ctx.currentTime);
    }
    return this.isMuted;
  }

  public setVolume(volume: number) {
    if (this.masterGain && this.ctx) {
      this.masterGain.gain.setValueAtTime(Math.max(0, Math.min(1, volume)), this.ctx.currentTime);
    }
  }

  public isSoundMuted(): boolean {
    return this.isMuted;
  }

  // --- TRACTOR ENGINE ---
  public startTractorEngine() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain || this.engineRunning) return;

    this.engineRunning = true;
    const now = this.ctx.currentTime;

    this.engineGain = this.ctx.createGain();
    this.engineGain.gain.setValueAtTime(0.01, now);
    this.engineGain.gain.exponentialRampToValueAtTime(0.22, now + 0.3);
    this.engineGain.connect(this.masterGain);

    // Primary low thumping cylinder tone (Massey Ferguson 385 4-cylinder rumble)
    this.engineOsc = this.ctx.createOscillator();
    this.engineOsc.type = 'sawtooth';
    this.engineOsc.frequency.setValueAtTime(42, now); // Idle ~ 650 RPM

    // Secondary sub-harmonic
    this.engineOsc2 = this.ctx.createOscillator();
    this.engineOsc2.type = 'triangle';
    this.engineOsc2.frequency.setValueAtTime(28, now);

    // Filter to simulate diesel engine block resonance
    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(220, now);
    filter.Q.setValueAtTime(4, now);

    this.engineOsc.connect(filter);
    this.engineOsc2.connect(filter);
    filter.connect(this.engineGain);

    this.engineOsc.start();
    this.engineOsc2.start();
  }

  public updateTractorRPM(speedRatio: number, isAccelerating: boolean) {
    if (!this.ctx || !this.engineRunning || !this.engineOsc || !this.engineOsc2) return;
    const now = this.ctx.currentTime;
    
    // Idle 40Hz, Max speed/rev 120Hz
    const targetFreq = 42 + speedRatio * 65 + (isAccelerating ? 20 : 0);
    this.engineOsc.frequency.setTargetAtTime(targetFreq, now, 0.1);
    this.engineOsc2.frequency.setTargetAtTime(targetFreq * 0.65, now, 0.1);

    if (this.engineGain) {
      const targetGain = 0.18 + speedRatio * 0.12 + (isAccelerating ? 0.06 : 0);
      this.engineGain.gain.setTargetAtTime(targetGain, now, 0.1);
    }
  }

  public stopTractorEngine() {
    if (!this.ctx || !this.engineRunning) return;
    this.engineRunning = false;
    const now = this.ctx.currentTime;

    if (this.engineGain) {
      this.engineGain.gain.exponentialRampToValueAtTime(0.001, now + 0.3);
      setTimeout(() => {
        try {
          this.engineOsc?.stop();
          this.engineOsc2?.stop();
          this.engineOsc?.disconnect();
          this.engineOsc2?.disconnect();
          this.engineGain?.disconnect();
        } catch {
          // ignore
        }
        this.engineOsc = null;
        this.engineOsc2 = null;
        this.engineGain = null;
      }, 350);
    }
  }

  // --- TRACTOR HORN (Pakistani dual tone truck/tractor style) ---
  public playTractorHorn() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    const osc1 = this.ctx.createOscillator();
    const osc2 = this.ctx.createOscillator();
    const hornGain = this.ctx.createGain();

    osc1.type = 'sawtooth';
    osc2.type = 'sawtooth';

    osc1.frequency.setValueAtTime(370, now); // F#4
    osc2.frequency.setValueAtTime(466, now); // A#4

    hornGain.gain.setValueAtTime(0.28, now);
    hornGain.gain.exponentialRampToValueAtTime(0.001, now + 0.6);

    osc1.connect(hornGain);
    osc2.connect(hornGain);
    hornGain.connect(this.masterGain);

    osc1.start(now);
    osc2.start(now);
    osc1.stop(now + 0.65);
    osc2.stop(now + 0.65);
  }

  // --- TUBE WELL PUMP SOUND (Peter Engine "dhuk dhuk dhuk" & water splash) ---
  public setTubeWellState(running: boolean) {
    this.ensureContext();
    if (running === this.pumpRunning) return;
    this.pumpRunning = running;

    if (running) {
      this.startTubeWellLoop();
    } else {
      if (this.pumpTimer) {
        clearInterval(this.pumpTimer);
        this.pumpTimer = null;
      }
    }
  }

  private startTubeWellLoop() {
    if (!this.ctx || !this.masterGain) return;

    // Rhythmic diesel pump stroke every 280ms
    this.pumpTimer = window.setInterval(() => {
      if (!this.pumpRunning || !this.ctx || !this.masterGain) return;
      const now = this.ctx.currentTime;

      // Heavy piston thump
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(65, now);
      osc.frequency.exponentialRampToValueAtTime(30, now + 0.12);

      gain.gain.setValueAtTime(0.25, now);
      gain.gain.exponentialRampToValueAtTime(0.001, now + 0.18);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now);
      osc.stop(now + 0.2);

      // Water splash hiss
      this.playNoisePuff(0.08, 0.15, 600);
    }, 280);
  }

  private playNoisePuff(gainVal: number, duration: number, cutoff: number) {
    if (!this.ctx || !this.masterGain) return;
    const bufferSize = this.ctx.sampleRate * duration;
    const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
    const data = buffer.getChannelData(0);
    for (let i = 0; i < bufferSize; i++) {
      data[i] = Math.random() * 2 - 1;
    }

    const noise = this.ctx.createBufferSource();
    noise.buffer = buffer;

    const filter = this.ctx.createBiquadFilter();
    filter.type = 'lowpass';
    filter.frequency.setValueAtTime(cutoff, this.ctx.currentTime);

    const gain = this.ctx.createGain();
    gain.gain.setValueAtTime(gainVal, this.ctx.currentTime);
    gain.gain.exponentialRampToValueAtTime(0.001, this.ctx.currentTime + duration);

    noise.connect(filter);
    filter.connect(gain);
    gain.connect(this.masterGain);

    noise.start();
  }

  // --- AMBIENT SOUNDS ---
  private startAmbience() {
    if (!this.ctx || !this.masterGain) return;

    // Subtle chirping bird at randomized intervals
    setInterval(() => {
      if (!this.ctx || !this.masterGain || this.isMuted) return;
      if (Math.random() < 0.4) {
        this.playBirdChirp();
      }
    }, 4000);
  }

  public playBirdChirp() {
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();

    osc.type = 'sine';
    const baseFreq = 2200 + Math.random() * 800;
    osc.frequency.setValueAtTime(baseFreq, now);
    osc.frequency.exponentialRampToValueAtTime(baseFreq + 600, now + 0.08);
    osc.frequency.exponentialRampToValueAtTime(baseFreq, now + 0.16);

    gain.gain.setValueAtTime(0.03, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.22);
  }

  public setWeatherAudio(weather: 'sunny' | 'cloudy' | 'rain' | 'storm') {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;

    if (weather === 'rain' || weather === 'storm') {
      if (!this.rainGain) {
        const bufferSize = this.ctx.sampleRate * 2;
        const buffer = this.ctx.createBuffer(1, bufferSize, this.ctx.sampleRate);
        const data = buffer.getChannelData(0);
        for (let i = 0; i < bufferSize; i++) {
          data[i] = Math.random() * 2 - 1;
        }

        const noise = this.ctx.createBufferSource();
        noise.buffer = buffer;
        noise.loop = true;

        const filter = this.ctx.createBiquadFilter();
        filter.type = 'bandpass';
        filter.frequency.setValueAtTime(1200, this.ctx.currentTime);
        filter.Q.setValueAtTime(0.8, this.ctx.currentTime);

        this.rainGain = this.ctx.createGain();
        this.rainGain.gain.setValueAtTime(weather === 'storm' ? 0.15 : 0.08, this.ctx.currentTime);

        noise.connect(filter);
        filter.connect(this.rainGain);
        this.rainGain.connect(this.masterGain);
        noise.start();
        this.rainNoiseNode = noise;
      } else {
        this.rainGain.gain.setValueAtTime(weather === 'storm' ? 0.15 : 0.08, this.ctx.currentTime);
      }
    } else {
      if (this.rainGain) {
        this.rainGain.gain.setValueAtTime(0.001, this.ctx.currentTime);
      }
    }
  }

  // --- GAMEPLAY FX ---
  public playHitchImplement() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    // Heavy metallic clank
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'triangle';
    osc.frequency.setValueAtTime(180, now);
    osc.frequency.exponentialRampToValueAtTime(60, now + 0.15);

    gain.gain.setValueAtTime(0.3, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.2);

    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.25);
    this.playNoisePuff(0.12, 0.08, 1200);
  }

  public playCashRegister() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;

    // 2-tone pleasant coin/cash register chime
    const notes = [987.77, 1318.51]; // B5, E6
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'sine';
      osc.frequency.setValueAtTime(freq, now + idx * 0.1);

      gain.gain.setValueAtTime(0.2, now + idx * 0.1);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.1 + 0.35);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.1);
      osc.stop(now + idx * 0.1 + 0.4);
    });
  }

  public playCropHarvestSound() {
    this.ensureContext();
    // Swishing blade sound
    this.playNoisePuff(0.16, 0.22, 1800);
  }

  public playMissionComplete() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const notes = [523.25, 659.25, 783.99, 1046.50]; // C5, E5, G5, C6
    notes.forEach((freq, idx) => {
      if (!this.ctx || !this.masterGain) return;
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      osc.type = 'triangle';
      osc.frequency.setValueAtTime(freq, now + idx * 0.12);

      gain.gain.setValueAtTime(0.2, now + idx * 0.12);
      gain.gain.exponentialRampToValueAtTime(0.001, now + idx * 0.12 + 0.3);

      osc.connect(gain);
      gain.connect(this.masterGain);
      osc.start(now + idx * 0.12);
      osc.stop(now + idx * 0.12 + 0.35);
    });
  }

  public playUIClick() {
    this.ensureContext();
    if (!this.ctx || !this.masterGain) return;
    const now = this.ctx.currentTime;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = 'sine';
    osc.frequency.setValueAtTime(800, now);
    osc.frequency.exponentialRampToValueAtTime(400, now + 0.04);
    gain.gain.setValueAtTime(0.12, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + 0.05);
    osc.connect(gain);
    gain.connect(this.masterGain);
    osc.start(now);
    osc.stop(now + 0.06);
  }
}

export const sound = new SoundEngine();
