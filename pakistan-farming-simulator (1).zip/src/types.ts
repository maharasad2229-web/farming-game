export type WeatherType = 'sunny' | 'cloudy' | 'rain' | 'storm';

export type TimeOfDay = 'sunrise' | 'day' | 'sunset' | 'night';

export type CropType = 
  | 'wheat'       // Gandam
  | 'rice'        // Basmati Chawal
  | 'sugarcane'   // Kamad
  | 'cotton'      // Kapas
  | 'maize'       // Makki
  | 'potato'      // Aaloo
  | 'onion'       // Pyaz
  | 'tomato'      // Tamatar
  | 'chili'       // Sabz Mirch
  | 'sunflower';  // Surajmukhi

export type SoilState = 'unploughed' | 'ploughed' | 'cultivated' | 'seeded' | 'harvest_ready' | 'harvested';

export type ImplementType = 
  | 'none'
  | 'plough'             // Hal
  | 'cultivator'         // Tiller
  | 'rotavator'          // Rotavator
  | 'seed_drill'         // Seed drill machine
  | 'fertilizer_spreader'// Khaad spreader
  | 'sprayer'            // Spray machine
  | 'harvester_cutter'   // Cutter bar / Harvester head
  | 'trolley';           // Desi Pakistani Trolley

export interface CropInfo {
  id: CropType;
  name: string;
  urduName: string;
  category: 'cereal' | 'cash' | 'vegetable' | 'oilseed';
  seedCostPerAcre: number; // in PKR
  growthTimeSeconds: number; // simulated seconds for a full growth cycle
  waterReq: number; // 0 - 100
  fertReq: number;  // 0 - 100
  baseYieldKg: number;
  baseMarketPricePer40Kg: number; // Maund (40kg) standard in Pakistan
  color: string;
  harvestColor: string;
  description: string;
}

export interface FieldData {
  id: number;
  name: string;
  acres: number;
  unlocked: boolean;
  unlockCost: number;
  bounds: { minX: number; maxX: number; minZ: number; maxZ: number };
  center: { x: number; z: number };
  soilState: SoilState;
  plantedCrop: CropType | null;
  growthProgress: number; // 0 to 100%
  moistureLevel: number; // 0 to 100%
  fertilizerLevel: number; // 0 to 100%
  weedLevel: number; // 0 to 100%
  pestLevel: number; // 0 to 100%
  ploughedPercentage: number;
  cultivatedPercentage: number;
  seededPercentage: number;
  harvestedPercentage: number;
}

export interface MachineryItem {
  id: ImplementType;
  name: string;
  urduName: string;
  price: number;
  owned: boolean;
  workWidth: number; // meters
  description: string;
  workType: 'plough' | 'cultivate' | 'seed' | 'fertilize' | 'spray' | 'harvest' | 'transport';
}

export interface TractorUpgrade {
  level: number;
  enginePowerHp: number; // e.g., 50hp -> 85hp (Millat MF 240 to MF 385)
  fuelTankMax: number;
  speedMax: number;
  name: string;
  upgradeCost: number;
}

export interface AnimalPen {
  id: string;
  type: 'buffalo' | 'cow' | 'goat' | 'chicken';
  name: string;
  urduName: string;
  count: number;
  capacity: number;
  feedLevel: number; // 0 to 100%
  waterLevel: number; // 0 to 100%
  productReady: number; // liters of milk or dozens of eggs
  productType: 'Milk (Liters)' | 'Eggs (Dozen)';
  pricePerUnit: number;
  purchaseCostPerAnimal: number;
}

export interface Mission {
  id: string;
  title: string;
  urduTitle: string;
  description: string;
  rewardMoney: number;
  rewardXp: number;
  completed: boolean;
  type: 'plough' | 'seed' | 'irrigate' | 'harvest' | 'sell' | 'earn' | 'milk' | 'spray';
  targetValue: number;
  currentValue: number;
  targetFieldId?: number;
  cropType?: CropType;
}

export interface MarketPrice {
  crop: CropType;
  currentPricePer40Kg: number; // PKR
  trend: 'up' | 'down' | 'stable';
  changePercent: number;
}

export interface PlayerStats {
  money: number; // PKR
  xp: number;
  level: number;
  farmerTitle: string;
  fuel: number; // Current tractor fuel
  maxFuel: number;
  waterPumpRunning: boolean;
  gameTimeMinutes: number; // Minute 0 to 1440 (24 hours)
  weather: WeatherType;
  temperatureC: number;
  totalCropsSoldKg: number;
  totalEarnedMoney: number;
  fertilizerStockBags: number; // 50kg bags
  seedStockKg: Record<CropType, number>;
  dieselJerryCans: number;
  pesticideBottles: number;
}

export interface GameSaveState {
  version: number;
  lastSaved: number;
  playerStats: PlayerStats;
  fields: FieldData[];
  machinery: MachineryItem[];
  currentImplement: ImplementType;
  tractorUpgradeLevel: number;
  animals: AnimalPen[];
  missions: Mission[];
  trolleyCargo: { crop: CropType | null; amountKg: number };
}
