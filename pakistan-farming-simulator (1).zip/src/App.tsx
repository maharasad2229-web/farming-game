import React, { useEffect, useRef, useState } from 'react';
import confetti from 'canvas-confetti';
import { GameEngine, InteractionPrompt } from './game/GameEngine';
import { HUD } from './components/HUD';
import { TouchControls } from './components/TouchControls';
import { GameMenuModal } from './components/GameMenuModal';
import { MainMenu } from './components/MainMenu';
import { VideoDemoModal } from './components/VideoDemoModal';
import { sound } from './audio/SoundEngine';
import {
  INITIAL_FIELDS,
  INITIAL_MACHINERY,
  INITIAL_ANIMALS,
  INITIAL_MISSIONS,
  CROPS_DATA
} from './game/constants';
import {
  PlayerStats,
  FieldData,
  MachineryItem,
  AnimalPen,
  Mission,
  CropType,
  ImplementType,
  GameSaveState,
  WeatherType
} from './types';

const SAVE_KEY = 'pk_farming_sim_save_v1';

const DEFAULT_PLAYER_STATS: PlayerStats = {
  money: 65000, // PKR starter capital
  xp: 0,
  level: 1,
  farmerTitle: 'Chota Zamindar',
  fuel: 45,
  maxFuel: 45,
  waterPumpRunning: false,
  gameTimeMinutes: 480, // 8:00 AM morning
  weather: 'sunny',
  temperatureC: 32,
  totalCropsSoldKg: 0,
  totalEarnedMoney: 0,
  fertilizerStockBags: 4,
  seedStockKg: {
    wheat: 80,
    rice: 40,
    sugarcane: 20,
    cotton: 20,
    maize: 30,
    potato: 40,
    onion: 20,
    tomato: 20,
    chili: 15,
    sunflower: 25
  },
  dieselJerryCans: 2,
  pesticideBottles: 3
};

export default function App() {
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const engineRef = useRef<GameEngine | null>(null);

  // App & Screen State
  const [gameState, setGameState] = useState<'menu' | 'playing'>('menu');
  const [hasSaveData, setHasSaveData] = useState<boolean>(false);
  const [isMenuOpen, setIsMenuOpen] = useState<boolean>(false);
  const [isVideoDemoOpen, setIsVideoDemoOpen] = useState<boolean>(false);

  // Player & World State
  const [playerStats, setPlayerStats] = useState<PlayerStats>(DEFAULT_PLAYER_STATS);
  const [fields, setFields] = useState<FieldData[]>(INITIAL_FIELDS);
  const [machinery, setMachinery] = useState<MachineryItem[]>(INITIAL_MACHINERY);
  const [currentImplement, setCurrentImplement] = useState<ImplementType>('plough');
  const [selectedCrop, setSelectedCrop] = useState<CropType>('wheat');
  const [animals, setAnimals] = useState<AnimalPen[]>(INITIAL_ANIMALS);
  const [missions, setMissions] = useState<Mission[]>(INITIAL_MISSIONS);
  const [tractorUpgradeLevel, setTractorUpgradeLevel] = useState<number>(1);
  const [trolleyCargo, setTrolleyCargo] = useState<{ crop: CropType | null; amountKg: number }>({
    crop: null,
    amountKg: 0
  });

  // Real-time HUD states
  const [inVehicle, setInVehicle] = useState<boolean>(false);
  const [speed, setSpeed] = useState<number>(0);
  const [gear, setGear] = useState<number>(1);
  const [implementLowered, setImplementLowered] = useState<boolean>(false);
  const [activeField, setActiveField] = useState<FieldData | null>(null);
  const [interactionPrompt, setInteractionPrompt] = useState<InteractionPrompt | null>(null);
  const [cameraMode, setCameraMode] = useState<1 | 2 | 3>(1);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [isTouchControlsVisible, setIsTouchControlsVisible] = useState<boolean>(() => {
    if (typeof window === 'undefined') return false;
    return 'ontouchstart' in window || navigator.maxTouchPoints > 0 || window.innerWidth < 1024;
  });

  // Check saved data on mount
  useEffect(() => {
    try {
      const saved = localStorage.getItem(SAVE_KEY);
      if (saved) {
        setHasSaveData(true);
      }
    } catch {
      // ignore
    }
  }, []);

  // Initialize Game Engine when playing
  useEffect(() => {
    if (gameState !== 'playing' || !canvasRef.current) return;

    const engine = new GameEngine(canvasRef.current, playerStats, fields);
    engineRef.current = engine;

    // Attach callbacks
    engine.onPromptChange = (prompt) => setInteractionPrompt(prompt);

    engine.onStatsUpdate = (newStats) => {
      setPlayerStats((prev) => {
        const updated = { ...prev, ...newStats };
        // Check level progression
        const newLevel = Math.floor(updated.xp / 250) + 1;
        let title = 'Chota Zamindar';
        if (newLevel >= 5) title = 'Malik / Khan Sahib';
        else if (newLevel >= 3) title = 'Numberdar';
        else if (newLevel >= 2) title = 'Wada Kissan';
        updated.level = newLevel;
        updated.farmerTitle = title;
        return updated;
      });
    };

    engine.onFieldUpdate = (updatedField) => {
      setFields((prev) => prev.map((f) => (f.id === updatedField.id ? { ...updatedField } : f)));
    };

    engine.onTrolleyUpdate = (cargo) => {
      setTrolleyCargo({ ...cargo });
    };

    engine.onMissionProgress = (type, amount, fieldId, crop) => {
      setMissions((prev) =>
        prev.map((m) => {
          if (m.completed) return m;
          if (m.type === type) {
            if (m.targetFieldId && fieldId && m.targetFieldId !== fieldId) return m;
            if (m.cropType && crop && m.cropType !== crop) return m;

            const updatedVal = Math.max(m.currentValue, Math.round(amount));
            return { ...m, currentValue: updatedVal };
          }
          return m;
        })
      );
    };

    engine.start();

    // Polling fast telemetry for HUD
    const hudInterval = setInterval(() => {
      if (!engineRef.current) return;
      setInVehicle(engineRef.current.inVehicle);
      setSpeed(engineRef.current.tractorSpeed);
      setGear(engineRef.current.tractorGear);
      setImplementLowered(engineRef.current.implementLowered);
      setCameraMode(engineRef.current.cameraMode);

      // Active field under tractor
      const pos = engineRef.current.inVehicle
        ? engineRef.current.tractorPos
        : engineRef.current.playerPos;

      const currField = engineRef.current.fields.find(
        (f) =>
          f.unlocked &&
          pos.x >= f.bounds.minX &&
          pos.x <= f.bounds.maxX &&
          pos.z >= f.bounds.minZ &&
          pos.z <= f.bounds.maxZ
      );
      setActiveField(currField ? { ...currField } : null);
    }, 100);

    return () => {
      clearInterval(hudInterval);
      engine.destroy();
      engineRef.current = null;
    };
  }, [gameState]);

  // Load Saved Game
  const loadSavedGame = () => {
    try {
      const savedStr = localStorage.getItem(SAVE_KEY);
      if (!savedStr) return;
      const data: GameSaveState = JSON.parse(savedStr);
      setPlayerStats(data.playerStats);
      setFields(data.fields);
      setMachinery(data.machinery);
      setCurrentImplement(data.currentImplement);
      setTractorUpgradeLevel(data.tractorUpgradeLevel);
      setAnimals(data.animals);
      setMissions(data.missions);
      setTrolleyCargo(data.trolleyCargo);
      setGameState('playing');
    } catch {
      setGameState('playing');
    }
  };

  // Start New Game
  const startNewGame = () => {
    setPlayerStats(DEFAULT_PLAYER_STATS);
    setFields(INITIAL_FIELDS);
    setMachinery(INITIAL_MACHINERY);
    setCurrentImplement('plough');
    setTractorUpgradeLevel(1);
    setAnimals(INITIAL_ANIMALS);
    setMissions(INITIAL_MISSIONS);
    setTrolleyCargo({ crop: null, amountKg: 0 });
    setGameState('playing');
  };

  // Save Game Progress
  const handleSaveGame = () => {
    try {
      const saveData: GameSaveState = {
        version: 1,
        lastSaved: Date.now(),
        playerStats,
        fields,
        machinery,
        currentImplement,
        tractorUpgradeLevel,
        animals,
        missions,
        trolleyCargo
      };
      localStorage.setItem(SAVE_KEY, JSON.stringify(saveData));
      sound.playCashRegister();
      confetti({ particleCount: 40, spread: 60 });
    } catch {
      // storage quota or private mode
    }
  };

  // Machinery purchase & hitching
  const handleHitchImplement = (impl: ImplementType) => {
    setCurrentImplement(impl);
    if (engineRef.current) {
      engineRef.current.setAttachedImplement(impl);
    }
  };

  const handleBuyMachinery = (item: MachineryItem) => {
    if (playerStats.money >= item.price) {
      setPlayerStats((prev) => ({ ...prev, money: prev.money - item.price }));
      setMachinery((prev) =>
        prev.map((m) => (m.id === item.id ? { ...m, owned: true } : m))
      );
      handleHitchImplement(item.id);
      sound.playCashRegister();
    }
  };

  // Unlock field
  const handleUnlockField = (field: FieldData) => {
    if (playerStats.money >= field.unlockCost) {
      setPlayerStats((prev) => ({ ...prev, money: prev.money - field.unlockCost }));
      const updated = fields.map((f) => (f.id === field.id ? { ...f, unlocked: true } : f));
      setFields(updated);
      if (engineRef.current) {
        engineRef.current.fields = updated;
      }
      sound.playCashRegister();
      confetti({ particleCount: 70, spread: 80 });
    }
  };

  // Upgrade Tractor
  const handleUpgradeTractor = (lvl: number) => {
    setTractorUpgradeLevel(lvl);
    if (engineRef.current) {
      engineRef.current.upgradeTractor(lvl);
      const maxFuel = lvl === 4 ? 90 : lvl === 3 ? 70 : lvl === 2 ? 55 : 45;
      setPlayerStats((prev) => ({ ...prev, maxFuel, fuel: maxFuel }));
    }
    sound.playCashRegister();
    confetti({ particleCount: 60, spread: 70 });
  };

  // Feed animals
  const handleFeedAnimals = (animalId: string) => {
    setAnimals((prev) =>
      prev.map((a) =>
        a.id === animalId ? { ...a, feedLevel: Math.min(100, a.feedLevel + 25) } : a
      )
    );
    sound.playUIClick();
  };

  // Collect animal product
  const handleCollectProduct = (animalId: string) => {
    const pen = animals.find((a) => a.id === animalId);
    if (!pen || pen.productReady <= 0) return;

    const earnings = pen.productReady * pen.pricePerUnit;
    setPlayerStats((prev) => ({
      ...prev,
      money: prev.money + earnings,
      xp: prev.xp + 40
    }));

    setAnimals((prev) =>
      prev.map((a) => (a.id === animalId ? { ...a, productReady: 0 } : a))
    );

    sound.playCashRegister();
  };

  // Claim Mission Reward
  const handleClaimReward = (missionId: string) => {
    const mission = missions.find((m) => m.id === missionId);
    if (!mission || mission.completed) return;

    setPlayerStats((prev) => ({
      ...prev,
      money: prev.money + mission.rewardMoney,
      xp: prev.xp + mission.rewardXp
    }));

    setMissions((prev) =>
      prev.map((m) => (m.id === missionId ? { ...m, completed: true } : m))
    );

    sound.playMissionComplete();
    confetti({ particleCount: 90, spread: 90 });
  };

  // Weather toggle
  const handleSetWeather = (weather: WeatherType) => {
    setPlayerStats((prev) => ({ ...prev, weather }));
    if (engineRef.current) {
      engineRef.current.playerStats.weather = weather;
      sound.setWeatherAudio(weather);
    }
  };

  // Reset Game
  const handleResetGame = () => {
    localStorage.removeItem(SAVE_KEY);
    startNewGame();
    setIsMenuOpen(false);
  };

  return (
    <div className="relative h-screen w-screen overflow-hidden bg-stone-950 font-sans">
      {/* 3D Canvas */}
      <canvas ref={canvasRef} className="h-full w-full block outline-none" />

      {/* Main Menu Screen */}
      {gameState === 'menu' && (
        <MainMenu
          hasSaveData={hasSaveData}
          onNewGame={startNewGame}
          onContinue={loadSavedGame}
          onOpenVideoDemo={() => setIsVideoDemoOpen(true)}
        />
      )}

      {/* Active In-Game HUD */}
      {gameState === 'playing' && (
        <>
          <HUD
            stats={playerStats}
            inVehicle={inVehicle}
            speed={speed}
            gear={gear}
            currentImplement={currentImplement}
            implementLowered={implementLowered}
            trolleyCargo={trolleyCargo}
            activeField={activeField}
            interactionPrompt={interactionPrompt}
            cameraMode={cameraMode}
            isMuted={isMuted}
            isTouchControlsVisible={isTouchControlsVisible}
            onToggleTouchControls={() => setIsTouchControlsVisible((prev) => !prev)}
            onToggleMute={() => setIsMuted(sound.toggleMute())}
            onCycleCamera={() => {
              if (engineRef.current) {
                engineRef.current.cameraMode = ((cameraMode % 3) + 1) as 1 | 2 | 3;
                setCameraMode(engineRef.current.cameraMode);
              }
            }}
            onOpenMenu={() => {
              sound.playUIClick();
              setIsMenuOpen(true);
            }}
            onOpenVideoDemo={() => setIsVideoDemoOpen(true)}
            onTriggerAction={() => engineRef.current?.triggerContextInteraction()}
            onToggleVehicle={() => engineRef.current?.toggleVehicle()}
            onToggleImplement={() => engineRef.current?.toggleImplementLowered()}
            onHonkHorn={() => engineRef.current?.honkHorn()}
          />

          {/* Touch Controls for Mobile, Tablet, and Touch-Screen Laptops */}
          {isTouchControlsVisible && (
            <TouchControls
              inVehicle={inVehicle}
              implementLowered={implementLowered}
              onJoystickMove={(x, y) => engineRef.current?.setVirtualJoystick(x, y)}
              onJoystickEnd={() => engineRef.current?.stopVirtualJoystick()}
              onCameraRotate={(dx, dy) => engineRef.current?.rotateCameraBy(dx, dy)}
              onResetCamera={() => engineRef.current?.resetCameraOrbit()}
              onToggleVehicle={() => engineRef.current?.toggleVehicle()}
              onTriggerAction={() => engineRef.current?.triggerContextInteraction()}
              onToggleImplement={() => engineRef.current?.toggleImplementLowered()}
              onHonkHorn={() => engineRef.current?.honkHorn()}
              onThrottle={(act) => engineRef.current?.setThrottle(act)}
              onBrake={(act) => engineRef.current?.setBrake(act)}
              onSteerLeft={(act) => engineRef.current?.setSteerLeft(act)}
              onSteerRight={(act) => engineRef.current?.setSteerRight(act)}
              onHandbrake={(act) => engineRef.current?.setHandbrake(act)}
              onSprint={(act) => engineRef.current?.setSprint(act)}
            />
          )}

          {/* Comprehensive Farm Management Menu Modal */}
          <GameMenuModal
            isOpen={isMenuOpen}
            onClose={() => setIsMenuOpen(false)}
            stats={playerStats}
            fields={fields}
            machinery={machinery}
            currentImplement={currentImplement}
            selectedCrop={selectedCrop}
            animals={animals}
            missions={missions}
            tractorUpgradeLevel={tractorUpgradeLevel}
            onSelectCrop={(crop) => {
              setSelectedCrop(crop);
              if (engineRef.current) {
                engineRef.current.selectedSeedCrop = crop;
              }
            }}
            onHitchImplement={handleHitchImplement}
            onBuyMachinery={handleBuyMachinery}
            onUnlockField={handleUnlockField}
            onUpgradeTractor={handleUpgradeTractor}
            onFeedAnimals={handleFeedAnimals}
            onCollectAnimalProduct={handleCollectProduct}
            onClaimMissionReward={handleClaimReward}
            onBuyAnimal={() => {}}
            onSetWeather={handleSetWeather}
            onSaveGame={handleSaveGame}
            onResetGame={handleResetGame}
          />
        </>
      )}

      {/* Interactive Video Demo & Gameplay Walkthrough Modal */}
      <VideoDemoModal
        isOpen={isVideoDemoOpen}
        onClose={() => setIsVideoDemoOpen(false)}
        onStartGame={() => {
          setIsVideoDemoOpen(false);
          if (gameState === 'menu') {
            startNewGame();
          }
        }}
      />
    </div>
  );
}
