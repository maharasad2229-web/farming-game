import { CropInfo, CropType, FieldData, MachineryItem, AnimalPen, Mission, TractorUpgrade } from '../types';

export const CROPS_DATA: Record<CropType, CropInfo> = {
  wheat: {
    id: 'wheat',
    name: 'Wheat (Gandam)',
    urduName: 'گندم',
    category: 'cereal',
    seedCostPerAcre: 5500, // PKR
    growthTimeSeconds: 45, // fast for fun game loop
    waterReq: 60,
    fertReq: 50,
    baseYieldKg: 1800,
    baseMarketPricePer40Kg: 3900, // PKR per 40kg (Maund)
    color: '#84cc16', // green sprout
    harvestColor: '#eab308', // golden wheat
    description: 'The golden pride of Punjab. Major staple crop yielding high profit during Rabee season.'
  },
  rice: {
    id: 'rice',
    name: 'Basmati Rice (Chawal)',
    urduName: 'چاول (باسمتی)',
    category: 'cereal',
    seedCostPerAcre: 7200,
    growthTimeSeconds: 55,
    waterReq: 90,
    fertReq: 65,
    baseYieldKg: 1500,
    baseMarketPricePer40Kg: 5200,
    color: '#4ade80',
    harvestColor: '#ca8a04',
    description: 'Aromatic Super Basmati. Requires abundant irrigation through tube well channels.'
  },
  sugarcane: {
    id: 'sugarcane',
    name: 'Sugarcane (Kamad)',
    urduName: 'کماد (گنا)',
    category: 'cash',
    seedCostPerAcre: 11000,
    growthTimeSeconds: 70,
    waterReq: 85,
    fertReq: 80,
    baseYieldKg: 3200,
    baseMarketPricePer40Kg: 425,
    color: '#16a34a',
    harvestColor: '#15803d',
    description: 'Heavy cash crop sold directly to the local Sugar Mill (Chini Mill).'
  },
  cotton: {
    id: 'cotton',
    name: 'Cotton (Kapas / Phutti)',
    urduName: 'کپاس (پھٹی)',
    category: 'cash',
    seedCostPerAcre: 8500,
    growthTimeSeconds: 60,
    waterReq: 50,
    fertReq: 70,
    baseYieldKg: 1200,
    baseMarketPricePer40Kg: 8500,
    color: '#22c55e',
    harvestColor: '#f8fafc',
    description: 'White gold of Multan & Sindh. High value crop susceptible to bollworms and weeds.'
  },
  maize: {
    id: 'maize',
    name: 'Maize (Makki)',
    urduName: 'مکئی',
    category: 'cereal',
    seedCostPerAcre: 6000,
    growthTimeSeconds: 40,
    waterReq: 65,
    fertReq: 60,
    baseYieldKg: 2200,
    baseMarketPricePer40Kg: 2800,
    color: '#65a30d',
    harvestColor: '#facc15',
    description: 'Fast-growing spring & autumn hybrid corn used for flour and cattle feed.'
  },
  potato: {
    id: 'potato',
    name: 'Potato (Aaloo)',
    urduName: 'آلو',
    category: 'vegetable',
    seedCostPerAcre: 14000,
    growthTimeSeconds: 38,
    waterReq: 70,
    fertReq: 85,
    baseYieldKg: 2800,
    baseMarketPricePer40Kg: 2400,
    color: '#84cc16',
    harvestColor: '#a16207',
    description: 'Famous Okara/Depalpur red and white potatoes. High yield per acre.'
  },
  onion: {
    id: 'onion',
    name: 'Onion (Pyaz)',
    urduName: 'پیاز',
    category: 'vegetable',
    seedCostPerAcre: 7500,
    growthTimeSeconds: 35,
    waterReq: 55,
    fertReq: 50,
    baseYieldKg: 2100,
    baseMarketPricePer40Kg: 3200,
    color: '#4ade80',
    harvestColor: '#b91c1c',
    description: 'Sindh and Swat onions. Market prices can fluctuate wildly for great profit margins.'
  },
  tomato: {
    id: 'tomato',
    name: 'Tomato (Tamatar)',
    urduName: 'ٹماٹر',
    category: 'vegetable',
    seedCostPerAcre: 8000,
    growthTimeSeconds: 32,
    waterReq: 65,
    fertReq: 60,
    baseYieldKg: 1900,
    baseMarketPricePer40Kg: 3600,
    color: '#22c55e',
    harvestColor: '#ef4444',
    description: 'Juicy red tomatoes harvested quickly and transported straight to the Subzi Mandi.'
  },
  chili: {
    id: 'chili',
    name: 'Red Hot Chili (Mirch)',
    urduName: 'لال مرچ',
    category: 'vegetable',
    seedCostPerAcre: 9200,
    growthTimeSeconds: 36,
    waterReq: 60,
    fertReq: 65,
    baseYieldKg: 1400,
    baseMarketPricePer40Kg: 7800,
    color: '#16a34a',
    harvestColor: '#dc2626',
    description: 'Kunri (Sindh) spicy chili pepper. Sells at premium rates in local and export spice markets.'
  },
  sunflower: {
    id: 'sunflower',
    name: 'Sunflower (Surajmukhi)',
    urduName: 'سورج مکھی',
    category: 'oilseed',
    seedCostPerAcre: 6800,
    growthTimeSeconds: 42,
    waterReq: 50,
    fertReq: 55,
    baseYieldKg: 1100,
    baseMarketPricePer40Kg: 6500,
    color: '#65a30d',
    harvestColor: '#f59e0b',
    description: 'Bright golden oilseed fields that track the sun and give excellent edible oil yield.'
  }
};

export const INITIAL_FIELDS: FieldData[] = [
  {
    id: 1,
    name: 'Field 1: Dera Plot',
    acres: 1.5,
    unlocked: true,
    unlockCost: 0,
    bounds: { minX: -65, maxX: -15, minZ: -60, maxZ: -10 },
    center: { x: -40, z: -35 },
    soilState: 'unploughed',
    plantedCrop: null,
    growthProgress: 0,
    moistureLevel: 30,
    fertilizerLevel: 40,
    weedLevel: 10,
    pestLevel: 0,
    ploughedPercentage: 0,
    cultivatedPercentage: 0,
    seededPercentage: 0,
    harvestedPercentage: 0
  },
  {
    id: 2,
    name: 'Field 2: Tube Well East',
    acres: 2.2,
    unlocked: true,
    unlockCost: 0,
    bounds: { minX: 15, maxX: 75, minZ: -60, maxZ: -10 },
    center: { x: 45, z: -35 },
    soilState: 'unploughed',
    plantedCrop: null,
    growthProgress: 0,
    moistureLevel: 25,
    fertilizerLevel: 35,
    weedLevel: 5,
    pestLevel: 0,
    ploughedPercentage: 0,
    cultivatedPercentage: 0,
    seededPercentage: 0,
    harvestedPercentage: 0
  },
  {
    id: 3,
    name: 'Field 3: Canal Bank Acres',
    acres: 3.5,
    unlocked: false,
    unlockCost: 120000,
    bounds: { minX: -80, maxX: -15, minZ: 30, maxZ: 90 },
    center: { x: -47, z: 60 },
    soilState: 'unploughed',
    plantedCrop: null,
    growthProgress: 0,
    moistureLevel: 45,
    fertilizerLevel: 50,
    weedLevel: 0,
    pestLevel: 0,
    ploughedPercentage: 0,
    cultivatedPercentage: 0,
    seededPercentage: 0,
    harvestedPercentage: 0
  },
  {
    id: 4,
    name: 'Field 4: Mandi Highway Front',
    acres: 5.0,
    unlocked: false,
    unlockCost: 250000,
    bounds: { minX: 25, maxX: 95, minZ: 30, maxZ: 100 },
    center: { x: 60, z: 65 },
    soilState: 'unploughed',
    plantedCrop: null,
    growthProgress: 0,
    moistureLevel: 20,
    fertilizerLevel: 45,
    weedLevel: 0,
    pestLevel: 0,
    ploughedPercentage: 0,
    cultivatedPercentage: 0,
    seededPercentage: 0,
    harvestedPercentage: 0
  }
];

export const INITIAL_MACHINERY: MachineryItem[] = [
  {
    id: 'plough',
    name: 'Mouldboard Plough (Hal)',
    urduName: 'ہل (مولڈ بورڈ)',
    price: 35000,
    owned: true,
    workWidth: 2.2,
    description: '3-bottom steel mouldboard plough to break deep hard soil and invert furrows.',
    workType: 'plough'
  },
  {
    id: 'cultivator',
    name: 'Tiller / Cultivator (Suhaga Hal)',
    urduName: 'ہل (کلٹیویٹر/ٹلر)',
    price: 45000,
    owned: true,
    workWidth: 2.6,
    description: '9-tine spring cultivator to break up soil clods and pulverize the seedbed.',
    workType: 'cultivate'
  },
  {
    id: 'rotavator',
    name: 'Rotary Tiller (Rotavator)',
    urduName: 'روٹاوریٹر',
    price: 95000,
    owned: false,
    workWidth: 2.8,
    description: 'PTO-driven heavy rotavator for fine soil tilt in a single high-speed pass.',
    workType: 'cultivate'
  },
  {
    id: 'seed_drill',
    name: 'Rabi Seed Drill (Beej Machine)',
    urduName: 'بیج ڈرل مشین',
    price: 65000,
    owned: true,
    workWidth: 2.4,
    description: 'Precision seed drill with grain hopper for uniform row spacing and depth.',
    workType: 'seed'
  },
  {
    id: 'fertilizer_spreader',
    name: 'Fertilizer Broadcaster (Khaad Spreader)',
    urduName: 'کھاد چھٹہ مشین',
    price: 40000,
    owned: false,
    workWidth: 4.5,
    description: 'Centrifugal spinning disk broadcaster for even distribution of Urea and DAP.',
    workType: 'fertilize'
  },
  {
    id: 'sprayer',
    name: 'Boom Crop Sprayer (Spraay Machine)',
    urduName: 'سپرے مشین',
    price: 55000,
    owned: false,
    workWidth: 5.0,
    description: 'Pressure pump with folding spray boom to eliminate cotton whiteflies and weeds.',
    workType: 'spray'
  },
  {
    id: 'harvester_cutter',
    name: 'Front Crop Harvester & Reaper',
    urduName: 'ہارویسٹر کٹر ہیڈ',
    price: 130000,
    owned: true,
    workWidth: 3.0,
    description: 'Reciprocating cutter bar with reel to harvest ripe wheat, rice, and stalks.',
    workType: 'harvest'
  },
  {
    id: 'trolley',
    name: 'Truck-Art Farm Trolley (Desi Trailer)',
    urduName: 'دیسی ٹریکٹر ٹرالی',
    price: 85000,
    owned: true,
    workWidth: 2.5,
    description: 'Hand-painted wooden high-wall trolley with Pakistani truck art for hauling crops to Mandi.',
    workType: 'transport'
  }
];

export const TRACTOR_UPGRADES: TractorUpgrade[] = [
  {
    level: 1,
    name: 'Millat Massey Ferguson 385 (85 HP Classic Red)',
    enginePowerHp: 85,
    fuelTankMax: 65,
    speedMax: 26,
    upgradeCost: 0
  },
  {
    level: 2,
    name: 'Al-Ghazi New Holland Fiat 640 (85 HP Vibrant Orange)',
    enginePowerHp: 85,
    fuelTankMax: 70,
    speedMax: 28,
    upgradeCost: 95000
  },
  {
    level: 3,
    name: 'Belarus 820 Heavy Duty (81 HP Soviet Turbo)',
    enginePowerHp: 90,
    fuelTankMax: 85,
    speedMax: 30,
    upgradeCost: 180000
  },
  {
    level: 4,
    name: 'John Deere 6M Modern Power (120 HP Green Giant)',
    enginePowerHp: 120,
    fuelTankMax: 110,
    speedMax: 36,
    upgradeCost: 320000
  }
];

export const INITIAL_ANIMALS: AnimalPen[] = [
  {
    id: 'buffalo',
    type: 'buffalo',
    name: 'Nili-Ravi Buffaloes',
    urduName: 'نیلی راوی بھینسیں',
    count: 2,
    capacity: 6,
    feedLevel: 75,
    waterLevel: 80,
    productReady: 12,
    productType: 'Milk (Liters)',
    pricePerUnit: 220, // PKR per liter
    purchaseCostPerAnimal: 240000
  },
  {
    id: 'cow',
    type: 'cow',
    name: 'Sahiwal Dairy Cows',
    urduName: 'ساہیوال گائے',
    count: 1,
    capacity: 4,
    feedLevel: 80,
    waterLevel: 70,
    productReady: 8,
    productType: 'Milk (Liters)',
    pricePerUnit: 190,
    purchaseCostPerAnimal: 180000
  },
  {
    id: 'goat',
    type: 'goat',
    name: 'Beetal Goats',
    urduName: 'بیتل بکریاں',
    count: 3,
    capacity: 10,
    feedLevel: 60,
    waterLevel: 65,
    productReady: 3,
    productType: 'Milk (Liters)',
    pricePerUnit: 260,
    purchaseCostPerAnimal: 55000
  },
  {
    id: 'chicken',
    type: 'chicken',
    name: 'Desi Village Chickens',
    urduName: 'دیسی مرغیاں',
    count: 8,
    capacity: 25,
    feedLevel: 90,
    waterLevel: 85,
    productReady: 6,
    productType: 'Eggs (Dozen)',
    pricePerUnit: 340,
    purchaseCostPerAnimal: 1800
  }
];

export const INITIAL_MISSIONS: Mission[] = [
  {
    id: 'm_plough_1',
    title: 'Soil Preparation: Plough Field 1',
    urduTitle: 'کھیت نمبر 1 میں ہل چلائیں',
    description: 'Attach the Mouldboard Plough (Hal) to your tractor, drive into Field 1 (Dera Plot), and turn the soil.',
    rewardMoney: 15000,
    rewardXp: 120,
    completed: false,
    type: 'plough',
    targetValue: 80,
    currentValue: 0,
    targetFieldId: 1
  },
  {
    id: 'm_seed_wheat',
    title: 'Sow Golden Wheat in Field 1',
    urduTitle: 'کھیت 1 میں گندم کی بجائی کریں',
    description: 'Attach the Seed Drill, select Wheat (Gandam) seeds, and plant the crop across the ploughed field.',
    rewardMoney: 25000,
    rewardXp: 180,
    completed: false,
    type: 'seed',
    targetValue: 80,
    currentValue: 0,
    targetFieldId: 1,
    cropType: 'wheat'
  },
  {
    id: 'm_irrigate_1',
    title: 'Start Tube Well & Irrigate Field',
    urduTitle: 'ٹیوب ویل چلا کر کھیت کو پانی دیں',
    description: 'Walk or drive to the Tube Well pump station and turn on the water motor to fill the irrigation channels.',
    rewardMoney: 12000,
    rewardXp: 100,
    completed: false,
    type: 'irrigate',
    targetValue: 70,
    currentValue: 30,
    targetFieldId: 1
  },
  {
    id: 'm_harvest_wheat',
    title: 'Harvest Golden Wheat with Cutter',
    urduTitle: 'پکی ہوئی گندم کی کٹائی کریں',
    description: 'Once Field 1 reaches 100% maturity, attach the Harvester Cutter and harvest the golden stalks.',
    rewardMoney: 40000,
    rewardXp: 260,
    completed: false,
    type: 'harvest',
    targetValue: 80,
    currentValue: 0,
    targetFieldId: 1,
    cropType: 'wheat'
  },
  {
    id: 'm_sell_mandi',
    title: 'Load Trolley & Sell at Grain Mandi',
    urduTitle: 'ٹرالی بھر کر اناج منڈی میں فروخت کریں',
    description: 'Hitch the painted Pakistani Trolley, drive to the Grain Storage / Mandi, and sell your harvest for cash.',
    rewardMoney: 30000,
    rewardXp: 200,
    completed: false,
    type: 'sell',
    targetValue: 1500,
    currentValue: 0
  },
  {
    id: 'm_milk_animals',
    title: 'Collect Dairy Milk from Buffaloes',
    urduTitle: 'بھینسوں کا تازہ دودھ حاصل کریں',
    description: 'Visit the cattle yard, feed the animals, and collect fresh milk for the village dairy.',
    rewardMoney: 18000,
    rewardXp: 150,
    completed: false,
    type: 'milk',
    targetValue: 20,
    currentValue: 0
  },
  {
    id: 'm_expand_canal',
    title: 'Unlock Field 3: Canal Bank Acres',
    urduTitle: 'نہر کے کنارے نیا زرعی رقبہ خریدیں',
    description: 'Expand your family zamindari by purchasing the fertile 3.5 acre plot along the main irrigation canal.',
    rewardMoney: 50000,
    rewardXp: 400,
    completed: false,
    type: 'earn',
    targetValue: 120000,
    currentValue: 45000
  }
];
