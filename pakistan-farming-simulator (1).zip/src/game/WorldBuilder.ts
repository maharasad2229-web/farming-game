import * as THREE from 'three';
import { FieldData, ImplementType } from '../types';
import { ProceduralTextures } from './ProceduralTextures';

export class WorldBuilder {
  public scene: THREE.Scene;

  // Tracked interactive world objects
  public tractorMesh: THREE.Group = new THREE.Group();
  public playerMesh: THREE.Group = new THREE.Group();
  public seatedDriverMesh: THREE.Group = new THREE.Group();
  public attachedImplementMesh: THREE.Group = new THREE.Group();
  public tubeWellMesh: THREE.Group = new THREE.Group();
  public waterStreamMesh: THREE.Mesh | null = null;
  public canalWaterMesh: THREE.Mesh | null = null;
  public animalGroup: THREE.Group = new THREE.Group();
  public fieldMeshes: Map<number, { ground: THREE.Mesh; cropInstancedMesh?: THREE.InstancedMesh; furrowGroup?: THREE.Group; boundsBox: THREE.Box3 }> = new Map();
  public exhaustParticles: { mesh: THREE.Mesh; life: number; velocity: THREE.Vector3 }[] = [];
  public rainParticles: THREE.Points | null = null;
  public wheelMeshes: THREE.Mesh[] = [];
  public currentTractorLevel: number = 1;
  public treeSwayMeshes: THREE.Group[] = [];

  // Natural living environment entities
  public birds: { group: THREE.Group; leftWing: THREE.Mesh; rightWing: THREE.Mesh; center: THREE.Vector3; radius: number; angle: number; speed: number; flapSpeed: number; baseHeight: number }[] = [];
  public floatingAirParticles: THREE.Points | null = null;
  public dynamicClouds: THREE.Group[] = [];
  public animatedAnimals: { group: THREE.Group; tail?: THREE.Mesh; head?: THREE.Group; type: string; animPhase: number }[] = [];
  public villagePeople: THREE.Group[] = [];
  public canalWaterOffset: number = 0;

  constructor(scene: THREE.Scene) {
    this.scene = scene;
  }

  // --- BUILD THE COMPLETE PAKISTANI RURAL ENVIRONMENT ---
  public buildEnvironment(fields: FieldData[]) {
    // 1. Vast Natural Terrain Plane with PBR Grass/Soil Texture
    const terrainGeo = new THREE.PlaneGeometry(350, 350, 64, 64);
    terrainGeo.rotateX(-Math.PI / 2);
    
    // Add subtle undulations for natural Pakistani rural topography
    const pos = terrainGeo.attributes.position;
    for (let i = 0; i < pos.count; i++) {
      const x = pos.getX(i);
      const z = pos.getZ(i);
      // Flat around farm center, gentle rises towards horizon
      const dist = Math.sqrt(x * x + z * z);
      if (dist > 75) {
        const h = Math.sin(x * 0.04) * Math.cos(z * 0.04) * 2.2 + Math.sin(x * 0.08) * 0.5;
        pos.setY(i, h);
      }
    }
    terrainGeo.computeVertexNormals();

    const grassTex = ProceduralTextures.getGrassTexture();
    const bumpTex = ProceduralTextures.getSoilBumpMap();

    const terrainMat = new THREE.MeshStandardMaterial({
      map: grassTex,
      bumpMap: bumpTex,
      bumpScale: 0.12,
      color: 0xc4beaa, // Warm Pakistani alluvial meadow tint
      roughness: 0.92,
      metalness: 0.04
    });
    const terrain = new THREE.Mesh(terrainGeo, terrainMat);
    terrain.receiveShadow = true;
    this.scene.add(terrain);

    // 2. Roads Network (Brick Soling & Dirt Tracks)
    this.createRoads();

    // 3. Fields with raised earthen borders (wats) and water channels (khals)
    this.buildFields(fields);

    // 4. Pakistani Village Dera, Farm House & Baithak
    this.buildFarmHouseDera();

    // 5. Pakistani Tube Well (Peter Engine + Cement Houz Tank + Water Outlet)
    this.buildTubeWell();

    // 6. Tractor Shed / Workshop & Tool Garage
    this.buildTractorShed();

    // 7. Pakistani Livestock Shed (Haveli / Cattle Area) with Buffaloes & Cows
    this.buildAnimalShed();

    // 8. Grain Mandi / Storage Godown & Weighing Station
    this.buildGrainMandi();

    // 9. Petrol Pump / Diesel Station
    this.buildPetrolPump();

    // 10. Rural Details: Electricity Poles, Realistic Neem/Eucalyptus/Date Trees, Bhoosa Mounds, Charpais
    this.buildRuralDecorations();

    // 11. Natural Wild Vegetation, Grass Clumps & Weed Clusters
    this.buildWildVegetation();

    // 12. Create Playable Drivable Pakistani Tractor
    this.buildPakistaniTractor();

    // 13. Create Traditional Pakistani Farmer Character
    this.buildFarmerCharacter();

    // 14. Weather Rain Particle System
    this.initWeatherParticles();

    // 15. Real-life Birds Flock (Kabootar & Eagles circling above fields)
    this.buildBirdsFlock();

    // 16. Atmospheric Floating Air Particles & Dynamic 3D Clouds
    this.initAtmosphereAndClouds();

    // 17. Village Characters (Arhti at Mandi, Mazdoor carrying grain sack, Gawala with milk pails)
    this.buildVillageCharacters();
  }

  // --- ROADS & CHANNELS ---
  private createRoads() {
    const asphaltTex = ProceduralTextures.getRealAsphaltTexture();
    const brickBump = ProceduralTextures.getSoilBumpMap();

    const roadMat = new THREE.MeshStandardMaterial({
      map: asphaltTex,
      bumpMap: brickBump,
      bumpScale: 0.04,
      roughness: 0.78,
      metalness: 0.08
    });

    // Main Village to Mandi Highway Road (runs North-South)
    const mainRoadGeo = new THREE.PlaneGeometry(8.0, 260);
    mainRoadGeo.rotateX(-Math.PI / 2);
    const mainRoad = new THREE.Mesh(mainRoadGeo, roadMat);
    mainRoad.position.set(0, 0.045, 20);
    mainRoad.receiveShadow = true;
    this.scene.add(mainRoad);

    // Weathered Concrete Curbs on both sides of the main road
    const curbGeo = new THREE.BoxGeometry(0.3, 0.18, 260);
    const curbMat = new THREE.MeshStandardMaterial({ color: 0x78716c, roughness: 0.92 });
    const curbLeft = new THREE.Mesh(curbGeo, curbMat);
    curbLeft.position.set(-4.0, 0.08, 20);
    this.scene.add(curbLeft);

    const curbRight = new THREE.Mesh(curbGeo, curbMat);
    curbRight.position.set(4.0, 0.08, 20);
    this.scene.add(curbRight);

    // East-West Farm Road connecting Dera to Tube Well and Fields (Dirt Cart Track)
    const dirtTex = ProceduralTextures.getDirtRoadTexture();
    const dirtRoadMat = new THREE.MeshStandardMaterial({
      map: dirtTex,
      bumpMap: brickBump,
      bumpScale: 0.1,
      roughness: 0.96,
      metalness: 0.02
    });
    const crossRoadGeo = new THREE.PlaneGeometry(240, 6.5);
    crossRoadGeo.rotateX(-Math.PI / 2);
    const crossRoad = new THREE.Mesh(crossRoadGeo, dirtRoadMat);
    crossRoad.position.set(0, 0.035, -15);
    crossRoad.receiveShadow = true;
    this.scene.add(crossRoad);

    // Main Irrigation Water Canal (Nahr / Khal) alongside road
    const concreteTex = ProceduralTextures.getConcreteTexture();
    const canalMat = new THREE.MeshStandardMaterial({
      map: concreteTex,
      roughness: 0.88
    });
    const canalGeo = new THREE.BoxGeometry(2.8, 0.7, 220);
    const canal = new THREE.Mesh(canalGeo, canalMat);
    canal.position.set(-6, -0.2, 20);
    this.scene.add(canal);

    // Flowing Canal Water with realistic water caustics and normal ripples
    const waterNormal = ProceduralTextures.getWaterNormalTexture();
    const waterCaustics = ProceduralTextures.getWaterCausticsTexture();
    const canalWaterGeo = new THREE.PlaneGeometry(2.3, 220);
    canalWaterGeo.rotateX(-Math.PI / 2);
    const canalWaterMat = new THREE.MeshStandardMaterial({
      map: waterCaustics,
      normalMap: waterNormal,
      normalScale: new THREE.Vector2(0.4, 0.4),
      color: 0x1f5459, // Authentic silt green-blue canal water of Punjab
      roughness: 0.08,
      metalness: 0.4,
      transparent: true,
      opacity: 0.88
    });
    this.canalWaterMesh = new THREE.Mesh(canalWaterGeo, canalWaterMat);
    this.canalWaterMesh.position.set(-6, 0.06, 20);
    this.scene.add(this.canalWaterMesh);

    // Concrete Distribution Branches (Kassiyan) with Water Gates (Naaka) into each Field
    const kassiPositions = [
      { x: -35, z: 20, len: 55 },
      { x: -6, z: -35, len: 45 },
      { x: -6, z: 65, len: 45 }
    ];

    kassiPositions.forEach((kp) => {
      // Earthen/concrete branch ditch
      const kGeo = new THREE.BoxGeometry(1.4, 0.45, kp.len);
      const kMesh = new THREE.Mesh(kGeo, canalMat);
      kMesh.position.set(kp.x, -0.1, kp.z);
      this.scene.add(kMesh);

      // Water channel in kassi
      const kwGeo = new THREE.PlaneGeometry(1.1, kp.len);
      kwGeo.rotateX(-Math.PI / 2);
      const kwMesh = new THREE.Mesh(kwGeo, canalWaterMat);
      kwMesh.position.set(kp.x, 0.04, kp.z);
      this.scene.add(kwMesh);

      // Iron Sluice Gate (Naaka)
      const gateFrameGeo = new THREE.BoxGeometry(1.5, 0.9, 0.12);
      const gateMat = new THREE.MeshStandardMaterial({ color: 0x374151, metalness: 0.8 });
      const gate = new THREE.Mesh(gateFrameGeo, gateMat);
      gate.position.set(kp.x, 0.35, kp.z - kp.len / 2 + 1);
      this.scene.add(gate);
    });
  }

  // --- FIELDS & CROP INSTANCING ---
  private buildFields(fields: FieldData[]) {
    const soilTex = ProceduralTextures.getSoilTexture();
    const bumpTex = ProceduralTextures.getSoilBumpMap();

    fields.forEach((field) => {
      const width = field.bounds.maxX - field.bounds.minX;
      const depth = field.bounds.maxZ - field.bounds.minZ;

      // Field plot ground with realistic soil texture and furrow bump
      const fieldGeo = new THREE.PlaneGeometry(width, depth, 16, 16);
      fieldGeo.rotateX(-Math.PI / 2);

      const fieldMat = new THREE.MeshStandardMaterial({
        map: soilTex,
        bumpMap: bumpTex,
        bumpScale: 0.16,
        color: 0x5a3e26, // Fresh fertile dark Punjab alluvial loam
        roughness: 0.94,
        metalness: 0.04
      });
      const fieldMesh = new THREE.Mesh(fieldGeo, fieldMat);
      fieldMesh.position.set(field.center.x, 0.06, field.center.z);
      fieldMesh.receiveShadow = true;
      this.scene.add(fieldMesh);

      // Raised Earthen Boundaries (Wat / Bann) around every field
      const watMat = new THREE.MeshStandardMaterial({
        bumpMap: bumpTex,
        bumpScale: 0.1,
        color: 0x6e5235,
        roughness: 0.96
      });
      const watThickness = 0.85;
      const watHeight = 0.38;

      // North & South Wats
      const watNSGeo = new THREE.BoxGeometry(width + 1.2, watHeight, watThickness);
      const watN = new THREE.Mesh(watNSGeo, watMat);
      watN.position.set(field.center.x, watHeight / 2, field.bounds.minZ);
      this.scene.add(watN);

      const watS = new THREE.Mesh(watNSGeo, watMat);
      watS.position.set(field.center.x, watHeight / 2, field.bounds.maxZ);
      this.scene.add(watS);

      // East & West Wats
      const watEWGeo = new THREE.BoxGeometry(watThickness, watHeight, depth + 1.2);
      const watW = new THREE.Mesh(watEWGeo, watMat);
      watW.position.set(field.bounds.minX, watHeight / 2, field.center.z);
      this.scene.add(watW);

      const watE = new THREE.Mesh(watEWGeo, watMat);
      watE.position.set(field.bounds.maxX, watHeight / 2, field.center.z);
      this.scene.add(watE);

      // Field Name Signboard (Pakistani wooden field marker)
      this.createFieldSignboard(field);

      // Store in map
      const box = new THREE.Box3(
        new THREE.Vector3(field.bounds.minX, 0, field.bounds.minZ),
        new THREE.Vector3(field.bounds.maxX, 5, field.bounds.maxZ)
      );
      this.fieldMeshes.set(field.id, { ground: fieldMesh, boundsBox: box });
    });
  }

  private createFieldSignboard(field: FieldData) {
    const postGeo = new THREE.CylinderGeometry(0.08, 0.08, 1.8);
    const postMat = new THREE.MeshStandardMaterial({ color: 0x4a3219, roughness: 0.9 });
    const post = new THREE.Mesh(postGeo, postMat);
    post.position.set(field.bounds.minX + 2, 0.9, field.bounds.minZ + 1);
    this.scene.add(post);

    const boardGeo = new THREE.BoxGeometry(1.4, 0.8, 0.08);
    const boardMat = new THREE.MeshStandardMaterial({ color: 0x1e3a2f, roughness: 0.8 }); // Green Pakistani agricultural board
    const board = new THREE.Mesh(boardGeo, boardMat);
    board.position.set(field.bounds.minX + 2, 1.4, field.bounds.minZ + 1);
    this.scene.add(board);
  }

  // Update dynamic visuals for fields (Soil state texture / crop stalks)
  public updateFieldVisuals(field: FieldData) {
    const fieldItem = this.fieldMeshes.get(field.id);
    if (!fieldItem) return;

    const mat = fieldItem.ground.material as THREE.MeshStandardMaterial;

    // Soil appearance based on state
    if (field.soilState === 'unploughed') {
      mat.color.setHex(0x8a6e4d); // Dry light brown with dusty surface
      mat.roughness = 0.96;
      mat.metalness = 0.02;
    } else if (field.soilState === 'ploughed') {
      mat.color.setHex(0x382312); // Deep dark furrowed moist earth
      mat.roughness = 0.98;
      mat.metalness = 0.05;
    } else if (field.soilState === 'cultivated') {
      mat.color.setHex(0x4a321b); // Smooth prepared seedbed tilth
      mat.roughness = 0.88;
      mat.metalness = 0.04;
    } else if (field.soilState === 'seeded') {
      mat.color.setHex(0x3f2a16); // Seeded rows
      mat.roughness = 0.85;
    } else if (field.soilState === 'harvest_ready' || field.growthProgress > 10) {
      // If crops are growing or harvest ready
      if (field.moistureLevel > 40) {
        mat.color.setHex(0x2f2012); // Moist dark soil
        mat.roughness = 0.75;
        mat.metalness = 0.12; // Glistening wet sheen
      } else {
        mat.color.setHex(0x563d25);
        mat.roughness = 0.92;
        mat.metalness = 0.03;
      }
    }

    // Manage 3D Botanical Crop Stalks
    if (field.growthProgress > 5 && field.plantedCrop) {
      this.rebuildCropMesh(field, fieldItem);
    } else {
      if (fieldItem.cropInstancedMesh) {
        this.scene.remove(fieldItem.cropInstancedMesh);
        fieldItem.cropInstancedMesh.geometry.dispose();
        fieldItem.cropInstancedMesh = undefined;
      }
    }
  }

  // Botanical crop mesh with multi-leaf stalks, grain heads, bolls, and flowers
  private rebuildCropMesh(field: FieldData, fieldItem: { ground: THREE.Mesh; cropInstancedMesh?: THREE.InstancedMesh }) {
    if (fieldItem.cropInstancedMesh) {
      this.scene.remove(fieldItem.cropInstancedMesh);
      fieldItem.cropInstancedMesh.geometry.dispose();
      fieldItem.cropInstancedMesh = undefined;
    }

    const rows = 14;
    const cols = 14;
    const count = rows * cols;
    const progress = Math.min(100, Math.max(0, field.growthProgress));
    const growthRatio = progress / 100;

    let plantGeo: THREE.BufferGeometry;
    let plantMat: THREE.MeshStandardMaterial;

    if (field.plantedCrop === 'wheat') {
      // Golden Wheat with slender stalk and nodding grain head with awn bristles
      const stalkH = 0.4 + growthRatio * 1.1;
      const isRipe = progress > 80;
      const wheatColor = isRipe ? 0xd4a034 : progress > 50 ? 0x86b026 : 0x589422;

      const stem = new THREE.CylinderGeometry(0.025, 0.04, stalkH, 5);
      stem.translate(0, stalkH / 2, 0);

      // Grain head (baali) on top
      const head = new THREE.CylinderGeometry(0.04, 0.05, 0.35, 5);
      head.translate(0.04, stalkH + 0.15, 0);
      head.rotateZ(-0.15); // Natural nodding head

      plantGeo = this.mergeGeometries([stem, head]);
      plantMat = new THREE.MeshStandardMaterial({
        color: wheatColor,
        roughness: 0.72,
        metalness: 0.08
      });
    } else if (field.plantedCrop === 'cotton') {
      // Branching shrub with cotton bolls
      const bushH = 0.35 + growthRatio * 0.9;
      const stem = new THREE.CylinderGeometry(0.03, 0.05, bushH, 5);
      stem.translate(0, bushH / 2, 0);

      // Branch 1 & 2
      const b1 = new THREE.CylinderGeometry(0.02, 0.03, bushH * 0.5, 4);
      b1.rotateZ(Math.PI / 4);
      b1.translate(0.12, bushH * 0.6, 0);

      const b2 = new THREE.CylinderGeometry(0.02, 0.03, bushH * 0.5, 4);
      b2.rotateZ(-Math.PI / 4);
      b2.translate(-0.12, bushH * 0.5, 0);

      // Fluffy white cotton bolls when ripe
      const boll = new THREE.DodecahedronGeometry(progress > 75 ? 0.12 : 0.06);
      boll.translate(0, bushH + 0.06, 0);

      plantGeo = this.mergeGeometries([stem, b1, b2, boll]);
      plantMat = new THREE.MeshStandardMaterial({
        color: progress > 80 ? 0xf8fafc : 0x2e7d32,
        roughness: progress > 80 ? 0.95 : 0.65
      });
    } else if (field.plantedCrop === 'sugarcane') {
      // Tall segmented sugarcane stalks with arching leaves
      const caneH = 0.6 + growthRatio * 2.5;
      const stem = new THREE.CylinderGeometry(0.055, 0.07, caneH, 6);
      stem.translate(0, caneH / 2, 0);

      // Arching leaf blades
      const leaf1 = new THREE.BoxGeometry(0.12, caneH * 0.6, 0.02);
      leaf1.rotateZ(Math.PI / 5);
      leaf1.translate(0.2, caneH * 0.8, 0);

      const leaf2 = new THREE.BoxGeometry(0.12, caneH * 0.6, 0.02);
      leaf2.rotateZ(-Math.PI / 5);
      leaf2.translate(-0.2, caneH * 0.85, 0);

      plantGeo = this.mergeGeometries([stem, leaf1, leaf2]);
      plantMat = new THREE.MeshStandardMaterial({
        color: 0x1e7532,
        roughness: 0.68,
        metalness: 0.08
      });
    } else if (field.plantedCrop === 'sunflower') {
      // Tall sturdy stalk with flower head
      const stemH = 0.5 + growthRatio * 1.6;
      const stem = new THREE.CylinderGeometry(0.04, 0.06, stemH, 6);
      stem.translate(0, stemH / 2, 0);

      // Golden sunflower disc on top
      const flower = new THREE.CylinderGeometry(0.35, 0.35, 0.06, 12);
      flower.rotateX(Math.PI / 4);
      flower.translate(0, stemH + 0.12, 0.12);

      plantGeo = this.mergeGeometries([stem, flower]);
      plantMat = new THREE.MeshStandardMaterial({
        color: progress > 70 ? 0xf59e0b : 0x4d7c0f,
        roughness: 0.6
      });
    } else {
      // Basmati Rice / Maize / General: multi-tiller cluster
      const stalkH = 0.4 + growthRatio * 1.2;
      const stem1 = new THREE.CylinderGeometry(0.03, 0.04, stalkH, 5);
      stem1.translate(0, stalkH / 2, 0);

      const stem2 = new THREE.CylinderGeometry(0.025, 0.035, stalkH * 0.9, 5);
      stem2.rotateZ(0.18);
      stem2.translate(0.08, stalkH * 0.45, 0);

      const stem3 = new THREE.CylinderGeometry(0.025, 0.035, stalkH * 0.9, 5);
      stem3.rotateZ(-0.18);
      stem3.translate(-0.08, stalkH * 0.45, 0);

      plantGeo = this.mergeGeometries([stem1, stem2, stem3]);
      const riceColor = progress > 85 ? 0xcc9933 : 0x3b821f;
      plantMat = new THREE.MeshStandardMaterial({
        color: riceColor,
        roughness: 0.7
      });
    }

    const instancedMesh = new THREE.InstancedMesh(plantGeo, plantMat, count);
    instancedMesh.castShadow = true;
    instancedMesh.receiveShadow = true;

    const dummy = new THREE.Object3D();
    const width = field.bounds.maxX - field.bounds.minX - 3.5;
    const depth = field.bounds.maxZ - field.bounds.minZ - 3.5;

    let index = 0;
    for (let r = 0; r < rows; r++) {
      for (let c = 0; c < cols; c++) {
        const x = field.bounds.minX + 1.8 + (c / (cols - 1)) * width + (Math.random() - 0.5) * 0.4;
        const z = field.bounds.minZ + 1.8 + (r / (rows - 1)) * depth + (Math.random() - 0.5) * 0.4;
        dummy.position.set(x, 0.07, z);
        dummy.rotation.y = Math.random() * Math.PI * 2;
        const s = 0.85 + Math.random() * 0.3;
        dummy.scale.set(s, s, s);
        dummy.updateMatrix();
        instancedMesh.setMatrixAt(index++, dummy.matrix);
      }
    }

    instancedMesh.instanceMatrix.needsUpdate = true;
    this.scene.add(instancedMesh);
    fieldItem.cropInstancedMesh = instancedMesh;
  }

  // Simple geometry merge helper
  private mergeGeometries(geos: THREE.BufferGeometry[]): THREE.BufferGeometry {
    // Collect all vertex data into single combined geometry
    let totalVerts = 0;
    geos.forEach(g => totalVerts += g.attributes.position.count);

    const posArray = new Float32Array(totalVerts * 3);
    const normArray = new Float32Array(totalVerts * 3);

    let offset = 0;
    geos.forEach(g => {
      const p = g.attributes.position;
      const n = g.attributes.normal || g.computeVertexNormals();
      for (let i = 0; i < p.count; i++) {
        posArray[(offset + i) * 3] = p.getX(i);
        posArray[(offset + i) * 3 + 1] = p.getY(i);
        posArray[(offset + i) * 3 + 2] = p.getZ(i);

        if (g.attributes.normal) {
          normArray[(offset + i) * 3] = g.attributes.normal.getX(i);
          normArray[(offset + i) * 3 + 1] = g.attributes.normal.getY(i);
          normArray[(offset + i) * 3 + 2] = g.attributes.normal.getZ(i);
        } else {
          normArray[(offset + i) * 3 + 1] = 1;
        }
      }
      offset += p.count;
    });

    const combined = new THREE.BufferGeometry();
    combined.setAttribute('position', new THREE.BufferAttribute(posArray, 3));
    combined.setAttribute('normal', new THREE.BufferAttribute(normArray, 3));
    return combined;
  }

  // --- PAKISTANI DERA & FARM HOUSE ---
  private buildFarmHouseDera() {
    const deraGroup = new THREE.Group();
    deraGroup.position.set(-25, 0, -25);

    const mudTex = ProceduralTextures.getMudPlasterTexture();
    const bumpTex = ProceduralTextures.getSoilBumpMap();

    // Main Haveli / Baithak Room with realistic mud-straw plaster
    const houseGeo = new THREE.BoxGeometry(10, 4.2, 7);
    const houseMat = new THREE.MeshStandardMaterial({
      map: mudTex,
      bumpMap: bumpTex,
      bumpScale: 0.08,
      color: 0xdfcaa8, // Warm Pakistani clay plaster
      roughness: 0.94,
      metalness: 0.02
    });
    const house = new THREE.Mesh(houseGeo, houseMat);
    house.position.set(0, 2.1, 0);
    house.castShadow = true;
    deraGroup.add(house);

    // Flat Roof with terracotta brick parapet
    const brickTex = ProceduralTextures.getBrickRoadTexture();
    const roofParapetGeo = new THREE.BoxGeometry(10.4, 0.6, 7.4);
    const roofMat = new THREE.MeshStandardMaterial({
      map: brickTex,
      color: 0xa85538,
      roughness: 0.88
    });
    const parapet = new THREE.Mesh(roofParapetGeo, roofMat);
    parapet.position.set(0, 4.3, 0);
    deraGroup.add(parapet);

    // Verandah (Chhappar / Porch) with rustic wooden pillars and corrugated roofing
    const porchRoofGeo = new THREE.BoxGeometry(10, 0.2, 3.5);
    const porchMat = new THREE.MeshStandardMaterial({ color: 0x5a3e26, roughness: 0.85 });
    const porchRoof = new THREE.Mesh(porchRoofGeo, porchMat);
    porchRoof.position.set(0, 3.4, 4.8);
    deraGroup.add(porchRoof);

    // Weathered Wooden Pillars supporting verandah
    const barkTex = ProceduralTextures.getBarkTexture('neem');
    [-4.5, -1.5, 1.5, 4.5].forEach((px) => {
      const pillarGeo = new THREE.CylinderGeometry(0.12, 0.12, 3.4);
      const pillarMat = new THREE.MeshStandardMaterial({ map: barkTex, roughness: 0.85 });
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(px, 1.7, 6.2);
      deraGroup.add(pillar);
    });

    // Traditional Charpai (Pakistani wooden cot with woven jute rope)
    const charpai = this.createCharpai();
    charpai.position.set(2, 0, 4.5);
    deraGroup.add(charpai);

    // Mud clay water jug (Matka / Gharra) on stand
    const matkaGeo = new THREE.SphereGeometry(0.28, 14, 14);
    const matkaMat = new THREE.MeshStandardMaterial({ color: 0xc4693f, roughness: 0.92 });
    const matka = new THREE.Mesh(matkaGeo, matkaMat);
    matka.position.set(-3.5, 0.6, 5.0);
    deraGroup.add(matka);

    this.scene.add(deraGroup);
  }

  private createCharpai(): THREE.Group {
    const charpai = new THREE.Group();
    // 4 legs (Paaway)
    const legGeo = new THREE.CylinderGeometry(0.06, 0.05, 0.5);
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x54361e, roughness: 0.8 });
    [
      [-0.9, -0.45],
      [0.9, -0.45],
      [-0.9, 0.45],
      [0.9, 0.45]
    ].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(legGeo, woodMat);
      leg.position.set(lx, 0.25, lz);
      charpai.add(leg);
    });

    // Frame (Sairway)
    const frameGeo = new THREE.BoxGeometry(1.9, 0.08, 1.0);
    const frame = new THREE.Mesh(frameGeo, woodMat);
    frame.position.set(0, 0.48, 0);
    charpai.add(frame);

    // Woven jute rope webbing (Vaan)
    const webGeo = new THREE.PlaneGeometry(1.7, 0.85);
    webGeo.rotateX(-Math.PI / 2);
    const webMat = new THREE.MeshStandardMaterial({ color: 0xd6b27e, roughness: 0.95 });
    const web = new THREE.Mesh(webGeo, webMat);
    web.position.set(0, 0.53, 0);
    charpai.add(web);

    return charpai;
  }

  // --- TUBE WELL PUMP & CEMENT HOUZ TANK ---
  private buildTubeWell() {
    this.tubeWellMesh.position.set(-5, 0, -35);

    const concreteTex = ProceduralTextures.getConcreteTexture();
    const waterNormal = ProceduralTextures.getWaterNormalTexture();

    // Concrete Water Storage Tank (Houz) with weathered concrete texture
    const houzOuterGeo = new THREE.BoxGeometry(4.5, 1.2, 4.5);
    const houzMat = new THREE.MeshStandardMaterial({
      map: concreteTex,
      roughness: 0.88,
      metalness: 0.05
    });
    const houzOuter = new THREE.Mesh(houzOuterGeo, houzMat);
    houzOuter.position.set(0, 0.6, 0);
    this.tubeWellMesh.add(houzOuter);

    // Water Surface inside Houz with realistic ripples
    const waterGeo = new THREE.PlaneGeometry(3.9, 3.9);
    waterGeo.rotateX(-Math.PI / 2);
    const waterMat = new THREE.MeshStandardMaterial({
      color: 0x226b77, // Cool greenish-blue fresh groundwater
      normalMap: waterNormal,
      normalScale: new THREE.Vector2(0.4, 0.4),
      roughness: 0.08,
      metalness: 0.3,
      transparent: true,
      opacity: 0.88
    });
    const water = new THREE.Mesh(waterGeo, waterMat);
    water.position.set(0, 1.0, 0);
    this.tubeWellMesh.add(water);

    // Small Peter Engine Pump House Shed with mud-brick texture
    const mudTex = ProceduralTextures.getMudPlasterTexture();
    const shedGeo = new THREE.BoxGeometry(2.4, 2.2, 2.2);
    const shedMat = new THREE.MeshStandardMaterial({
      map: mudTex,
      color: 0xbfa382,
      roughness: 0.92
    });
    const shed = new THREE.Mesh(shedGeo, shedMat);
    shed.position.set(-3.2, 1.1, 0);
    this.tubeWellMesh.add(shed);

    // Peter Engine (Heavy Iron Single Cylinder Diesel Engine with Flywheel)
    const engineGeo = new THREE.BoxGeometry(1.2, 0.8, 0.7);
    const engineMat = new THREE.MeshStandardMaterial({ color: 0x1f3824, metalness: 0.7, roughness: 0.4 }); // Dark green Peter engine
    const engine = new THREE.Mesh(engineGeo, engineMat);
    engine.position.set(-3.2, 0.6, 1.3);
    this.tubeWellMesh.add(engine);

    // Big Flywheel (Wheel)
    const wheelGeo = new THREE.CylinderGeometry(0.45, 0.45, 0.12, 18);
    wheelGeo.rotateZ(Math.PI / 2);
    const wheelMat = new THREE.MeshStandardMaterial({ color: 0x111111, metalness: 0.85, roughness: 0.3 });
    const flywheel = new THREE.Mesh(wheelGeo, wheelMat);
    flywheel.position.set(-3.7, 0.6, 1.3);
    this.tubeWellMesh.add(flywheel);

    // Big Iron Delivery Pipe pouring into Houz
    const pipeGeo = new THREE.CylinderGeometry(0.18, 0.18, 2.4, 14);
    pipeGeo.rotateZ(Math.PI / 2);
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x2e3a47, metalness: 0.8, roughness: 0.3 });
    const pipe = new THREE.Mesh(pipeGeo, pipeMat);
    pipe.position.set(-1.4, 1.5, 0);
    this.tubeWellMesh.add(pipe);

    // Water Gushing stream coming out of pipe
    const streamGeo = new THREE.CylinderGeometry(0.14, 0.22, 0.8, 10);
    const streamMat = new THREE.MeshStandardMaterial({
      color: 0x4aaed4,
      transparent: true,
      opacity: 0.85,
      roughness: 0.1
    });
    this.waterStreamMesh = new THREE.Mesh(streamGeo, streamMat);
    this.waterStreamMesh.position.set(-0.3, 1.1, 0);
    this.waterStreamMesh.visible = false; // toggled on when pump is running
    this.tubeWellMesh.add(this.waterStreamMesh);

    // Tube Well Switch Box & Urdu Board
    const switchGeo = new THREE.BoxGeometry(0.3, 0.5, 0.2);
    const switchMat = new THREE.MeshStandardMaterial({ color: 0xdc2626 });
    const switchBox = new THREE.Mesh(switchGeo, switchMat);
    switchBox.position.set(-2.0, 1.4, 0.8);
    this.tubeWellMesh.add(switchBox);

    this.scene.add(this.tubeWellMesh);
  }

  // --- TRACTOR SHED & WORKSHOP ---
  private buildTractorShed() {
    const shedGroup = new THREE.Group();
    shedGroup.position.set(-25, 0, 5);

    // Slanted tin roof
    const roofGeo = new THREE.BoxGeometry(9, 0.15, 8);
    roofGeo.rotateZ(0.08);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x52606d, metalness: 0.7, roughness: 0.4 });
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(0, 4.2, 0);
    shedGroup.add(roof);

    // Metal support girders
    [
      [-4.2, -3.8],
      [4.2, -3.8],
      [-4.2, 3.8],
      [4.2, 3.8]
    ].forEach(([gx, gz]) => {
      const girderGeo = new THREE.CylinderGeometry(0.1, 0.1, 4.2);
      const girderMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.8 });
      const girder = new THREE.Mesh(girderGeo, girderMat);
      girder.position.set(gx, 2.1, gz);
      shedGroup.add(girder);
    });

    // Workshop Workbench with toolboxes & red diesel drum
    const drumGeo = new THREE.CylinderGeometry(0.4, 0.4, 1.0, 16);
    const drumMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.5 });
    const drum = new THREE.Mesh(drumGeo, drumMat);
    drum.position.set(3.2, 0.5, -3.0);
    shedGroup.add(drum);

    this.scene.add(shedGroup);
  }

  // --- LIVESTOCK AREA (HAVELI) ---
  private buildAnimalShed() {
    this.animalGroup.position.set(25, 0, -25);

    // Fenced wooden animal yard with aged weathered posts
    const fenceMat = new THREE.MeshStandardMaterial({ color: 0x4a3319, roughness: 0.92 });
    const fenceGeo = new THREE.BoxGeometry(16, 1.15, 0.15);

    const fNorth = new THREE.Mesh(fenceGeo, fenceMat);
    fNorth.position.set(0, 0.58, -7);
    this.animalGroup.add(fNorth);

    const fSouth = new THREE.Mesh(fenceGeo, fenceMat);
    fSouth.position.set(0, 0.58, 7);
    this.animalGroup.add(fSouth);

    const fSideGeo = new THREE.BoxGeometry(0.15, 1.15, 14);
    const fEast = new THREE.Mesh(fSideGeo, fenceMat);
    fEast.position.set(8, 0.58, 0);
    this.animalGroup.add(fEast);

    // Wooden gate posts
    [-8, 8].forEach((gx) => {
      const postGeo = new THREE.CylinderGeometry(0.12, 0.14, 1.6, 8);
      const post = new THREE.Mesh(postGeo, fenceMat);
      post.position.set(gx, 0.8, -7);
      this.animalGroup.add(post);
    });

    // Cattle Feeding Trough (Khurli) built from brick and plaster
    const khurliGeo = new THREE.BoxGeometry(10, 0.85, 1.2);
    const khurliMat = new THREE.MeshStandardMaterial({ color: 0x827663, roughness: 0.88 });
    const khurli = new THREE.Mesh(khurliGeo, khurliMat);
    khurli.position.set(0, 0.42, -5.6);
    khurli.castShadow = true;
    this.animalGroup.add(khurli);

    // Fresh Green Barseem & Mustard fodder (Chara) in khurli
    const fodderGeo = new THREE.BoxGeometry(9.6, 0.25, 0.95);
    const fodderMat = new THREE.MeshStandardMaterial({ color: 0x4d7c0f, roughness: 0.85 });
    const fodder = new THREE.Mesh(fodderGeo, fodderMat);
    fodder.position.set(0, 0.82, -5.6);
    this.animalGroup.add(fodder);

    // Yellow Mustard flower specks in fodder
    const flowerMat = new THREE.MeshStandardMaterial({ color: 0xfacc15 });
    for (let f = 0; f < 18; f++) {
      const flGeo = new THREE.SphereGeometry(0.06, 4, 4);
      const fl = new THREE.Mesh(flGeo, flowerMat);
      fl.position.set(-4.5 + Math.random() * 9.0, 0.96, -5.6 + (Math.random() - 0.5) * 0.7);
      this.animalGroup.add(fl);
    }

    // 1. Pakistani Nili-Ravi Buffalo (Dark wet hide, curled horns, white forehead star)
    const buffalo = this.createBuffaloMesh();
    buffalo.position.set(-3.6, 0, -2.5);
    this.animalGroup.add(buffalo);

    // 2. Sahiwal Zebu Dairy Cow (Chestnut coat, prominent hump, throat dewlap, swishing tail)
    const cow = this.createSahiwalCowMesh();
    cow.position.set(3.4, 0, -2.5);
    this.animalGroup.add(cow);

    // 3. Second Sahiwal Cow resting near the manger
    const cow2 = this.createSahiwalCowMesh();
    cow2.position.set(0.6, 0, -1.8);
    cow2.rotation.y = 0.4;
    this.animalGroup.add(cow2);

    // 4. Desi Goats (Beetal / Kamori) with long floppy ears grazing in paddock
    const goat1 = this.createDesiGoatMesh();
    goat1.position.set(-5.5, 0, 2.5);
    goat1.rotation.y = 0.8;
    this.animalGroup.add(goat1);

    const goat2 = this.createDesiGoatMesh();
    goat2.position.set(4.8, 0, 3.2);
    goat2.rotation.y = -1.2;
    this.animalGroup.add(goat2);

    this.scene.add(this.animalGroup);
  }

  // Realistic Pakistani Nili-Ravi Buffalo with Anatomical Horns & Mud Sheen
  private createBuffaloMesh(): THREE.Group {
    const buffalo = new THREE.Group();
    const buffaloTex = ProceduralTextures.getCattleSkinTexture('buffalo');
    const blackMat = new THREE.MeshStandardMaterial({
      map: buffaloTex,
      bumpMap: buffaloTex,
      bumpScale: 0.08,
      color: 0x1f2328,
      roughness: 0.45,
      metalness: 0.15
    });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.5 });
    const muzzleMat = new THREE.MeshStandardMaterial({ color: 0x3f332c, roughness: 0.7 });
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf4f4f5, roughness: 0.6 });

    // 1. Organic Barrel Torso
    const bodyGeo = new THREE.CylinderGeometry(0.78, 0.82, 2.4, 12);
    bodyGeo.rotateX(Math.PI / 2);
    const body = new THREE.Mesh(bodyGeo, blackMat);
    body.position.set(0, 1.25, 0);
    body.castShadow = true;
    buffalo.add(body);

    // 2. Thick Muscular Neck
    const neckGeo = new THREE.CylinderGeometry(0.5, 0.65, 1.1, 10);
    neckGeo.rotateX(0.7);
    const neck = new THREE.Mesh(neckGeo, blackMat);
    neck.position.set(0, 1.48, 1.15);
    neck.castShadow = true;
    buffalo.add(neck);

    // 3. Head & Snout Group (for chewing cud animation)
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.62, 1.72);

    const craniumGeo = new THREE.BoxGeometry(0.68, 0.58, 0.65);
    const cranium = new THREE.Mesh(craniumGeo, blackMat);
    cranium.castShadow = true;
    headGroup.add(cranium);

    // Iconic Nili-Ravi White Star on Forehead ("Panch Kalyan" hallmark)
    const starGeo = new THREE.BoxGeometry(0.18, 0.22, 0.02);
    const star = new THREE.Mesh(starGeo, whiteMat);
    star.position.set(0, 0.12, 0.33);
    headGroup.add(star);

    // Tapered Muzzle / Snout with wide nostrils
    const muzzleGeo = new THREE.BoxGeometry(0.52, 0.42, 0.58);
    const muzzle = new THREE.Mesh(muzzleGeo, muzzleMat);
    muzzle.position.set(0, -0.16, 0.48);
    headGroup.add(muzzle);

    // Nostrils
    [-0.14, 0.14].forEach((nx) => {
      const nosGeo = new THREE.SphereGeometry(0.045, 6, 6);
      const nos = new THREE.Mesh(nosGeo, hornMat);
      nos.position.set(nx, -0.16, 0.77);
      headGroup.add(nos);
    });

    // Dark Glazed Eyes
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x050505, roughness: 0.1, metalness: 0.9 });
    [-0.35, 0.35].forEach((ex) => {
      const eyeGeo = new THREE.SphereGeometry(0.065, 8, 8);
      const eye = new THREE.Mesh(eyeGeo, eyeMat);
      eye.position.set(ex, 0.08, 0.2);
      headGroup.add(eye);
    });

    // Drooping Lateral Ears
    [-0.42, 0.42].forEach((ex, i) => {
      const earGeo = new THREE.BoxGeometry(0.24, 0.08, 0.12);
      earGeo.rotateZ((i === 0 ? 1 : -1) * 0.4);
      const ear = new THREE.Mesh(earGeo, blackMat);
      ear.position.set(ex, 0.12, -0.05);
      headGroup.add(ear);
    });

    // Iconic Tightly Curled "Kundhi" Horns of Nili-Ravi breed
    [-0.32, 0.32].forEach((hx) => {
      const hornGeo = new THREE.TorusGeometry(0.24, 0.065, 8, 16, Math.PI * 1.15);
      hornGeo.rotateY(hx > 0 ? 0.4 : -0.4);
      hornGeo.rotateX(-0.5);
      const horn = new THREE.Mesh(hornGeo, hornMat);
      horn.position.set(hx, 0.26, -0.05);
      headGroup.add(horn);
    });

    buffalo.add(headGroup);

    // 4. Sturdy Hoofed Legs (with white fetlocks / socks)
    const legGeo = new THREE.CylinderGeometry(0.12, 0.1, 1.15, 8);
    const hoofGeo = new THREE.CylinderGeometry(0.11, 0.13, 0.14, 8);
    const hoofMat = new THREE.MeshStandardMaterial({ color: 0x111111, roughness: 0.8 });

    [
      [-0.55, -0.85],
      [0.55, -0.85],
      [-0.55, 0.75],
      [0.55, 0.75]
    ].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(legGeo, blackMat);
      leg.position.set(lx, 0.58, lz);
      leg.castShadow = true;

      // White socks marking on ankles
      const sockGeo = new THREE.CylinderGeometry(0.105, 0.11, 0.25, 8);
      const sock = new THREE.Mesh(sockGeo, whiteMat);
      sock.position.set(0, -0.42, 0);
      leg.add(sock);

      const hoof = new THREE.Mesh(hoofGeo, hoofMat);
      hoof.position.set(0, -0.52, 0);
      leg.add(hoof);

      buffalo.add(leg);
    });

    // 5. Swishing Tail with White Switch Tuft
    const tailMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.04, 0.03, 0.95, 6),
      blackMat
    );
    tailMesh.position.set(0, 1.35, -1.22);
    tailMesh.rotation.x = -0.35;

    // White switch brush
    const brushGeo = new THREE.ConeGeometry(0.08, 0.35, 6);
    brushGeo.rotateX(Math.PI);
    const brush = new THREE.Mesh(brushGeo, whiteMat);
    brush.position.set(0, -0.55, 0);
    tailMesh.add(brush);
    buffalo.add(tailMesh);

    // Register for idle animation
    this.animatedAnimals.push({
      group: buffalo,
      tail: tailMesh,
      head: headGroup,
      type: 'buffalo',
      animPhase: Math.random() * Math.PI * 2
    });

    return buffalo;
  }

  // Realistic Sahiwal Dairy Cow (Zebu) with Kohan Hump, Throat Dewlap & Swishing Tail
  private createSahiwalCowMesh(): THREE.Group {
    const cow = new THREE.Group();
    const cowTex = ProceduralTextures.getCattleSkinTexture('sahiwal');
    const coatMat = new THREE.MeshStandardMaterial({
      map: cowTex,
      bumpMap: cowTex,
      bumpScale: 0.09,
      color: 0x9b4221, // Authentic reddish chestnut Sahiwal coat
      roughness: 0.65,
      metalness: 0.05
    });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x261d18, roughness: 0.6 });
    const muzzleMat = new THREE.MeshStandardMaterial({ color: 0x42261a, roughness: 0.8 });
    const udderMat = new THREE.MeshStandardMaterial({ color: 0xdca890, roughness: 0.5 });

    // 1. Torso
    const bodyGeo = new THREE.CylinderGeometry(0.68, 0.74, 2.3, 12);
    bodyGeo.rotateX(Math.PI / 2);
    const body = new THREE.Mesh(bodyGeo, coatMat);
    body.position.set(0, 1.2, 0);
    body.castShadow = true;
    cow.add(body);

    // 2. Distinctive Sahiwal Hump (Kohan) over shoulders
    const humpGeo = new THREE.SphereGeometry(0.42, 10, 10);
    humpGeo.scale(0.85, 1.15, 1.1);
    const hump = new THREE.Mesh(humpGeo, coatMat);
    hump.position.set(0, 1.82, 0.68);
    hump.castShadow = true;
    cow.add(hump);

    // 3. Hanging Loose Neck Skin Folds (Iconic Sahiwal Dewlap / Gal-Kambal)
    const dewlapGeo = new THREE.BoxGeometry(0.12, 0.65, 1.1);
    dewlapGeo.rotateX(0.4);
    const dewlap = new THREE.Mesh(dewlapGeo, coatMat);
    dewlap.position.set(0, 1.12, 1.25);
    dewlap.castShadow = true;
    cow.add(dewlap);

    // 4. Head Group (with jaw and ears)
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.55, 1.6);

    const headGeo = new THREE.BoxGeometry(0.58, 0.52, 0.62);
    const head = new THREE.Mesh(headGeo, coatMat);
    head.castShadow = true;
    headGroup.add(head);

    // Tapered Muzzle with nostrils
    const muzzleGeo = new THREE.BoxGeometry(0.44, 0.38, 0.52);
    const muzzle = new THREE.Mesh(muzzleGeo, muzzleMat);
    muzzle.position.set(0, -0.15, 0.45);
    headGroup.add(muzzle);

    // Big gentle eyes with white ring
    const eyeMat = new THREE.MeshStandardMaterial({ color: 0x0a0a0a, roughness: 0.1 });
    [-0.3, 0.3].forEach((ex) => {
      const eyeGeo = new THREE.SphereGeometry(0.055, 8, 8);
      const eye = new THREE.Mesh(eyeGeo, eyeMat);
      eye.position.set(ex, 0.08, 0.16);
      headGroup.add(eye);
    });

    // Long Pendulous Drooping Ears
    [-0.36, 0.36].forEach((ex, i) => {
      const earGeo = new THREE.BoxGeometry(0.28, 0.09, 0.12);
      earGeo.rotateZ((i === 0 ? 1 : -1) * 0.55);
      const ear = new THREE.Mesh(earGeo, coatMat);
      ear.position.set(ex, 0.05, -0.08);
      headGroup.add(ear);
    });

    // Short Stumpy Sahiwal Horns
    [-0.24, 0.24].forEach((hx, i) => {
      const hornGeo = new THREE.ConeGeometry(0.06, 0.26, 6);
      hornGeo.rotateX(-0.4);
      hornGeo.rotateZ((i === 0 ? -1 : 1) * 0.3);
      const horn = new THREE.Mesh(hornGeo, hornMat);
      horn.position.set(hx, 0.32, -0.05);
      headGroup.add(horn);
    });

    cow.add(headGroup);

    // 5. Slender Bovine Legs with Cloven Hooves
    const legGeo = new THREE.CylinderGeometry(0.1, 0.085, 1.15, 8);
    const hoofGeo = new THREE.CylinderGeometry(0.09, 0.11, 0.12, 8);
    const hoofMat = new THREE.MeshStandardMaterial({ color: 0x1c1917, roughness: 0.8 });

    [
      [-0.48, -0.8],
      [0.48, -0.8],
      [-0.48, 0.7],
      [0.48, 0.7]
    ].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(legGeo, coatMat);
      leg.position.set(lx, 0.58, lz);
      leg.castShadow = true;

      const hoof = new THREE.Mesh(hoofGeo, hoofMat);
      hoof.position.set(0, -0.52, 0);
      leg.add(hoof);

      cow.add(leg);
    });

    // 6. Dairy Udder (Hawaana) with 4 Teats
    const udderGeo = new THREE.SphereGeometry(0.24, 8, 8);
    udderGeo.scale(1.0, 0.8, 1.2);
    const udder = new THREE.Mesh(udderGeo, udderMat);
    udder.position.set(0, 0.82, -0.35);
    cow.add(udder);

    // 4 Teats
    [
      [-0.08, -0.08],
      [0.08, -0.08],
      [-0.08, 0.08],
      [0.08, 0.08]
    ].forEach(([tx, tz]) => {
      const teatGeo = new THREE.CylinderGeometry(0.02, 0.015, 0.1, 6);
      const teat = new THREE.Mesh(teatGeo, udderMat);
      teat.position.set(tx, 0.65, -0.35 + tz);
      cow.add(teat);
    });

    // 7. Swishing Tail with Black Hair Tuft
    const tailMesh = new THREE.Mesh(
      new THREE.CylinderGeometry(0.035, 0.025, 0.98, 6),
      coatMat
    );
    tailMesh.position.set(0, 1.28, -1.18);
    tailMesh.rotation.x = -0.3;

    // Dark hair switch at tip
    const tuftGeo = new THREE.ConeGeometry(0.07, 0.32, 6);
    tuftGeo.rotateX(Math.PI);
    const tuftMat = new THREE.MeshStandardMaterial({ color: 0x1f1915, roughness: 0.9 });
    const tuft = new THREE.Mesh(tuftGeo, tuftMat);
    tuft.position.set(0, -0.56, 0);
    tailMesh.add(tuft);
    cow.add(tailMesh);

    // Register for idle animation
    this.animatedAnimals.push({
      group: cow,
      tail: tailMesh,
      head: headGroup,
      type: 'sahiwal',
      animPhase: Math.random() * Math.PI * 2
    });

    return cow;
  }

  // Desi Pakistani Goat (Kamori / Beetal with long floppy ears)
  private createDesiGoatMesh(): THREE.Group {
    const goat = new THREE.Group();
    const goatTex = ProceduralTextures.getCattleSkinTexture('goat');
    const coatMat = new THREE.MeshStandardMaterial({
      map: goatTex,
      bumpMap: goatTex,
      bumpScale: 0.06,
      roughness: 0.7
    });
    const hornMat = new THREE.MeshStandardMaterial({ color: 0x292524, roughness: 0.6 });

    // Torso
    const bodyGeo = new THREE.CylinderGeometry(0.32, 0.36, 1.1, 8);
    bodyGeo.rotateX(Math.PI / 2);
    const body = new THREE.Mesh(bodyGeo, coatMat);
    body.position.set(0, 0.72, 0);
    body.castShadow = true;
    goat.add(body);

    // Head
    const headGroup = new THREE.Group();
    headGroup.position.set(0, 1.05, 0.65);

    const headGeo = new THREE.BoxGeometry(0.3, 0.32, 0.38);
    const head = new THREE.Mesh(headGeo, coatMat);
    headGroup.add(head);

    // Long Pendulous Kamori Ears (famous long hanging ears)
    [-0.18, 0.18].forEach((ex, i) => {
      const earGeo = new THREE.BoxGeometry(0.08, 0.36, 0.06);
      earGeo.rotateZ((i === 0 ? -1 : 1) * 0.15);
      const ear = new THREE.Mesh(earGeo, coatMat);
      ear.position.set(ex, -0.15, 0);
      headGroup.add(ear);
    });

    // Backward Curved Horns
    [-0.08, 0.08].forEach((hx) => {
      const hornGeo = new THREE.CylinderGeometry(0.03, 0.015, 0.28, 6);
      hornGeo.rotateX(-0.5);
      const horn = new THREE.Mesh(hornGeo, hornMat);
      horn.position.set(hx, 0.22, -0.05);
      headGroup.add(horn);
    });

    goat.add(headGroup);

    // 4 Slender Legs
    const legGeo = new THREE.CylinderGeometry(0.05, 0.04, 0.68, 6);
    [
      [-0.22, -0.4],
      [0.22, -0.4],
      [-0.22, 0.35],
      [0.22, 0.35]
    ].forEach(([lx, lz]) => {
      const leg = new THREE.Mesh(legGeo, coatMat);
      leg.position.set(lx, 0.34, lz);
      leg.castShadow = true;
      goat.add(leg);
    });

    // Short Upright Tail
    const tailGeo = new THREE.ConeGeometry(0.04, 0.18, 5);
    tailGeo.rotateX(0.6);
    const tail = new THREE.Mesh(tailGeo, coatMat);
    tail.position.set(0, 0.85, -0.55);
    goat.add(tail);

    this.animatedAnimals.push({
      group: goat,
      head: headGroup,
      type: 'goat',
      animPhase: Math.random() * Math.PI * 2
    });

    return goat;
  }

  // --- GRAIN MANDI / MARKET & STORAGE GODOWN ---
  private buildGrainMandi() {
    const mandiGroup = new THREE.Group();
    mandiGroup.position.set(40, 0, 50);

    // Elevated Concrete Auction Platform with weathered concrete texture
    const concreteTex = ProceduralTextures.getConcreteTexture();
    const platformGeo = new THREE.BoxGeometry(16, 0.6, 12);
    const platformMat = new THREE.MeshStandardMaterial({
      map: concreteTex,
      roughness: 0.88,
      metalness: 0.05
    });
    const platform = new THREE.Mesh(platformGeo, platformMat);
    platform.position.set(0, 0.3, 0);
    mandiGroup.add(platform);

    // Mandi Tin Shed Roof
    const roofGeo = new THREE.BoxGeometry(17, 0.2, 13);
    const roofMat = new THREE.MeshStandardMaterial({ color: 0x15803d }); // Green Pakistani Mandi canopy
    const roof = new THREE.Mesh(roofGeo, roofMat);
    roof.position.set(0, 5.0, 0);
    mandiGroup.add(roof);

    // Steel Pillars
    [
      [-7.5, -5.5],
      [7.5, -5.5],
      [-7.5, 5.5],
      [7.5, 5.5]
    ].forEach(([px, pz]) => {
      const pillarGeo = new THREE.CylinderGeometry(0.14, 0.14, 4.8);
      const pillarMat = new THREE.MeshStandardMaterial({ color: 0x374151, metalness: 0.8 });
      const pillar = new THREE.Mesh(pillarGeo, pillarMat);
      pillar.position.set(px, 2.7, pz);
      mandiGroup.add(pillar);
    });

    // Stacks of Jute Grain Sacks (Borian)
    const sackMat = new THREE.MeshStandardMaterial({ color: 0xc2a679, roughness: 0.95 });
    for (let i = 0; i < 4; i++) {
      for (let j = 0; j < 3; j++) {
        const sackGeo = new THREE.BoxGeometry(1.2, 0.5, 0.7);
        const sack = new THREE.Mesh(sackGeo, sackMat);
        sack.position.set(-4 + i * 1.3, 0.85 + j * 0.45, -2.5);
        sack.rotation.y = (Math.random() - 0.5) * 0.2;
        mandiGroup.add(sack);
      }
    }

    // Weighing Platform Scale (Kanda)
    const scaleGeo = new THREE.BoxGeometry(2.5, 0.15, 2.5);
    const scaleMat = new THREE.MeshStandardMaterial({ color: 0x222222, metalness: 0.8 });
    const scale = new THREE.Mesh(scaleGeo, scaleMat);
    scale.position.set(3.5, 0.65, 2.0);
    mandiGroup.add(scale);

    this.scene.add(mandiGroup);
  }

  // --- PETROL PUMP / DIESEL STATION ---
  private buildPetrolPump() {
    const pumpGroup = new THREE.Group();
    pumpGroup.position.set(-45, 0, 45);

    // Fuel Canopy
    const canopyGeo = new THREE.BoxGeometry(10, 0.3, 8);
    const canopyMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 }); // PSO / Shell blue canopy
    const canopy = new THREE.Mesh(canopyGeo, canopyMat);
    canopy.position.set(0, 4.5, 0);
    pumpGroup.add(canopy);

    // Canopy Pillars
    [-3.8, 3.8].forEach((px) => {
      const pGeo = new THREE.CylinderGeometry(0.18, 0.18, 4.4);
      const pMat = new THREE.MeshStandardMaterial({ color: 0xffffff, roughness: 0.5 });
      const p = new THREE.Mesh(pGeo, pMat);
      p.position.set(px, 2.2, 0);
      pumpGroup.add(p);
    });

    // Diesel Dispenser Unit
    const dispenserGeo = new THREE.BoxGeometry(1.2, 2.0, 0.6);
    const dispenserMat = new THREE.MeshStandardMaterial({ color: 0x16a34a }); // Green Diesel pump
    const dispenser = new THREE.Mesh(dispenserGeo, dispenserMat);
    dispenser.position.set(0, 1.0, 0);
    pumpGroup.add(dispenser);

    this.scene.add(pumpGroup);
  }

  // --- RURAL DECORATIONS (TREES, ELECTRICITY POLES, BHOOSA DHAR) ---
  private buildRuralDecorations() {
    // 1. Traditional Bhoosa Mounds (Wheat straw chaff storage covered in mud plaster)
    [
      [-15, -45],
      [18, -48]
    ].forEach(([bx, bz]) => {
      const bhoosaGeo = new THREE.ConeGeometry(2.5, 2.8, 14);
      const bhoosaMat = new THREE.MeshStandardMaterial({ color: 0x947249, roughness: 0.95 });
      const mound = new THREE.Mesh(bhoosaGeo, bhoosaMat);
      mound.position.set(bx, 1.4, bz);
      mound.castShadow = true;
      this.scene.add(mound);
    });

    // 2. Rural Electricity Poles with Crossarms along the road
    for (let z = -60; z <= 80; z += 35) {
      const pole = this.createElectricityPole();
      pole.position.set(5.5, 0, z);
      this.scene.add(pole);
    }

    // 3. Pakistani Rural Trees (Eucalyptus / Safeda, Neem, Shisham / Talli, Date Palm)
    const treePositions = [
      { x: -12, z: -18, type: 'neem' },
      { x: -8, z: -28, type: 'safeda' },
      { x: 10, z: -22, type: 'shisham' },
      { x: -38, z: -10, type: 'safeda' },
      { x: 12, z: 15, type: 'palm' },
      { x: -14, z: 25, type: 'neem' },
      { x: 30, z: 20, type: 'safeda' },
      { x: -45, z: 20, type: 'palm' },
      { x: -55, z: -40, type: 'shisham' },
      { x: 50, z: -15, type: 'safeda' },
      { x: -65, z: 30, type: 'neem' },
      { x: 45, z: 50, type: 'palm' },
      { x: -20, z: 60, type: 'shisham' },
      { x: 15, z: -55, type: 'safeda' }
    ];

    treePositions.forEach((tp) => {
      const tree = this.createPakistaniTree(tp.type);
      tree.position.set(tp.x, 0, tp.z);
      this.scene.add(tree);
      this.treeSwayMeshes.push(tree);
    });
  }

  private createElectricityPole(): THREE.Group {
    const pole = new THREE.Group();
    // Vertical cement pole
    const pGeo = new THREE.CylinderGeometry(0.12, 0.16, 7.5, 8);
    const pMat = new THREE.MeshStandardMaterial({ color: 0x9ca3af, roughness: 0.9 });
    const pMesh = new THREE.Mesh(pGeo, pMat);
    pMesh.position.set(0, 3.75, 0);
    pole.add(pMesh);

    // Cross-arm
    const crossGeo = new THREE.BoxGeometry(1.6, 0.1, 0.1);
    const crossMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.7 });
    const cross = new THREE.Mesh(crossGeo, crossMat);
    cross.position.set(0, 7.0, 0);
    pole.add(cross);

    // Ceramic insulators
    [-0.7, 0, 0.7].forEach((ix) => {
      const insGeo = new THREE.CylinderGeometry(0.04, 0.05, 0.15);
      const insMat = new THREE.MeshStandardMaterial({ color: 0x854d0e });
      const ins = new THREE.Mesh(insGeo, insMat);
      ins.position.set(ix, 7.15, 0);
      pole.add(ins);
    });

    return pole;
  }

  private createPakistaniTree(type: string): THREE.Group {
    const tree = new THREE.Group();
    const barkTex = ProceduralTextures.getBarkTexture(type === 'palm' ? 'palm' : type === 'safeda' ? 'safeda' : 'neem');

    const trunkMat = new THREE.MeshStandardMaterial({
      map: barkTex,
      bumpMap: barkTex,
      bumpScale: 0.12,
      roughness: 0.88,
      color: type === 'safeda' ? 0xf1ede3 : type === 'palm' ? 0x543a22 : 0x362113
    });

    if (type === 'safeda') {
      // Tall, elegant Eucalyptus (Safeda) with pale mottled peeling bark and sweeping drooping foliage
      const trunkGeo = new THREE.CylinderGeometry(0.18, 0.32, 11.5, 10);
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.set(0, 5.75, 0);
      trunk.castShadow = true;
      tree.add(trunk);

      // Branching upper forks
      [-0.4, 0.4].forEach((bx, i) => {
        const forkGeo = new THREE.CylinderGeometry(0.08, 0.14, 4.5, 8);
        forkGeo.rotateZ((i === 0 ? -1 : 1) * 0.28);
        const fork = new THREE.Mesh(forkGeo, trunkMat);
        fork.position.set(bx * 0.8, 9.2, 0);
        fork.castShadow = true;
        tree.add(fork);
      });

      const leafTex = ProceduralTextures.getLeafCanopyTexture('#4d7c0f');
      const leafMat = new THREE.MeshStandardMaterial({
        map: leafTex,
        roughness: 0.55,
        alphaTest: 0.15,
        color: 0x65a30d
      });

      // Layered conical foliage plumes with graceful drooping canopy
      [
        { y: 7.8, r: 1.8, h: 4.2 },
        { y: 10.2, r: 1.5, h: 4.0 },
        { y: 12.4, r: 1.0, h: 3.2 },
        { y: 14.0, r: 0.6, h: 2.2 }
      ].forEach((layer) => {
        const fGeo = new THREE.ConeGeometry(layer.r, layer.h, 8);
        const fMesh = new THREE.Mesh(fGeo, leafMat);
        fMesh.position.set((Math.random() - 0.5) * 0.2, layer.y, (Math.random() - 0.5) * 0.2);
        fMesh.castShadow = true;
        tree.add(fMesh);
      });
    } else if (type === 'palm') {
      // Natural Date Palm (Khajoor) with annular fibrous trunk segments, arching fronds, and golden date bunches
      // Stacked ringed trunk segments
      const trunkGroup = new THREE.Group();
      for (let s = 0; s < 6; s++) {
        const segGeo = new THREE.CylinderGeometry(0.24 - s * 0.015, 0.28 - s * 0.015, 1.4, 10);
        const seg = new THREE.Mesh(segGeo, trunkMat);
        seg.position.set(0, 0.7 + s * 1.3, 0);
        seg.castShadow = true;
        trunkGroup.add(seg);
      }
      tree.add(trunkGroup);

      // Golden Date Fruit Clusters (Khajoor ke Guchhe) hanging below fronds
      const fruitMat = new THREE.MeshStandardMaterial({
        color: 0xd97706, // Rich golden-amber date fruit
        roughness: 0.4,
        metalness: 0.2
      });

      for (let g = 0; g < 4; g++) {
        const gAng = (g / 4) * Math.PI * 2 + 0.3;
        const stalkGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.8);
        stalkGeo.rotateZ(0.5);
        const stalk = new THREE.Mesh(stalkGeo, trunkMat);
        stalk.position.set(Math.cos(gAng) * 0.35, 7.8, Math.sin(gAng) * 0.35);
        tree.add(stalk);

        // Clustered fruit bundle
        const bunchGeo = new THREE.DodecahedronGeometry(0.28);
        const bunch = new THREE.Mesh(bunchGeo, fruitMat);
        bunch.position.set(Math.cos(gAng) * 0.5, 7.4, Math.sin(gAng) * 0.5);
        bunch.scale.set(1.0, 1.6, 1.0);
        tree.add(bunch);
      }

      // 16 Radiating arching pinnate palm fronds
      const leafTex = ProceduralTextures.getLeafCanopyTexture('#15803d');
      const frondMat = new THREE.MeshStandardMaterial({
        map: leafTex,
        roughness: 0.5,
        color: 0x16a34a,
        side: THREE.DoubleSide
      });

      for (let i = 0; i < 16; i++) {
        const angle = (i / 16) * Math.PI * 2;
        const frondGroup = new THREE.Group();
        frondGroup.position.set(0, 8.2, 0);
        frondGroup.rotation.y = angle;

        // Arching stem
        const fStemGeo = new THREE.CylinderGeometry(0.03, 0.05, 3.8, 6);
        fStemGeo.rotateX(Math.PI / 2.5); // Arched downwards
        const fStem = new THREE.Mesh(fStemGeo, trunkMat);
        fStem.position.set(0, -0.2, 1.7);
        frondGroup.add(fStem);

        // Pinnate feather blade
        const fBladeGeo = new THREE.ConeGeometry(0.55, 3.6, 5);
        fBladeGeo.rotateX(Math.PI / 2.5);
        fBladeGeo.scale(1.2, 0.1, 1.0); // Flatten into leaf blade
        const fBlade = new THREE.Mesh(fBladeGeo, frondMat);
        fBlade.position.set(0, -0.15, 1.8);
        fBlade.castShadow = true;
        frondGroup.add(fBlade);

        tree.add(frondGroup);
      }
    } else {
      // Majestic mature Neem / Shisham Tree with sprawling boughs, canopy clusters, and organic foliage
      const trunkGeo = new THREE.CylinderGeometry(0.42, 0.65, 5.2, 10);
      const trunk = new THREE.Mesh(trunkGeo, trunkMat);
      trunk.position.set(0, 2.6, 0);
      trunk.castShadow = true;
      tree.add(trunk);

      // Heavy sprawling boughs reaching in 5 organic directions
      const boughAngles = [0, 1.3, 2.6, 3.9, 5.2];
      boughAngles.forEach((ang, idx) => {
        const boughGeo = new THREE.CylinderGeometry(0.16, 0.26, 3.2, 8);
        boughGeo.rotateZ(0.75);
        const bough = new THREE.Mesh(boughGeo, trunkMat);
        bough.position.set(0, 4.2 + (idx % 2) * 0.4, 0);
        bough.rotation.y = ang;
        bough.castShadow = true;
        tree.add(bough);

        // Secondary small branch
        const subGeo = new THREE.CylinderGeometry(0.08, 0.12, 1.8, 6);
        subGeo.rotateZ(0.5);
        const sub = new THREE.Mesh(subGeo, trunkMat);
        sub.position.set(Math.cos(ang) * 1.6, 5.2, Math.sin(ang) * 1.6);
        sub.rotation.y = ang + 0.4;
        tree.add(sub);
      });

      // Natural multi-cluster organic foliage
      const leafTex = ProceduralTextures.getLeafCanopyTexture('#2d6a2e');
      const canopyMat = new THREE.MeshStandardMaterial({
        map: leafTex,
        roughness: 0.68,
        color: 0x367e3a
      });

      const foliageClusters = [
        { x: 0, y: 6.2, z: 0, r: 2.8 },
        { x: 2.2, y: 5.4, z: 1.0, r: 2.2 },
        { x: -2.1, y: 5.6, z: -0.8, r: 2.1 },
        { x: 0.8, y: 5.3, z: 2.2, r: 2.2 },
        { x: -0.9, y: 5.5, z: -2.1, r: 2.2 },
        { x: 1.4, y: 6.6, z: -1.2, r: 1.9 },
        { x: -1.2, y: 6.8, z: 1.4, r: 1.9 },
        { x: 0, y: 7.6, z: 0, r: 2.0 }
      ];

      foliageClusters.forEach((c) => {
        const fGeo = new THREE.DodecahedronGeometry(c.r);
        const fMesh = new THREE.Mesh(fGeo, canopyMat);
        fMesh.position.set(c.x, c.y, c.z);
        fMesh.castShadow = true;
        tree.add(fMesh);
      });
    }

    this.treeSwayMeshes.push(tree);
    return tree;
  }

  // --- NATURAL WILD VEGETATION & WEED CLUMPS ---
  private buildWildVegetation() {
    // Scatter 3D grass clumps along road shoulders and canal banks
    const grassCount = 180;
    const grassGeo = new THREE.ConeGeometry(0.28, 0.7, 4);
    grassGeo.translate(0, 0.35, 0);

    const grassMat = new THREE.MeshStandardMaterial({
      color: 0x5b7e28,
      roughness: 0.82
    });

    const instancedGrass = new THREE.InstancedMesh(grassGeo, grassMat, grassCount);
    const dummy = new THREE.Object3D();

    let idx = 0;
    // Along North-South main brick road shoulders
    for (let z = -75; z < 85; z += 2.5) {
      if (idx >= grassCount) break;
      // Left verge
      dummy.position.set(-3.2 + (Math.random() - 0.5) * 0.8, 0.05, z + (Math.random() - 0.5) * 1.5);
      dummy.rotation.y = Math.random() * Math.PI * 2;
      const s = 0.7 + Math.random() * 0.6;
      dummy.scale.set(s, s * 1.2, s);
      dummy.updateMatrix();
      instancedGrass.setMatrixAt(idx++, dummy.matrix);

      if (idx >= grassCount) break;
      // Right verge
      dummy.position.set(3.2 + (Math.random() - 0.5) * 0.8, 0.05, z + (Math.random() - 0.5) * 1.5);
      dummy.rotation.y = Math.random() * Math.PI * 2;
      const s2 = 0.7 + Math.random() * 0.6;
      dummy.scale.set(s2, s2 * 1.2, s2);
      dummy.updateMatrix();
      instancedGrass.setMatrixAt(idx++, dummy.matrix);
    }

    instancedGrass.instanceMatrix.needsUpdate = true;
    instancedGrass.receiveShadow = true;
    this.scene.add(instancedGrass);
  }

  // --- REALISTIC HUMAN CHARACTER (PAKISTANI FARMER IN SHALWAR KAMEEZ & PAGRI) ---
  public createRealisticHumanCharacter(isSeated: boolean): THREE.Group {
    const character = new THREE.Group();

    const skinTex = ProceduralTextures.getHumanFaceTexture();
    const kurtaTex = ProceduralTextures.getKurtaFabricTexture('#1e40af'); // Deep royal blue cotton kurta
    const shalwarTex = ProceduralTextures.getKurtaFabricTexture('#f8fafc'); // Pure white cotton shalwar
    const pagriTex = ProceduralTextures.getPagriFabricTexture('#059669'); // Punjab emerald green pagri with gold border

    const skinMat = new THREE.MeshStandardMaterial({
      color: 0xc89874,
      roughness: 0.68,
      metalness: 0.08
    });

    const faceMat = new THREE.MeshStandardMaterial({
      map: skinTex,
      roughness: 0.65,
      metalness: 0.05
    });

    const kurtaMat = new THREE.MeshStandardMaterial({
      map: kurtaTex,
      bumpMap: kurtaTex,
      bumpScale: 0.06,
      roughness: 0.82
    });

    const shalwarMat = new THREE.MeshStandardMaterial({
      map: shalwarTex,
      bumpMap: shalwarTex,
      bumpScale: 0.05,
      roughness: 0.88
    });

    const pagriMat = new THREE.MeshStandardMaterial({
      map: pagriTex,
      bumpMap: pagriTex,
      bumpScale: 0.08,
      roughness: 0.78
    });

    const sandalMat = new THREE.MeshStandardMaterial({
      color: 0x2e1809,
      roughness: 0.6,
      metalness: 0.15
    });

    // 1. HEAD & DETAILED HUMAN FACE
    const headGroup = new THREE.Group();
    headGroup.position.set(0, isSeated ? 1.48 : 1.96, isSeated ? 0.04 : 0);

    // Cranium base with smooth facial curvature
    const craniumGeo = new THREE.CylinderGeometry(0.16, 0.14, 0.34, 16);
    const cranium = new THREE.Mesh(craniumGeo, skinMat);
    cranium.castShadow = true;
    headGroup.add(cranium);

    // Anatomical Face Front Plate with HD painted face texture (eyes, brows, mustache, stubble)
    const faceGeo = new THREE.PlaneGeometry(0.28, 0.32);
    const faceMesh = new THREE.Mesh(faceGeo, faceMat);
    faceMesh.position.set(0, 0.01, 0.15);
    headGroup.add(faceMesh);

    // 3D Sculpted Nose Bridge
    const noseGeo = new THREE.ConeGeometry(0.045, 0.13, 4);
    noseGeo.rotateX(Math.PI / 2.3);
    const nose = new THREE.Mesh(noseGeo, skinMat);
    nose.position.set(0, 0.01, 0.17);
    headGroup.add(nose);

    // 3D Groomed Mustache Bar
    const stacheMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
    const stacheGeo = new THREE.BoxGeometry(0.18, 0.04, 0.04);
    const stache = new THREE.Mesh(stacheGeo, stacheMat);
    stache.position.set(0, -0.065, 0.17);
    headGroup.add(stache);

    // Symmetrical 3D Sculpted Ears
    [-0.16, 0.16].forEach((ex) => {
      const earGeo = new THREE.CylinderGeometry(0.035, 0.045, 0.09, 8);
      earGeo.rotateZ(ex > 0 ? -0.2 : 0.2);
      const ear = new THREE.Mesh(earGeo, skinMat);
      ear.position.set(ex, 0, 0.02);
      headGroup.add(ear);
    });

    // Neck
    const neckGeo = new THREE.CylinderGeometry(0.1, 0.12, 0.16, 12);
    const neck = new THREE.Mesh(neckGeo, skinMat);
    neck.position.set(0, -0.2, 0);
    headGroup.add(neck);

    // 2. AUTHENTIC MULTI-TIERED PUNJABI PAGRI / TURBAN
    const turbanBaseGeo = new THREE.TorusGeometry(0.2, 0.075, 10, 24);
    turbanBaseGeo.rotateX(Math.PI / 2);
    const turbanBase = new THREE.Mesh(turbanBaseGeo, pagriMat);
    turbanBase.position.set(0, 0.13, 0);
    headGroup.add(turbanBase);

    // Crown Dome of Turban
    const turbanCrownGeo = new THREE.SphereGeometry(0.21, 16, 12);
    turbanCrownGeo.scale(1.0, 0.65, 1.05);
    const turbanCrown = new THREE.Mesh(turbanCrownGeo, pagriMat);
    turbanCrown.position.set(0, 0.21, 0);
    headGroup.add(turbanCrown);

    // Flared Shamla (Turban Crest / Kalgi on top)
    const shamlaGeo = new THREE.ConeGeometry(0.12, 0.28, 4);
    shamlaGeo.scale(1.2, 1.0, 0.3);
    const shamla = new THREE.Mesh(shamlaGeo, pagriMat);
    shamla.position.set(0, 0.38, -0.03);
    headGroup.add(shamla);

    // Dangling Palla (Turban fabric tail draping down the back of neck)
    const pallaGeo = new THREE.BoxGeometry(0.1, 0.32, 0.03);
    const palla = new THREE.Mesh(pallaGeo, pagriMat);
    palla.position.set(0.08, 0.02, -0.16);
    palla.rotateZ(0.15);
    headGroup.add(palla);

    character.add(headGroup);

    // 3. TORSO (COTTON KURTA KAMEEZ)
    const torsoGroup = new THREE.Group();
    torsoGroup.position.set(0, isSeated ? 0.98 : 1.34, 0);

    // Chest & abdomen block
    const chestGeo = new THREE.BoxGeometry(0.58, 0.72, 0.34);
    const chest = new THREE.Mesh(chestGeo, kurtaMat);
    chest.castShadow = true;
    torsoGroup.add(chest);

    // Standing Nehru Collar Band
    const collarGeo = new THREE.CylinderGeometry(0.14, 0.15, 0.07, 12);
    const collar = new THREE.Mesh(collarGeo, kurtaMat);
    collar.position.set(0, 0.39, 0);
    torsoGroup.add(collar);

    // Embroidered Front Neck Placket with Buttons
    const placketGeo = new THREE.BoxGeometry(0.09, 0.36, 0.03);
    const placket = new THREE.Mesh(placketGeo, kurtaMat);
    placket.position.set(0, 0.18, 0.17);
    torsoGroup.add(placket);

    // Pearl buttons
    const btnMat = new THREE.MeshStandardMaterial({ color: 0xffffff, metalness: 0.8 });
    [0.28, 0.18, 0.08].forEach((by) => {
      const btnGeo = new THREE.CylinderGeometry(0.015, 0.015, 0.02, 8);
      btnGeo.rotateX(Math.PI / 2);
      const btn = new THREE.Mesh(btnGeo, btnMat);
      btn.position.set(0, by, 0.185);
      torsoGroup.add(btn);
    });

    // Lower Kurta Draping Skirt
    const skirtGeo = new THREE.BoxGeometry(0.6, 0.32, 0.36);
    const skirt = new THREE.Mesh(skirtGeo, kurtaMat);
    skirt.position.set(0, -0.38, 0);
    torsoGroup.add(skirt);

    character.add(torsoGroup);

    // 4. LIMBS (SEATED DRIVER VS STANDING/WALKING FARMER)
    if (isSeated) {
      // --- SEATED TRACTOR DRIVER ---
      // Thighs extended forward onto tractor seat
      [-0.16, 0.16].forEach((lx) => {
        const thighGeo = new THREE.BoxGeometry(0.21, 0.21, 0.48);
        const thigh = new THREE.Mesh(thighGeo, shalwarMat);
        thigh.position.set(lx, 0.88, 0.22);
        character.add(thigh);

        // Lower legs (shins) bent downward toward foot pedals
        const shinGeo = new THREE.BoxGeometry(0.19, 0.48, 0.2);
        const shin = new THREE.Mesh(shinGeo, shalwarMat);
        shin.position.set(lx, 0.58, 0.44);
        character.add(shin);

        // Peshawari Sandal on foot pedals
        const shoeGeo = new THREE.BoxGeometry(0.18, 0.11, 0.32);
        const shoe = new THREE.Mesh(shoeGeo, sandalMat);
        shoe.position.set(lx, 0.34, 0.48);
        character.add(shoe);
      });

      // Arms reaching forward to hold steering wheel at 10 and 2 o'clock
      [-0.34, 0.34].forEach((ax, idx) => {
        const armGroup = new THREE.Group();
        armGroup.position.set(ax, 1.25, 0.06);

        // Upper arm angled forward
        const uArmGeo = new THREE.BoxGeometry(0.15, 0.34, 0.15);
        uArmGeo.rotateX(0.7);
        const uArm = new THREE.Mesh(uArmGeo, kurtaMat);
        armGroup.add(uArm);

        // Forearm reaching steering wheel rim
        const fArmGeo = new THREE.BoxGeometry(0.13, 0.34, 0.13);
        fArmGeo.rotateX(1.35);
        fArmGeo.rotateY(idx === 0 ? 0.3 : -0.3);
        const fArm = new THREE.Mesh(fArmGeo, kurtaMat);
        fArm.position.set(idx === 0 ? 0.12 : -0.12, -0.06, 0.28);
        armGroup.add(fArm);

        // Sculpted hand gripping steering wheel
        const handGeo = new THREE.BoxGeometry(0.09, 0.08, 0.12);
        const hand = new THREE.Mesh(handGeo, skinMat);
        hand.position.set(idx === 0 ? 0.16 : -0.16, -0.02, 0.46);
        armGroup.add(hand);

        character.add(armGroup);
      });
    } else {
      // --- STANDING / WALKING FARMER ---
      // Baggy Shalwar legs
      [-0.17, 0.17].forEach((lx) => {
        const legGroup = new THREE.Group();
        legGroup.position.set(lx, 0.55, 0);

        const legGeo = new THREE.BoxGeometry(0.24, 0.82, 0.28);
        const leg = new THREE.Mesh(legGeo, shalwarMat);
        leg.castShadow = true;
        legGroup.add(leg);

        // Peshawari Leather Sandals
        const shoeGeo = new THREE.BoxGeometry(0.2, 0.12, 0.34);
        const shoe = new THREE.Mesh(shoeGeo, sandalMat);
        shoe.position.set(0, -0.44, 0.04);
        shoe.castShadow = true;
        legGroup.add(shoe);

        // Curved sandal toe tip
        const toeGeo = new THREE.ConeGeometry(0.09, 0.12, 4);
        toeGeo.rotateX(Math.PI / 2);
        const toe = new THREE.Mesh(toeGeo, sandalMat);
        toe.position.set(0, -0.44, 0.22);
        legGroup.add(toe);

        character.add(legGroup);
      });

      // Natural arms at sides
      [-0.38, 0.38].forEach((ax) => {
        const armGroup = new THREE.Group();
        armGroup.position.set(ax, 1.25, 0);

        const armGeo = new THREE.BoxGeometry(0.16, 0.72, 0.17);
        const arm = new THREE.Mesh(armGeo, kurtaMat);
        arm.castShadow = true;
        armGroup.add(arm);

        // Hand with fingers
        const handGeo = new THREE.BoxGeometry(0.12, 0.18, 0.1);
        const hand = new THREE.Mesh(handGeo, skinMat);
        hand.position.set(0, -0.44, 0.02);
        armGroup.add(hand);

        character.add(armGroup);
      });
    }

    return character;
  }

  // --- PAKISTANI TRACTOR FLEET BUILDER (MF 385, FIAT 640, BELARUS 820, JOHN DEERE 6M) ---
  public buildPakistaniTractor(level: number = 1) {
    this.currentTractorLevel = level;
    this.tractorMesh = new THREE.Group();
    this.wheelMeshes = [];

    // Tractor model specs based on level
    let bodyColor = 0xc1121f; // MF 385 Classic Red
    let rimColor = 0xc1121f; // Red rims
    let brandKey: 'mf385' | 'nh640' | 'belarus' | 'jd' = 'mf385';
    let isCabin = false;
    let hasCanopy = true;
    let hasFrontWeights = false;

    if (level === 2) {
      // Al-Ghazi New Holland Fiat 640 (Iconic Pakistani Vibrant Orange)
      bodyColor = 0xea580c;
      rimColor = 0xf8fafc; // Classic White Fiat rims
      brandKey = 'nh640';
      hasCanopy = false;
    } else if (level === 3) {
      // Belarus 820 Heavy Duty (Soviet Crimson Red with Ballast Weights & Roll-Cage Cabin)
      bodyColor = 0x991b1b;
      rimColor = 0x18181b; // Black rims
      brandKey = 'belarus';
      isCabin = true;
      hasFrontWeights = true;
      hasCanopy = false;
    } else if (level === 4) {
      // John Deere 6M Modern Power (Signature Green & Yellow Rims with Panoramic Cab)
      bodyColor = 0x15803d; // Agricultural Green
      rimColor = 0xfacc15; // Golden Yellow rims
      brandKey = 'jd';
      isCabin = true;
      hasCanopy = false;
    }

    const bodyMat = new THREE.MeshStandardMaterial({
      color: bodyColor,
      roughness: 0.22,
      metalness: 0.32
    });

    const ironMat = new THREE.MeshStandardMaterial({
      color: 0x1f242d,
      roughness: 0.55,
      metalness: 0.8
    });

    // 1. Engine Hood (Bonnet)
    const hoodGeo = new THREE.BoxGeometry(1.22, 0.95, 2.05);
    const hood = new THREE.Mesh(hoodGeo, bodyMat);
    hood.position.set(0, 1.45, 0.5);
    hood.castShadow = true;
    this.tractorMesh.add(hood);

    // Front Chrome/Silver Grill with air slots
    const grillGeo = new THREE.BoxGeometry(1.12, 0.76, 0.06);
    const grillMat = new THREE.MeshStandardMaterial({
      color: level === 2 ? 0xf8fafc : 0xd1d5db,
      metalness: 0.85,
      roughness: 0.2
    });
    const grill = new THREE.Mesh(grillGeo, grillMat);
    grill.position.set(0, 1.45, 1.54);
    this.tractorMesh.add(grill);

    // Front Brand Badge Decal (MF 385, Fiat 640, Belarus, John Deere)
    const badgeTex = ProceduralTextures.getBrandBadgeTexture(brandKey);
    const badgeGeo = new THREE.PlaneGeometry(0.36, 0.18);
    const badgeMat = new THREE.MeshStandardMaterial({
      map: badgeTex,
      metalness: 0.6,
      roughness: 0.3
    });
    const badge = new THREE.Mesh(badgeGeo, badgeMat);
    badge.position.set(0, 1.6, 1.58);
    this.tractorMesh.add(badge);

    // Cyclone Air Pre-Cleaner (high-mounted glass/fiber bowl on right bonnet side)
    const cycloneStemGeo = new THREE.CylinderGeometry(0.045, 0.045, 0.85, 8);
    const cycloneStem = new THREE.Mesh(cycloneStemGeo, ironMat);
    cycloneStem.position.set(-0.48, 2.12, 1.1);
    this.tractorMesh.add(cycloneStem);

    const cycloneBowlGeo = new THREE.CylinderGeometry(0.15, 0.11, 0.24, 12);
    const cycloneBowlMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.2, transparent: true, opacity: 0.78 });
    const cycloneBowl = new THREE.Mesh(cycloneBowlGeo, cycloneBowlMat);
    cycloneBowl.position.set(-0.48, 2.54, 1.1);
    this.tractorMesh.add(cycloneBowl);

    // Dual Round High-Intensity Headlights
    const lightMat = new THREE.MeshStandardMaterial({ color: 0xfffbeb, emissive: 0xfef08a, emissiveIntensity: 0.85 });
    [-0.38, 0.38].forEach((lx) => {
      const hlGeo = new THREE.CylinderGeometry(0.12, 0.12, 0.1, 16);
      hlGeo.rotateX(Math.PI / 2);
      const hl = new THREE.Mesh(hlGeo, lightMat);
      hl.position.set(lx, 1.55, 1.56);
      this.tractorMesh.add(hl);
    });

    // 2. Heavy Front Bumper & Suitcase Ballast Weights
    if (hasFrontWeights) {
      // Belarus 6 front suitcase weights
      const weightGroup = new THREE.Group();
      weightGroup.position.set(0, 0.85, 1.75);
      for (let w = -0.5; w <= 0.5; w += 0.2) {
        const wGeo = new THREE.BoxGeometry(0.16, 0.45, 0.35);
        const wMesh = new THREE.Mesh(wGeo, ironMat);
        wMesh.position.set(w, 0, 0);
        weightGroup.add(wMesh);
      }
      this.tractorMesh.add(weightGroup);
    } else {
      // Pakistani Truck-Art Decorated Heavy Guard Bumper
      const bumperGroup = new THREE.Group();
      bumperGroup.position.set(0, 0.85, 1.8);

      const bumperBeamGeo = new THREE.BoxGeometry(1.95, 0.36, 0.2);
      const bumperBeamMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b, metalness: 0.4 });
      const bumperBeam = new THREE.Mesh(bumperBeamGeo, bumperBeamMat);
      bumperGroup.add(bumperBeam);

      [-0.6, -0.2, 0.2, 0.6].forEach((bx, idx) => {
        const stripeGeo = new THREE.BoxGeometry(0.24, 0.38, 0.22);
        const stripeMat = new THREE.MeshStandardMaterial({
          color: idx % 2 === 0 ? 0x0284c7 : 0xdc2626
        });
        const stripe = new THREE.Mesh(stripeGeo, stripeMat);
        stripe.position.set(bx, 0, 0);
        bumperGroup.add(stripe);
      });

      this.tractorMesh.add(bumperGroup);
    }

    // 3. Tall Vertical Diesel Exhaust Stack
    const exhaustGeo = new THREE.CylinderGeometry(0.065, 0.065, 1.65, 12);
    const exhaustMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.85, roughness: 0.3 });
    const exhaust = new THREE.Mesh(exhaustGeo, exhaustMat);
    exhaust.position.set(0.48, 2.35, 0.9);
    this.tractorMesh.add(exhaust);

    // Flapper cap
    const flapperGeo = new THREE.BoxGeometry(0.15, 0.03, 0.15);
    const flapper = new THREE.Mesh(flapperGeo, exhaustMat);
    flapper.position.set(0.48, 3.18, 0.9);
    this.tractorMesh.add(flapper);

    // 4. Platform, Fenders, & Seat
    const platformGeo = new THREE.BoxGeometry(1.65, 0.15, 1.55);
    const platform = new THREE.Mesh(platformGeo, ironMat);
    platform.position.set(0, 0.95, -0.7);
    this.tractorMesh.add(platform);

    const seatGeo = new THREE.BoxGeometry(0.65, 0.15, 0.6);
    const seatMat = new THREE.MeshStandardMaterial({ color: 0x111827, roughness: 0.8 });
    const seat = new THREE.Mesh(seatGeo, seatMat);
    seat.position.set(0, 1.4, -0.85);
    this.tractorMesh.add(seat);

    const backGeo = new THREE.BoxGeometry(0.65, 0.5, 0.12);
    const back = new THREE.Mesh(backGeo, seatMat);
    back.position.set(0, 1.7, -1.1);
    this.tractorMesh.add(back);

    // Steering Column & Wheel
    const colGeo = new THREE.CylinderGeometry(0.04, 0.04, 0.72);
    colGeo.rotateX(Math.PI / 4);
    const col = new THREE.Mesh(colGeo, ironMat);
    col.position.set(0, 1.62, -0.35);
    this.tractorMesh.add(col);

    const wheelGeo = new THREE.TorusGeometry(0.25, 0.032, 8, 24);
    wheelGeo.rotateX(Math.PI / 4);
    const steerWheel = new THREE.Mesh(wheelGeo, ironMat);
    steerWheel.position.set(0, 1.88, -0.55);
    this.tractorMesh.add(steerWheel);

    // Rear Curved Fenders
    [-0.88, 0.88].forEach((fx) => {
      const fenderGeo = new THREE.BoxGeometry(0.36, 0.88, 1.65);
      const fender = new THREE.Mesh(fenderGeo, bodyMat);
      fender.position.set(fx, 1.65, -0.85);
      this.tractorMesh.add(fender);
    });

    // 5. CABIN VS CANOPY (CHHATRI)
    if (isCabin) {
      // Enclosed Safety Driver Cabin with Dark Tinted Glass
      const glassMat = new THREE.MeshStandardMaterial({
        color: 0x0f172a,
        roughness: 0.1,
        metalness: 0.9,
        transparent: true,
        opacity: 0.65
      });
      const cabFrameMat = ironMat;

      // Cabin Roof
      const cabRoofGeo = new THREE.BoxGeometry(1.68, 0.14, 1.7);
      const cabRoof = new THREE.Mesh(cabRoofGeo, bodyMat);
      cabRoof.position.set(0, 2.9, -0.7);
      this.tractorMesh.add(cabRoof);

      // 4 Cabin corner pillars
      [[-0.8, -0.05], [0.8, -0.05], [-0.8, -1.5], [0.8, -1.5]].forEach(([cx, cz]) => {
        const pillarGeo = new THREE.BoxGeometry(0.08, 1.8, 0.08);
        const pillar = new THREE.Mesh(pillarGeo, cabFrameMat);
        pillar.position.set(cx, 1.95, cz);
        this.tractorMesh.add(pillar);
      });

      // Front windshield & side windows
      const windGeo = new THREE.BoxGeometry(1.56, 1.6, 0.05);
      const wind = new THREE.Mesh(windGeo, glassMat);
      wind.position.set(0, 1.95, -0.05);
      this.tractorMesh.add(wind);
    } else if (hasCanopy) {
      // Classic Pakistani Weather Canopy (White fiberglass Chhatri on 4 white steel support arches)
      const canopyMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc, roughness: 0.3 });
      const roofGeo = new THREE.BoxGeometry(1.7, 0.08, 1.85);
      const roof = new THREE.Mesh(roofGeo, canopyMat);
      roof.position.set(0, 2.95, -0.7);
      this.tractorMesh.add(roof);

      // 4 Curved White Tubular Support Pillars
      [[-0.78, -0.1], [0.78, -0.1], [-0.78, -1.45], [0.78, -1.45]].forEach(([px, pz]) => {
        const poleGeo = new THREE.CylinderGeometry(0.035, 0.035, 1.85, 8);
        const pole = new THREE.Mesh(poleGeo, canopyMat);
        pole.position.set(px, 2.0, pz);
        this.tractorMesh.add(pole);
      });
    }

    // 6. WHEELS & TIRES WITH CHEVRON LUG TREAD
    const tireTreadTex = ProceduralTextures.getTireTreadTexture();
    const tireMat = new THREE.MeshStandardMaterial({
      map: tireTreadTex,
      bumpMap: tireTreadTex,
      bumpScale: 0.16,
      color: 0x171717,
      roughness: 0.92
    });
    const rimMat = new THREE.MeshStandardMaterial({ color: rimColor, metalness: 0.5, roughness: 0.4 });

    // Front Wheels
    [-0.76, 0.76].forEach((wx) => {
      const wheelGroup = new THREE.Group();
      wheelGroup.position.set(wx, 0.55, 1.2);

      const fTireGeo = new THREE.CylinderGeometry(0.48, 0.48, 0.32, 20);
      fTireGeo.rotateZ(Math.PI / 2);
      const fTire = new THREE.Mesh(fTireGeo, tireMat);
      fTire.castShadow = true;
      wheelGroup.add(fTire);

      const fRimGeo = new THREE.CylinderGeometry(0.26, 0.26, 0.34, 16);
      fRimGeo.rotateZ(Math.PI / 2);
      const fRim = new THREE.Mesh(fRimGeo, rimMat);
      wheelGroup.add(fRim);

      this.tractorMesh.add(wheelGroup);
      this.wheelMeshes.push(fTire);
    });

    // Rear Huge Wheels with Heavy Agricultural Chevron Lugs
    [-0.96, 0.96].forEach((wx) => {
      const wheelGroup = new THREE.Group();
      wheelGroup.position.set(wx, 0.88, -0.85);

      const rTireGeo = new THREE.CylinderGeometry(0.88, 0.88, 0.54, 24);
      rTireGeo.rotateZ(Math.PI / 2);
      const rTire = new THREE.Mesh(rTireGeo, tireMat);
      rTire.castShadow = true;
      wheelGroup.add(rTire);

      const rRimGeo = new THREE.CylinderGeometry(0.52, 0.52, 0.56, 18);
      rRimGeo.rotateZ(Math.PI / 2);
      const rRim = new THREE.Mesh(rRimGeo, rimMat);
      wheelGroup.add(rRim);

      this.tractorMesh.add(wheelGroup);
      this.wheelMeshes.push(rTire);
    });

    // 7. Rear 3-Point Hitch with Dual Tow Chains and Bright Red Rigging Hooks (Photo 4)
    const hitchGeo = new THREE.BoxGeometry(0.65, 0.42, 0.32);
    const hitch = new THREE.Mesh(hitchGeo, ironMat);
    hitch.position.set(0, 0.7, -1.62);
    this.tractorMesh.add(hitch);

    // Authentic dual hanging tow chains with red safety hooks
    const hookMat = new THREE.MeshStandardMaterial({ color: 0xdc2626, metalness: 0.6, roughness: 0.3 }); // Red forged steel hooks
    [-0.22, 0.22].forEach((hx) => {
      const chainGeo = new THREE.CylinderGeometry(0.02, 0.02, 0.45, 6);
      chainGeo.rotateX(0.2);
      const chain = new THREE.Mesh(chainGeo, ironMat);
      chain.position.set(hx, 0.52, -1.78);
      this.tractorMesh.add(chain);

      // Red forged hook at end of chain
      const hookGeo = new THREE.TorusGeometry(0.06, 0.02, 6, 12, Math.PI * 1.5);
      const hook = new THREE.Mesh(hookGeo, hookMat);
      hook.position.set(hx, 0.32, -1.82);
      this.tractorMesh.add(hook);
    });

    // 8. SEATED HUMAN DRIVER IN TRACTOR
    this.seatedDriverMesh = this.createRealisticHumanCharacter(true);
    this.seatedDriverMesh.position.set(0, 0.48, -0.85);
    this.seatedDriverMesh.visible = false; // Initially visible only when player enters tractor
    this.tractorMesh.add(this.seatedDriverMesh);

    // Add attached implement container
    this.tractorMesh.add(this.attachedImplementMesh);

    // Initial position
    this.tractorMesh.position.set(-8, 0, 8);
    this.scene.add(this.tractorMesh);
  }

  // Hot rebuild tractor model when upgraded
  public rebuildTractor(level: number) {
    const prevPos = this.tractorMesh.position.clone();
    const prevRotY = this.tractorMesh.rotation.y;

    this.scene.remove(this.tractorMesh);
    this.buildPakistaniTractor(level);

    this.tractorMesh.position.copy(prevPos);
    this.tractorMesh.rotation.y = prevRotY;
  }

  // --- TRACTOR ATTACHMENT SYSTEM (ACCURATE AGRICULTURAL IMPLEMENTS) ---
  public updateAttachedImplement(implementType: ImplementType) {
    // Clear current attached visual
    while (this.attachedImplementMesh.children.length > 0) {
      this.attachedImplementMesh.remove(this.attachedImplementMesh.children[0]);
    }

    if (implementType === 'none') {
      return;
    }

    const steelMat = new THREE.MeshStandardMaterial({ color: 0x27272a, metalness: 0.85, roughness: 0.4 });
    const orangeMat = new THREE.MeshStandardMaterial({ color: 0xea580c, metalness: 0.35, roughness: 0.4 }); // Authentic Rotavator Orange (Photo 1)
    const sonalikaBlueMat = new THREE.MeshStandardMaterial({ color: 0x1d4ed8, metalness: 0.4, roughness: 0.35 }); // Authentic Sonalika Tiller Blue (Photo 2)
    const redMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c });

    if (implementType === 'plough') {
      // 3-Bottom Mouldboard Reversible Plough (Hal)
      const frameGeo = new THREE.BoxGeometry(0.2, 0.2, 2.2);
      const frame = new THREE.Mesh(frameGeo, steelMat);
      frame.position.set(0, 0.6, -1.2);
      this.attachedImplementMesh.add(frame);

      [-0.7, 0, 0.7].forEach((px, i) => {
        const shareGeo = new THREE.ConeGeometry(0.32, 0.65, 4);
        shareGeo.rotateZ(Math.PI / 3);
        const share = new THREE.Mesh(shareGeo, steelMat);
        share.position.set(px * 0.5, 0.25, -0.6 - i * 0.6);
        this.attachedImplementMesh.add(share);
      });
    } else if (implementType === 'cultivator') {
      // Sonalika Spring-Loaded 9-Tine Tiller / Cultivator (Matching Photo 2)
      // Bright Royal Blue rectangular dual-beam box frame
      const frameGroup = new THREE.Group();
      frameGroup.position.set(0, 0.6, -1.1);

      // Front & rear crossbeams
      [-0.25, 0.25].forEach((bz) => {
        const beamGeo = new THREE.BoxGeometry(2.5, 0.16, 0.16);
        const beam = new THREE.Mesh(beamGeo, sonalikaBlueMat);
        beam.position.set(0, 0, bz);
        frameGroup.add(beam);
      });

      // 3-Point Hitch Triangular A-Frame Mast
      const mastGeo = new THREE.BoxGeometry(0.12, 0.75, 0.12);
      [-0.45, 0.45].forEach((mx, mi) => {
        const mast = new THREE.Mesh(mastGeo, sonalikaBlueMat);
        mast.rotateZ((mi === 0 ? 1 : -1) * 0.4);
        mast.position.set(mx, 0.4, 0);
        frameGroup.add(mast);
      });

      // Center "SONALIKA TILLER" brand badge plate
      const badgePlateGeo = new THREE.BoxGeometry(0.8, 0.22, 0.04);
      const badgePlateMat = new THREE.MeshStandardMaterial({ color: 0xf8fafc });
      const badgePlate = new THREE.Mesh(badgePlateGeo, badgePlateMat);
      badgePlate.position.set(0, 0.45, 0.08);
      frameGroup.add(badgePlate);

      // 9 Spring-Loaded Tines with Dual Coiled Springs (Matching Photo 2)
      const springMat = new THREE.MeshStandardMaterial({ color: 0x18181b, metalness: 0.9, roughness: 0.2 });
      const tineSpacing = [-1.0, -0.75, -0.5, -0.25, 0, 0.25, 0.5, 0.75, 1.0];
      tineSpacing.forEach((tx, idx) => {
        const zOffset = idx % 2 === 0 ? 0.25 : -0.25;

        // Dual heavy coil springs on top of shank
        const springGeo = new THREE.CylinderGeometry(0.06, 0.06, 0.28, 8);
        const spring = new THREE.Mesh(springGeo, springMat);
        spring.position.set(tx, 0.12, zOffset);
        frameGroup.add(spring);

        // Curved forged black steel tine shank
        const tineGeo = new THREE.CylinderGeometry(0.04, 0.02, 0.68, 6);
        tineGeo.rotateX(0.25);
        const tine = new THREE.Mesh(tineGeo, steelMat);
        tine.position.set(tx, -0.28, zOffset - 0.08);
        frameGroup.add(tine);
      });

      this.attachedImplementMesh.add(frameGroup);
    } else if (implementType === 'rotavator') {
      // Heavy-Duty Agricultural Rotavator / Rotary Tiller (Matching Photo 1)
      // Bright Orange tubular frame with side gear drive & rotating C-blades
      const rotaGroup = new THREE.Group();
      rotaGroup.position.set(0, 0.55, -1.2);

      // Main tubular orange beam
      const beamGeo = new THREE.CylinderGeometry(0.12, 0.12, 2.6, 12);
      beamGeo.rotateZ(Math.PI / 2);
      const beam = new THREE.Mesh(beamGeo, orangeMat);
      rotaGroup.add(beam);

      // Triangular 3-Point Hitch Mast
      const mastGeo = new THREE.BoxGeometry(0.14, 0.8, 0.12);
      [-0.4, 0.4].forEach((mx, mi) => {
        const mast = new THREE.Mesh(mastGeo, orangeMat);
        mast.rotateZ((mi === 0 ? 1 : -1) * 0.42);
        mast.position.set(mx, 0.45, 0);
        rotaGroup.add(mast);
      });

      // Left-side heavy gear drive transmission casing
      const gearBoxGeo = new THREE.BoxGeometry(0.32, 0.72, 0.65);
      const gearBox = new THREE.Mesh(gearBoxGeo, orangeMat);
      gearBox.position.set(-1.3, -0.05, 0);
      rotaGroup.add(gearBox);

      // Telescoping Yellow & Black PTO Drive Shaft to Tractor PTO
      const ptoGeo = new THREE.CylinderGeometry(0.05, 0.05, 0.7, 8);
      ptoGeo.rotateX(Math.PI / 2);
      const ptoMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.4 });
      const pto = new THREE.Mesh(ptoGeo, ptoMat);
      pto.position.set(0, 0.15, 0.45);
      rotaGroup.add(pto);

      // Central Rotor Shaft with Curved Black Forged C-Blades/Tines
      const rotorGeo = new THREE.CylinderGeometry(0.08, 0.08, 2.4, 12);
      rotorGeo.rotateZ(Math.PI / 2);
      const rotor = new THREE.Mesh(rotorGeo, steelMat);
      rotor.position.set(0, -0.22, 0);
      rotaGroup.add(rotor);

      // 12 Curved C-blades distributed along rotor shaft
      for (let rx = -1.1; rx <= 1.1; rx += 0.2) {
        const bladeGeo = new THREE.TorusGeometry(0.24, 0.025, 4, 12, Math.PI);
        const blade = new THREE.Mesh(bladeGeo, steelMat);
        blade.position.set(rx, -0.22, 0);
        blade.rotation.x = Math.random() * Math.PI * 2;
        rotaGroup.add(blade);
      }

      // Rear Trailing Leveling Flap / Hood with tension chains
      const flapGeo = new THREE.BoxGeometry(2.55, 0.06, 0.55);
      flapGeo.rotateX(0.4);
      const flap = new THREE.Mesh(flapGeo, orangeMat);
      flap.position.set(0, -0.05, -0.38);
      rotaGroup.add(flap);

      this.attachedImplementMesh.add(rotaGroup);
    } else if (implementType === 'seed_drill') {
      // Rabi Seed Drill with grain hopper & fertilizer box
      const hopperGeo = new THREE.BoxGeometry(2.4, 0.65, 0.65);
      const hopper = new THREE.Mesh(hopperGeo, redMat);
      hopper.position.set(0, 1.05, -1.1);
      this.attachedImplementMesh.add(hopper);

      // Drop tubes and disc coulters
      for (let sx = -1.0; sx <= 1.0; sx += 0.25) {
        const tubeGeo = new THREE.CylinderGeometry(0.03, 0.03, 0.75);
        const tube = new THREE.Mesh(tubeGeo, steelMat);
        tube.position.set(sx, 0.48, -1.1);
        this.attachedImplementMesh.add(tube);
      }
    } else if (implementType === 'fertilizer_spreader') {
      // Conical Khaad Spreader Hopper
      const coneGeo = new THREE.ConeGeometry(0.72, 0.95, 12);
      coneGeo.rotateX(Math.PI);
      const coneMat = new THREE.MeshStandardMaterial({ color: 0xeab308 });
      const cone = new THREE.Mesh(coneGeo, coneMat);
      cone.position.set(0, 1.05, -0.9);
      this.attachedImplementMesh.add(cone);

      // Spinning broadcast disc
      const discGeo = new THREE.CylinderGeometry(0.38, 0.38, 0.05);
      const disc = new THREE.Mesh(discGeo, steelMat);
      disc.position.set(0, 0.45, -0.9);
      this.attachedImplementMesh.add(disc);
    } else if (implementType === 'sprayer') {
      // Boom Crop Sprayer with wide folding wings
      const tankGeo = new THREE.CylinderGeometry(0.42, 0.42, 1.3, 12);
      const tankMat = new THREE.MeshStandardMaterial({ color: 0x0284c7 });
      const tank = new THREE.Mesh(tankGeo, tankMat);
      tank.position.set(0, 1.05, -0.8);
      this.attachedImplementMesh.add(tank);

      const boomGeo = new THREE.BoxGeometry(5.2, 0.08, 0.08);
      const boom = new THREE.Mesh(boomGeo, steelMat);
      boom.position.set(0, 0.8, -1.2);
      this.attachedImplementMesh.add(boom);
    } else if (implementType === 'harvester_cutter') {
      // Harvester Cutter Head
      const reelGeo = new THREE.CylinderGeometry(0.48, 0.48, 3.4, 8);
      reelGeo.rotateZ(Math.PI / 2);
      const reel = new THREE.Mesh(reelGeo, steelMat);
      reel.position.set(0, 0.7, 2.2);
      this.attachedImplementMesh.add(reel);
    } else if (implementType === 'trolley') {
      // Hand-Painted Pakistani Wooden Tractor Trolley with Truck Art (Matching Photo 5)
      const trolleyGroup = this.createPakistaniTrolley();
      trolleyGroup.position.set(0, 0, -2.8);
      this.attachedImplementMesh.add(trolleyGroup);
    }

    this.tractorMesh.add(this.attachedImplementMesh);
  }

  // Hand-Painted Pakistani Farm Trolley with High-Wall Welded Pipe Extension (Jalli / Katta) - Matching Photo 5
  private createPakistaniTrolley(): THREE.Group {
    const trolley = new THREE.Group();
    const trailerBlueMat = new THREE.MeshStandardMaterial({ color: 0x0284c7, metalness: 0.4, roughness: 0.5 }); // Blue chassis
    const yellowRimMat = new THREE.MeshStandardMaterial({ color: 0xfacc15, metalness: 0.5, roughness: 0.3 }); // Yellow rims (Photo 5)
    const ironMat = new THREE.MeshStandardMaterial({ color: 0x1f2937, metalness: 0.85 });

    // Drawbar hitch to tractor
    const drawbarGeo = new THREE.BoxGeometry(0.18, 0.16, 1.7);
    const drawbar = new THREE.Mesh(drawbarGeo, ironMat);
    drawbar.position.set(0, 0.55, 0.85);
    trolley.add(drawbar);

    // Bed Platform (Trolley Farash)
    const bedGeo = new THREE.BoxGeometry(2.4, 0.22, 4.2);
    const bed = new THREE.Mesh(bedGeo, trailerBlueMat);
    bed.position.set(0, 0.82, -1.2);
    trolley.add(bed);

    // Solid Lower Sideboards (Patrey)
    [-1.2, 1.2].forEach((sx) => {
      const sideGeo = new THREE.BoxGeometry(0.1, 0.85, 4.2);
      const side = new THREE.Mesh(sideGeo, trailerBlueMat);
      side.position.set(sx, 1.35, -1.2);
      trolley.add(side);

      // Yellow Pakistani Truck-Art decorative stripe
      const stripeGeo = new THREE.BoxGeometry(0.12, 0.22, 4.1);
      const stripeMat = new THREE.MeshStandardMaterial({ color: 0xf59e0b });
      const stripe = new THREE.Mesh(stripeGeo, stripeMat);
      stripe.position.set(sx, 1.4, -1.2);
      trolley.add(stripe);
    });

    // Tall Welded Steel Pipe High-Wall Extension Cage (Jalli / Katta Extension - Signature Pakistani feature from Photo 5)
    const pipeMat = new THREE.MeshStandardMaterial({ color: 0x475569, metalness: 0.8, roughness: 0.4 });
    [-1.2, 1.2].forEach((sx) => {
      // 5 vertical support posts
      for (let pz = -3.2; pz <= 0.8; pz += 1.0) {
        const postGeo = new THREE.CylinderGeometry(0.035, 0.035, 1.1, 8);
        const post = new THREE.Mesh(postGeo, pipeMat);
        post.position.set(sx, 2.3, pz);
        trolley.add(post);
      }
      // 3 horizontal rails
      [1.95, 2.35, 2.8].forEach((ry) => {
        const railGeo = new THREE.BoxGeometry(0.04, 0.04, 4.2);
        const rail = new THREE.Mesh(railGeo, pipeMat);
        rail.position.set(sx, ry, -1.2);
        trolley.add(rail);
      });
    });

    // Front & Tailgate Boards
    const frontGeo = new THREE.BoxGeometry(2.4, 1.8, 0.1);
    const front = new THREE.Mesh(frontGeo, trailerBlueMat);
    front.position.set(0, 1.8, 0.9);
    trolley.add(front);

    const backGeo = new THREE.BoxGeometry(2.4, 0.85, 0.1);
    const back = new THREE.Mesh(backGeo, trailerBlueMat);
    back.position.set(0, 1.35, -3.3);
    trolley.add(back);

    // Tandem Dual-Axle Wheels with Bright Yellow Rims & Double Tires (Matching Photo 5)
    [-1.3, 1.3].forEach((wx) => {
      [-1.1, -2.1].forEach((wz) => {
        const tWheelGeo = new THREE.CylinderGeometry(0.68, 0.68, 0.38, 20);
        tWheelGeo.rotateZ(Math.PI / 2);
        const tTireMat = new THREE.MeshStandardMaterial({ color: 0x18181b, roughness: 0.9 });
        const tWheel = new THREE.Mesh(tWheelGeo, tTireMat);
        tWheel.position.set(wx, 0.68, wz);

        // Yellow rim
        const tRimGeo = new THREE.CylinderGeometry(0.42, 0.42, 0.4, 16);
        tRimGeo.rotateZ(Math.PI / 2);
        const tRim = new THREE.Mesh(tRimGeo, yellowRimMat);
        tWheel.add(tRim);

        trolley.add(tWheel);
      });
    });

    return trolley;
  }

  // --- PLAYER CHARACTER INITIALIZATION ---
  public buildFarmerCharacter() {
    // Standing farmer character model with authentic human face and shalwar kameez
    this.playerMesh = this.createRealisticHumanCharacter(false);
    this.playerMesh.position.set(-10, 0, 10);
    this.scene.add(this.playerMesh);
  }

  // --- WEATHER PARTICLES (RAIN) ---
  private initWeatherParticles() {
    const rainCount = 1800;
    const rainGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(rainCount * 3);

    for (let i = 0; i < rainCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 160;
      positions[i + 1] = Math.random() * 50;
      positions[i + 2] = (Math.random() - 0.5) * 160;
    }

    rainGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const rainMat = new THREE.PointsMaterial({
      color: 0x93c5fd,
      size: 0.25,
      transparent: true,
      opacity: 0.75
    });

    this.rainParticles = new THREE.Points(rainGeo, rainMat);
    this.rainParticles.visible = false;
    this.scene.add(this.rainParticles);
  }

  // Animate rain fall
  public updateRain(delta: number, active: boolean, centerPos: THREE.Vector3) {
    if (!this.rainParticles) return;
    this.rainParticles.visible = active;
    if (!active) return;

    this.rainParticles.position.set(centerPos.x, 0, centerPos.z);
    const pos = this.rainParticles.geometry.attributes.position;
    for (let i = 1; i < pos.count * 3; i += 3) {
      let y = pos.array[i];
      y -= delta * 38;
      if (y < 0) y = 45;
      pos.array[i] = y;
    }
    pos.needsUpdate = true;
  }

  // Spawn exhaust smoke puff from tractor chimney
  public spawnExhaustPuff(tractorPos: THREE.Vector3, tractorRotY: number, isRevving: boolean) {
    if (this.exhaustParticles.length > 25) return;

    const puffGeo = new THREE.SphereGeometry(0.12 + Math.random() * 0.08, 6, 6);
    const puffMat = new THREE.MeshBasicMaterial({
      color: isRevving ? 0x27272a : 0x71717a, // Black diesel smoke when revving!
      transparent: true,
      opacity: 0.65
    });
    const puff = new THREE.Mesh(puffGeo, puffMat);

    // Calculate exhaust pipe global position
    const offset = new THREE.Vector3(0.48, 3.15, 0.9);
    offset.applyAxisAngle(new THREE.Vector3(0, 1, 0), tractorRotY);
    puff.position.copy(tractorPos).add(offset);

    const vel = new THREE.Vector3(
      (Math.random() - 0.5) * 0.4,
      1.5 + Math.random() * 1.0,
      (Math.random() - 0.5) * 0.4
    );

    this.scene.add(puff);
    this.exhaustParticles.push({ mesh: puff, life: 1.0, velocity: vel });
  }

  public updateExhaustParticles(delta: number) {
    for (let i = this.exhaustParticles.length - 1; i >= 0; i--) {
      const p = this.exhaustParticles[i];
      p.life -= delta * 1.6;
      p.mesh.position.addScaledVector(p.velocity, delta);
      p.mesh.scale.multiplyScalar(1 + delta * 1.8);
      (p.mesh.material as THREE.MeshBasicMaterial).opacity = p.life * 0.6;

      if (p.life <= 0) {
        this.scene.remove(p.mesh);
        p.mesh.geometry.dispose();
        this.exhaustParticles.splice(i, 1);
      }
    }
  }

  // --- BIRDS FLOCK (KABOOTAR & EAGLES CIRCLING IN PUNJABI SKY) ---
  private buildBirdsFlock() {
    const pigeonMat = new THREE.MeshStandardMaterial({ color: 0x64748b, roughness: 0.7 }); // Blue-grey pigeon feathers
    const whiteMat = new THREE.MeshStandardMaterial({ color: 0xf1f5f9, roughness: 0.6 });
    const beakMat = new THREE.MeshStandardMaterial({ color: 0xf97316 });

    // 2 Flock Centers: One over the green fields, one near the tube well & haveli
    const flockCenters = [
      new THREE.Vector3(-25, 0, 15),
      new THREE.Vector3(20, 0, -20)
    ];

    for (let i = 0; i < 14; i++) {
      const birdGroup = new THREE.Group();

      // Fusiform streamlined bird body
      const bodyGeo = new THREE.ConeGeometry(0.12, 0.48, 6);
      bodyGeo.rotateX(Math.PI / 2);
      const isWhite = i % 3 === 0;
      const bMat = isWhite ? whiteMat : pigeonMat;
      const body = new THREE.Mesh(bodyGeo, bMat);
      birdGroup.add(body);

      // Head & Beak
      const headGeo = new THREE.SphereGeometry(0.08, 6, 6);
      const head = new THREE.Mesh(headGeo, bMat);
      head.position.set(0, 0.04, 0.28);
      birdGroup.add(head);

      const beakGeo = new THREE.ConeGeometry(0.025, 0.08, 4);
      beakGeo.rotateX(Math.PI / 2);
      const beak = new THREE.Mesh(beakGeo, beakMat);
      beak.position.set(0, 0.03, 0.36);
      birdGroup.add(beak);

      // Fan-shaped tail feathers
      const tailGeo = new THREE.BoxGeometry(0.18, 0.02, 0.22);
      const tail = new THREE.Mesh(tailGeo, bMat);
      tail.position.set(0, 0.02, -0.32);
      birdGroup.add(tail);

      // Left Wing with pivot hinge at shoulder
      const wingGeo = new THREE.BoxGeometry(0.55, 0.02, 0.16);
      wingGeo.translate(0.275, 0, 0); // Offset origin to shoulder
      const leftWing = new THREE.Mesh(wingGeo, bMat);
      leftWing.position.set(0.06, 0.04, 0.08);
      birdGroup.add(leftWing);

      // Right Wing with pivot hinge at shoulder
      const rWingGeo = new THREE.BoxGeometry(0.55, 0.02, 0.16);
      rWingGeo.translate(-0.275, 0, 0);
      const rightWing = new THREE.Mesh(rWingGeo, bMat);
      rightWing.position.set(-0.06, 0.04, 0.08);
      birdGroup.add(rightWing);

      const center = flockCenters[i % flockCenters.length];
      const radius = 18 + (i % 6) * 5;
      const baseHeight = 22 + (i % 5) * 4;
      const angle = (i / 14) * Math.PI * 2;

      birdGroup.position.set(
        center.x + Math.cos(angle) * radius,
        baseHeight,
        center.z + Math.sin(angle) * radius
      );

      this.scene.add(birdGroup);

      this.birds.push({
        group: birdGroup,
        leftWing,
        rightWing,
        center,
        radius,
        angle,
        speed: 0.35 + (i % 3) * 0.08,
        flapSpeed: 10 + (i % 4) * 2,
        baseHeight
      });
    }
  }

  public updateBirds(delta: number) {
    const time = performance.now() * 0.001;

    this.birds.forEach((bird) => {
      bird.angle += bird.speed * delta;

      // Circular flight trajectory
      bird.group.position.x = bird.center.x + Math.cos(bird.angle) * bird.radius;
      bird.group.position.z = bird.center.z + Math.sin(bird.angle) * bird.radius;
      bird.group.position.y = bird.baseHeight + Math.sin(bird.angle * 2.2) * 1.6;

      // Orient forward along flight path tangent with natural banking tilt
      bird.group.rotation.y = -bird.angle;
      bird.group.rotation.z = -0.22; // Inward bank angle during turn

      // Organic wing flapping oscillation
      const flap = Math.sin(time * bird.flapSpeed) * 0.55;
      bird.leftWing.rotation.z = flap;
      bird.rightWing.rotation.z = -flap;
    });
  }

  // --- ATMOSPHERIC PARTICLES & DYNAMIC 3D CUMULUS CLOUDS ---
  private initAtmosphereAndClouds() {
    // 1. Golden Floating Sunlight Dust & Chaff Motes (Dhool / Zarre in Punjabi air)
    const dustCount = 650;
    const dustGeo = new THREE.BufferGeometry();
    const positions = new Float32Array(dustCount * 3);

    for (let i = 0; i < dustCount * 3; i += 3) {
      positions[i] = (Math.random() - 0.5) * 240;
      positions[i + 1] = 0.5 + Math.random() * 16;
      positions[i + 2] = (Math.random() - 0.5) * 240;
    }

    dustGeo.setAttribute('position', new THREE.BufferAttribute(positions, 3));
    const dustMat = new THREE.PointsMaterial({
      color: 0xfde047, // Warm golden sunlit wheat pollen and dust
      size: 0.18,
      transparent: true,
      opacity: 0.45
    });
    this.floatingAirParticles = new THREE.Points(dustGeo, dustMat);
    this.scene.add(this.floatingAirParticles);

    // 2. Realistic 3D Soft Cumulus Cloud Formations
    const cloudTex = ProceduralTextures.getCloudTexture();
    const cloudMat = new THREE.MeshStandardMaterial({
      map: cloudTex,
      transparent: true,
      opacity: 0.82,
      roughness: 1.0,
      color: 0xffffff
    });

    for (let c = 0; c < 10; c++) {
      const cloudGroup = new THREE.Group();
      const puffCount = 7 + Math.floor(Math.random() * 5);

      for (let p = 0; p < puffCount; p++) {
        const radius = 6 + Math.random() * 8;
        const puffGeo = new THREE.SphereGeometry(radius, 8, 8);
        const puff = new THREE.Mesh(puffGeo, cloudMat);
        puff.position.set(
          (Math.random() - 0.5) * 26,
          (Math.random() - 0.5) * 4,
          (Math.random() - 0.5) * 16
        );
        puff.scale.set(1.4, 0.65, 1.0);
        cloudGroup.add(puff);
      }

      cloudGroup.position.set(
        (Math.random() - 0.5) * 320,
        55 + Math.random() * 20,
        (Math.random() - 0.5) * 320
      );
      this.scene.add(cloudGroup);
      this.dynamicClouds.push(cloudGroup);
    }
  }

  public updateAtmosphere(delta: number, centerPos: THREE.Vector3) {
    // Slowly drift clouds across the horizon
    this.dynamicClouds.forEach((cloud) => {
      cloud.position.x += delta * 1.5;
      if (cloud.position.x > 220) {
        cloud.position.x = -220;
      }
    });

    // Gently float dust particles around player / tractor
    if (this.floatingAirParticles) {
      this.floatingAirParticles.position.x = centerPos.x * 0.2;
      this.floatingAirParticles.position.z = centerPos.z * 0.2;

      const pos = this.floatingAirParticles.geometry.attributes.position;
      for (let i = 0; i < pos.count * 3; i += 3) {
        pos.array[i] += Math.sin(pos.array[i + 1] + performance.now() * 0.001) * delta * 0.4;
        pos.array[i + 1] -= delta * 0.25;
        if (pos.array[i + 1] < 0.2) {
          pos.array[i + 1] = 16.0;
        }
      }
      pos.needsUpdate = true;
    }
  }

  // --- VILLAGE CHARACTERS (ARHTI, GRAIN PORTER, GAWALA) ---
  private buildVillageCharacters() {
    // 1. Arhti (Grain Merchant / Munshi) sitting on a Charpai in Mandi
    const arhtiGroup = new THREE.Group();
    arhtiGroup.position.set(38, 0, 52);

    // Traditional Charpai (Woven rope cot)
    const woodMat = new THREE.MeshStandardMaterial({ color: 0x5c3d1e, roughness: 0.9 });
    const ropeMat = new THREE.MeshStandardMaterial({ color: 0xb59e72, roughness: 0.95 });

    // 4 Charpai carved legs
    [[-1.1, -0.6], [1.1, -0.6], [-1.1, 0.6], [1.1, 0.6]].forEach(([lx, lz]) => {
      const legGeo = new THREE.CylinderGeometry(0.08, 0.06, 0.55, 8);
      const leg = new THREE.Mesh(legGeo, woodMat);
      leg.position.set(lx, 0.275, lz);
      arhtiGroup.add(leg);
    });

    // Frame rails
    const railXGeo = new THREE.BoxGeometry(2.3, 0.09, 0.09);
    [-0.6, 0.6].forEach((rz) => {
      const rail = new THREE.Mesh(railXGeo, woodMat);
      rail.position.set(0, 0.52, rz);
      arhtiGroup.add(rail);
    });

    const railZGeo = new THREE.BoxGeometry(0.09, 0.09, 1.25);
    [-1.1, 1.1].forEach((rx) => {
      const rail = new THREE.Mesh(railZGeo, woodMat);
      rail.position.set(rx, 0.52, 0);
      arhtiGroup.add(rail);
    });

    // Woven rope webbing (Baan)
    const webbingGeo = new THREE.BoxGeometry(2.15, 0.04, 1.12);
    const webbing = new THREE.Mesh(webbingGeo, ropeMat);
    webbing.position.set(0, 0.5, 0);
    arhtiGroup.add(webbing);

    // Red bolster cushion (Gaao-Takiya)
    const bolsterGeo = new THREE.CylinderGeometry(0.18, 0.18, 1.0, 10);
    bolsterGeo.rotateZ(Math.PI / 2);
    const bolsterMat = new THREE.MeshStandardMaterial({ color: 0xb91c1c });
    const bolster = new THREE.Mesh(bolsterGeo, bolsterMat);
    bolster.position.set(-0.65, 0.72, 0);
    arhtiGroup.add(bolster);

    // Seated Arhti Character with Bahi-Khata ledger
    const arhtiPerson = this.createRealisticHumanCharacter(true);
    arhtiPerson.position.set(0.1, -0.42, 0);
    arhtiPerson.rotation.y = -Math.PI / 2;
    arhtiGroup.add(arhtiPerson);

    // Ledger Register (Bahi Khata with red fabric binding)
    const ledgerGeo = new THREE.BoxGeometry(0.35, 0.05, 0.25);
    const ledgerMat = new THREE.MeshStandardMaterial({ color: 0x991b1b });
    const ledger = new THREE.Mesh(ledgerGeo, ledgerMat);
    ledger.position.set(0.35, 0.55, 0.2);
    arhtiGroup.add(ledger);

    this.scene.add(arhtiGroup);
    this.villagePeople.push(arhtiGroup);

    // 2. Grain Porter (Palledar / Mazdoor) carrying a heavy wheat sack near godown
    const porterGroup = new THREE.Group();
    porterGroup.position.set(45, 0, 42);

    const porterPerson = this.createRealisticHumanCharacter(false);
    porterGroup.add(porterPerson);

    // 50kg Jute Sack of Golden Grain on Porter's back/shoulder
    const sackGeo = new THREE.BoxGeometry(0.85, 0.55, 0.42);
    const sackMat = new THREE.MeshStandardMaterial({ color: 0xc2a679, roughness: 0.95 });
    const sack = new THREE.Mesh(sackGeo, sackMat);
    sack.position.set(0, 1.7, -0.22);
    sack.rotation.x = 0.25;
    porterGroup.add(sack);

    this.scene.add(porterGroup);
    this.villagePeople.push(porterGroup);

    // 3. Gawala (Milkman) in the animal shed haveli with large silver milk cans
    const milkmanGroup = new THREE.Group();
    milkmanGroup.position.set(22, 0, -22);

    const milkman = this.createRealisticHumanCharacter(false);
    milkmanGroup.add(milkman);

    // Traditional Silver Milk Cans (Dhol)
    const canMat = new THREE.MeshStandardMaterial({ color: 0xd4d4d8, metalness: 0.9, roughness: 0.25 });
    [-0.55, 0.55].forEach((cx) => {
      const canGeo = new THREE.CylinderGeometry(0.24, 0.28, 0.85, 12);
      const can = new THREE.Mesh(canGeo, canMat);
      can.position.set(cx, 0.425, 0.45);
      can.castShadow = true;
      milkmanGroup.add(can);

      // Lid handle
      const lidGeo = new THREE.TorusGeometry(0.08, 0.02, 6, 8);
      const lid = new THREE.Mesh(lidGeo, canMat);
      lid.position.set(cx, 0.88, 0.45);
      milkmanGroup.add(lid);
    });

    this.scene.add(milkmanGroup);
    this.villagePeople.push(milkmanGroup);
  }

  // --- ANIMATED ANIMAL BEHAVIOR (SWISHING TAILS & CHEWING CUD) ---
  public updateAnimals(delta: number) {
    const time = performance.now() * 0.001;

    this.animatedAnimals.forEach((item) => {
      const phase = item.animPhase;

      // Swish tail back and forth to swat flies
      if (item.tail) {
        item.tail.rotation.z = Math.sin(time * 3.5 + phase) * 0.38;
        item.tail.rotation.y = Math.cos(time * 2.0 + phase) * 0.15;
      }

      // Gentle cud chewing head bob & subtle yaw motion
      if (item.head) {
        item.head.rotation.x = Math.sin(time * 2.5 + phase) * 0.06;
        item.head.rotation.y = Math.cos(time * 1.2 + phase) * 0.08;
      }
    });
  }

  // --- FLOWING CANAL WATER ANIMATION ---
  public updateCanalWater(delta: number) {
    if (this.canalWaterMesh) {
      this.canalWaterOffset += delta * 0.12;
      const mat = this.canalWaterMesh.material as THREE.MeshStandardMaterial;
      if (mat.normalMap) {
        mat.normalMap.offset.set(0, this.canalWaterOffset);
        mat.normalMap.needsUpdate = true;
      }
      if (mat.map) {
        mat.map.offset.set(0, this.canalWaterOffset * 0.7);
        mat.map.needsUpdate = true;
      }
    }
  }

  // --- WIND SWAY ON TREES & NATURE ---
  public updateCropWind(delta: number) {
    const time = performance.now() * 0.001;

    this.treeSwayMeshes.forEach((tree, idx) => {
      const sway = Math.sin(time * 1.6 + idx * 0.8) * 0.022;
      tree.rotation.z = sway;
      tree.rotation.x = Math.cos(time * 1.2 + idx * 0.5) * 0.015;
    });
  }
}

