import * as THREE from 'three';
import { WorldBuilder } from './WorldBuilder';
import { sound } from '../audio/SoundEngine';
import { CROPS_DATA } from './constants';
import {
  CropType,
  FieldData,
  ImplementType,
  PlayerStats,
  WeatherType,
  TimeOfDay
} from '../types';

export interface InteractionPrompt {
  action: string;
  keyLabel: string;
  type: 'enter_tractor' | 'exit_tractor' | 'tube_well' | 'hitch' | 'sell_mandi' | 'refuel' | 'animals';
}

export class GameEngine {
  public canvas: HTMLCanvasElement;
  public renderer: THREE.WebGLRenderer;
  public scene: THREE.Scene;
  public camera: THREE.PerspectiveCamera;
  public worldBuilder: WorldBuilder;

  // Lights
  public sunLight: THREE.DirectionalLight;
  public hemiLight: THREE.HemisphereLight;
  public tractorHeadlight: THREE.SpotLight;

  // Game Loop
  private clock: THREE.Clock = new THREE.Clock();
  private animFrameId: number | null = null;

  // Camera Settings
  public cameraMode: 1 | 2 | 3 = 1; // 1: Third-person, 2: First-person cabin, 3: Top-down tactical
  public cameraYaw: number = 0;
  public cameraPitch: number = 0.3;

  // Player & Vehicle State
  public inVehicle: boolean = false;
  public playerPos: THREE.Vector3 = new THREE.Vector3(-10, 0, 10);
  public playerRotY: number = 0;
  public playerWalkAnim: number = 0;

  public tractorPos: THREE.Vector3 = new THREE.Vector3(-8, 0, 8);
  public tractorRotY: number = Math.PI / 2;
  public tractorSpeed: number = 0;
  public tractorGear: number = 1; // -1: Rev, 0: N, 1: Low (Field), 2: High (Road)
  public steeringAngle: number = 0;
  public implementLowered: boolean = false;

  // Controls input buffer
  public keys: Record<string, boolean> = {};

  // World Data References (synchronized with React state)
  public fields: FieldData[] = [];
  public currentImplement: ImplementType = 'plough';
  public selectedSeedCrop: CropType = 'wheat';
  public trolleyCargo: { crop: CropType | null; amountKg: number } = { crop: null, amountKg: 0 };
  public playerStats: PlayerStats;

  // Callbacks to notify React UI
  public onPromptChange: ((prompt: InteractionPrompt | null) => void) | null = null;
  public onStatsUpdate: ((stats: Partial<PlayerStats>) => void) | null = null;
  public onFieldUpdate: ((field: FieldData) => void) | null = null;
  public onTrolleyUpdate: ((cargo: { crop: CropType | null; amountKg: number }) => void) | null = null;
  public onMissionProgress: ((type: string, amount: number, fieldId?: number, crop?: CropType) => void) | null = null;

  constructor(canvas: HTMLCanvasElement, initialStats: PlayerStats, initialFields: FieldData[]) {
    this.canvas = canvas;
    this.playerStats = { ...initialStats };
    this.fields = [...initialFields];

    // 1. Renderer with crisp shadows and tone mapping
    this.renderer = new THREE.WebGLRenderer({
      canvas: this.canvas,
      antialias: true,
      powerPreference: 'high-performance'
    });
    this.renderer.setSize(canvas.clientWidth, canvas.clientHeight);
    this.renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    this.renderer.shadowMap.enabled = true;
    this.renderer.shadowMap.type = THREE.PCFSoftShadowMap;
    this.renderer.toneMapping = THREE.ACESFilmicToneMapping;
    this.renderer.toneMappingExposure = 1.1;

    // 2. Scene
    this.scene = new THREE.Scene();
    this.scene.background = new THREE.Color(0x87ceeb); // Daylight blue sky
    this.scene.fog = new THREE.FogExp2(0x87ceeb, 0.005);

    // 3. Camera
    this.camera = new THREE.PerspectiveCamera(
      60,
      canvas.clientWidth / canvas.clientHeight,
      0.2,
      600
    );

    // 4. Lighting
    this.hemiLight = new THREE.HemisphereLight(0xfff8e7, 0x5a4227, 0.7);
    this.scene.add(this.hemiLight);

    this.sunLight = new THREE.DirectionalLight(0xfff3d1, 1.8);
    this.sunLight.position.set(80, 120, 60);
    this.sunLight.castShadow = true;
    this.sunLight.shadow.mapSize.width = 2048;
    this.sunLight.shadow.mapSize.height = 2048;
    this.sunLight.shadow.camera.near = 10;
    this.sunLight.shadow.camera.far = 300;
    const d = 110;
    this.sunLight.shadow.camera.left = -d;
    this.sunLight.shadow.camera.right = d;
    this.sunLight.shadow.camera.top = d;
    this.sunLight.shadow.camera.bottom = -d;
    this.scene.add(this.sunLight);

    // Tractor Headlight (toggled on during night/dusk)
    this.tractorHeadlight = new THREE.SpotLight(0xfffaed, 3.5, 45, Math.PI / 4, 0.4);
    this.tractorHeadlight.position.set(0, 1.6, 1.6);
    this.tractorHeadlight.target.position.set(0, 0, 15);
    this.tractorHeadlight.visible = false;

    // 5. Build Environment
    this.worldBuilder = new WorldBuilder(this.scene);
    this.worldBuilder.buildEnvironment(this.fields);
    this.worldBuilder.tractorMesh.add(this.tractorHeadlight);
    this.worldBuilder.tractorMesh.add(this.tractorHeadlight.target);

    // Initial implement attachment
    this.worldBuilder.updateAttachedImplement(this.currentImplement);

    // Initial field ground visuals
    this.fields.forEach((f) => this.worldBuilder.updateFieldVisuals(f));

    // Listeners
    this.initEventListeners();
  }

  private initEventListeners() {
    window.addEventListener('resize', this.onResize);
    window.addEventListener('keydown', this.onKeyDown);
    window.addEventListener('keyup', this.onKeyUp);
  }

  public destroy() {
    if (this.animFrameId !== null) {
      cancelAnimationFrame(this.animFrameId);
    }
    sound.stopTractorEngine();
    sound.setTubeWellState(false);
    window.removeEventListener('resize', this.onResize);
    window.removeEventListener('keydown', this.onKeyDown);
    window.removeEventListener('keyup', this.onKeyUp);
    this.renderer.dispose();
  }

  private onResize = () => {
    if (!this.canvas) return;
    const width = this.canvas.clientWidth;
    const height = this.canvas.clientHeight;
    this.camera.aspect = width / height;
    this.camera.updateProjectionMatrix();
    this.renderer.setSize(width, height);
  };

  private onKeyDown = (e: KeyboardEvent) => {
    sound.ensureContext();
    this.keys[e.code] = true;

    if (e.code === 'KeyE') {
      this.toggleVehicle();
    } else if (e.code === 'KeyF') {
      this.triggerContextInteraction();
    } else if (e.code === 'KeyG') {
      this.toggleImplementLowered();
    } else if (e.code === 'KeyH') {
      this.honkHorn();
    } else if (e.code === 'Digit1') {
      this.cameraMode = 1;
    } else if (e.code === 'Digit2') {
      this.cameraMode = 2;
    } else if (e.code === 'Digit3') {
      this.cameraMode = 3;
    } else if (e.code === 'KeyC') {
      this.cameraMode = (this.cameraMode % 3 + 1) as 1 | 2 | 3;
    } else if (e.code === 'ShiftLeft' && this.inVehicle) {
      // Toggle tractor gear
      this.tractorGear = this.tractorGear === 1 ? 2 : 1;
    }
  };

  private onKeyUp = (e: KeyboardEvent) => {
    this.keys[e.code] = false;
  };

  public start() {
    this.clock.start();
    this.animate();
  }

  private animate = () => {
    this.animFrameId = requestAnimationFrame(this.animate);
    const delta = Math.min(this.clock.getDelta(), 0.1);

    this.updateSimulation(delta);
    this.updateCamera();
    this.renderer.render(this.scene, this.camera);
  };

  // --- CORE GAME SIMULATION LOOP ---
  private updateSimulation(delta: number) {
    // 1. Advance Game Time & Weather Cycle
    this.updateDayNightAndWeather(delta);

    // 2. Player or Tractor Movement
    if (this.inVehicle) {
      this.updateTractorPhysics(delta);
      // Standing character is hidden while driving, seated realistic driver inside tractor is active
      this.worldBuilder.playerMesh.visible = false;
      if (this.worldBuilder.seatedDriverMesh) {
        this.worldBuilder.seatedDriverMesh.visible = true;
      }
      this.playerPos.copy(this.tractorPos);
    } else {
      this.worldBuilder.playerMesh.visible = true;
      if (this.worldBuilder.seatedDriverMesh) {
        this.worldBuilder.seatedDriverMesh.visible = false;
      }
      this.updatePlayerMovement(delta);
      sound.updateTractorRPM(0, false);
    }

    // 3. Farming Implements & Soil Interactions
    this.updateFarmingFieldWork(delta);

    // 4. Crop Growth & Moisture Decay
    this.updateCropsGrowth(delta);

    // 5. Interaction Check & Prompt
    this.checkInteractionPrompts();

    // 6. Particles
    this.worldBuilder.updateExhaustParticles(delta);
    const centerPos = this.inVehicle ? this.tractorPos : this.playerPos;
    const isRaining = this.playerStats.weather === 'rain' || this.playerStats.weather === 'storm';
    this.worldBuilder.updateRain(delta, isRaining, centerPos);

    // 7. Natural Living World Dynamics (Birds, Atmosphere, Livestock, Canal Water, Tree Wind)
    this.worldBuilder.updateBirds(delta);
    this.worldBuilder.updateAtmosphere(delta, centerPos);
    this.worldBuilder.updateAnimals(delta);
    this.worldBuilder.updateCanalWater(delta);
    this.worldBuilder.updateCropWind(delta);
  }

  // --- DAY / NIGHT & WEATHER CYCLE ---
  private updateDayNightAndWeather(delta: number) {
    // Clock advances: 1 real second = 4 game minutes
    this.playerStats.gameTimeMinutes = (this.playerStats.gameTimeMinutes + delta * 4) % 1440;
    const mins = this.playerStats.gameTimeMinutes;
    const hours = mins / 60;

    // Sun angle calculation
    const sunAngle = ((mins - 360) / 1440) * Math.PI * 2; // 6:00 AM sunrise
    const sunDist = 140;
    const sunY = Math.sin(sunAngle) * sunDist;
    const sunX = Math.cos(sunAngle) * sunDist;

    this.sunLight.position.set(sunX, Math.max(10, sunY), 40);

    // Sky colors based on time of day
    let skyColor = 0x87ceeb;
    let hemiSky = 0xfff8e7;
    let hemiGround = 0x5a4227;
    let sunIntensity = 1.8;

    if (hours >= 5 && hours < 7) {
      // Sunrise (Punjabi dawn glow)
      skyColor = 0xfdba74;
      hemiSky = 0xfef08a;
      sunIntensity = 1.2;
    } else if (hours >= 7 && hours < 17) {
      // Daytime bright Punjab sun
      skyColor = 0x7dd3fc;
      hemiSky = 0xffffff;
      sunIntensity = 2.0;
    } else if (hours >= 17 && hours < 19.5) {
      // Sunset (Shaam twilight)
      skyColor = 0xf97316;
      hemiSky = 0xfbbf24;
      sunIntensity = 1.1;
    } else {
      // Night (Raat under stars)
      skyColor = 0x0f172a;
      hemiSky = 0x1e293b;
      hemiGround = 0x090d16;
      sunIntensity = 0.15;
    }

    // Weather modification
    if (this.playerStats.weather === 'rain' || this.playerStats.weather === 'storm') {
      skyColor = 0x475569; // Dark monsoon clouds
      sunIntensity *= 0.35;
    } else if (this.playerStats.weather === 'cloudy') {
      skyColor = 0x94a3b8;
      sunIntensity *= 0.7;
    }

    this.scene.background = new THREE.Color(skyColor);
    if (this.scene.fog) {
      this.scene.fog.color = new THREE.Color(skyColor);
    }
    this.sunLight.intensity = sunIntensity;
    this.hemiLight.color.setHex(hemiSky);
    this.hemiLight.groundColor.setHex(hemiGround);

    // Headlight automatic toggle at night
    const isDark = hours < 6 || hours > 19;
    this.tractorHeadlight.visible = this.inVehicle && isDark;

    // Tube Well water stream visual
    if (this.worldBuilder.waterStreamMesh) {
      this.worldBuilder.waterStreamMesh.visible = this.playerStats.waterPumpRunning;
      if (this.playerStats.waterPumpRunning) {
        this.worldBuilder.waterStreamMesh.rotation.y += delta * 6;
      }
    }
  }

  // --- TRACTOR DRIVING PHYSICS ---
  private updateTractorPhysics(delta: number) {
    if (this.playerStats.fuel <= 0) {
      this.tractorSpeed = Math.max(0, this.tractorSpeed - delta * 5);
      return;
    }

    const accelInput = (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0) -
                       (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0);
    const steerInput = (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0) -
                       (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0);
    const isBraking = this.keys['Space'] || false;

    // Speeds based on Gear
    const maxSpeed = this.tractorGear === 1 ? 12 : 24; // Gear 1: 12 m/s, Gear 2: 24 m/s
    const reverseMax = 6;
    const accelRate = this.tractorGear === 1 ? 8.0 : 5.5;
    const dragRate = isBraking ? 18.0 : 3.5;

    // Acceleration
    if (accelInput > 0) {
      this.tractorSpeed = Math.min(maxSpeed, this.tractorSpeed + accelRate * delta);
    } else if (accelInput < 0) {
      this.tractorSpeed = Math.max(-reverseMax, this.tractorSpeed - accelRate * delta);
    } else {
      // Natural rolling drag
      if (this.tractorSpeed > 0) {
        this.tractorSpeed = Math.max(0, this.tractorSpeed - dragRate * delta);
      } else if (this.tractorSpeed < 0) {
        this.tractorSpeed = Math.min(0, this.tractorSpeed + dragRate * delta);
      }
    }

    // Steering
    const maxSteer = 0.65;
    if (steerInput !== 0) {
      this.steeringAngle = THREE.MathUtils.lerp(this.steeringAngle, steerInput * maxSteer, delta * 8);
    } else {
      this.steeringAngle = THREE.MathUtils.lerp(this.steeringAngle, 0, delta * 10);
    }

    // Apply rotation based on speed and steering
    if (Math.abs(this.tractorSpeed) > 0.05) {
      const turnMultiplier = this.tractorSpeed > 0 ? 1 : -1;
      this.tractorRotY += this.steeringAngle * turnMultiplier * (Math.abs(this.tractorSpeed) / maxSpeed) * delta * 2.2;
    }

    // Move forward in facing direction
    const forwardX = Math.sin(this.tractorRotY);
    const forwardZ = Math.cos(this.tractorRotY);
    this.tractorPos.x += forwardX * this.tractorSpeed * delta;
    this.tractorPos.z += forwardZ * this.tractorSpeed * delta;

    // Keep within world bounds
    this.tractorPos.x = Math.max(-150, Math.min(150, this.tractorPos.x));
    this.tractorPos.z = Math.max(-150, Math.min(150, this.tractorPos.z));

    this.worldBuilder.tractorMesh.position.copy(this.tractorPos);
    this.worldBuilder.tractorMesh.rotation.y = this.tractorRotY;

    // Wheel rotation animation
    this.worldBuilder.wheelMeshes.forEach((wheel) => {
      wheel.rotation.x += this.tractorSpeed * delta * 2;
    });

    // Audio RPM update
    const speedRatio = Math.abs(this.tractorSpeed) / maxSpeed;
    sound.updateTractorRPM(speedRatio, accelInput !== 0);

    // Fuel consumption (higher when working soil)
    const loadFactor = this.implementLowered ? 2.5 : 1.0;
    const fuelBurn = (0.01 + speedRatio * 0.04) * loadFactor * delta;
    this.playerStats.fuel = Math.max(0, this.playerStats.fuel - fuelBurn);

    // Diesel exhaust smoke puff
    if (Math.random() < 0.35 + (accelInput !== 0 ? 0.35 : 0)) {
      this.worldBuilder.spawnExhaustPuff(this.tractorPos, this.tractorRotY, accelInput !== 0);
    }
  }

  // --- WALKING PLAYER MOVEMENT ---
  private updatePlayerMovement(delta: number) {
    const moveX = (this.keys['KeyD'] || this.keys['ArrowRight'] ? 1 : 0) -
                  (this.keys['KeyA'] || this.keys['ArrowLeft'] ? 1 : 0);
    const moveZ = (this.keys['KeyS'] || this.keys['ArrowDown'] ? 1 : 0) -
                  (this.keys['KeyW'] || this.keys['ArrowUp'] ? 1 : 0);

    const isRunning = this.keys['ShiftLeft'] || false;
    const speed = isRunning ? 7.5 : 4.0;

    if (moveX !== 0 || moveZ !== 0) {
      // Rotate relative to camera angle
      const inputAngle = Math.atan2(moveX, moveZ);
      this.playerRotY = inputAngle;

      this.playerPos.x += Math.sin(inputAngle) * speed * delta;
      this.playerPos.z += Math.cos(inputAngle) * speed * delta;

      // Walking bounce animation
      this.playerWalkAnim += delta * (isRunning ? 14 : 9);
      this.worldBuilder.playerMesh.position.y = Math.abs(Math.sin(this.playerWalkAnim)) * 0.12;
    } else {
      this.worldBuilder.playerMesh.position.y = 0;
    }

    this.worldBuilder.playerMesh.position.x = this.playerPos.x;
    this.worldBuilder.playerMesh.position.z = this.playerPos.z;
    this.worldBuilder.playerMesh.rotation.y = this.playerRotY;
  }

  // --- CAMERA CONTROLLER ---
  private updateCamera() {
    const targetPos = this.inVehicle ? this.tractorPos : this.playerPos;
    const targetRotY = this.inVehicle ? this.tractorRotY : this.playerRotY;

    if (this.cameraMode === 1) {
      // Mode 1: Smooth 3rd Person Follow Camera with 360 touch orbit support
      const dist = this.inVehicle ? 9.5 : 6.0;
      const height = this.inVehicle ? 4.8 : 3.0;

      const effectiveAngle = targetRotY + this.cameraYaw;
      const camX = targetPos.x - Math.sin(effectiveAngle) * dist;
      const camZ = targetPos.z - Math.cos(effectiveAngle) * dist;
      const camY = Math.max(1.2, targetPos.y + height + this.cameraPitch * 3.5);

      this.camera.position.lerp(new THREE.Vector3(camX, camY, camZ), 0.12);
      this.camera.lookAt(targetPos.x, targetPos.y + 1.6, targetPos.z);
    } else if (this.cameraMode === 2) {
      // Mode 2: First-person Driver Cabin Camera
      if (this.inVehicle) {
        const cabinX = targetPos.x + Math.sin(targetRotY) * 0.1;
        const cabinZ = targetPos.z + Math.cos(targetRotY) * 0.1;
        const cabinY = targetPos.y + 1.85;

        this.camera.position.set(cabinX, cabinY, cabinZ);
        const lookX = cabinX + Math.sin(targetRotY) * 10;
        const lookZ = cabinZ + Math.cos(targetRotY) * 10;
        this.camera.lookAt(lookX, cabinY - 0.2, lookZ);
      } else {
        // Player eyes
        this.camera.position.set(targetPos.x, targetPos.y + 1.95, targetPos.z);
        const lookX = targetPos.x + Math.sin(targetRotY) * 10;
        const lookZ = targetPos.z + Math.cos(targetRotY) * 10;
        this.camera.lookAt(lookX, targetPos.y + 1.8, lookZ);
      }
    } else if (this.cameraMode === 3) {
      // Mode 3: Top-Down Tactical Farm View
      this.camera.position.lerp(new THREE.Vector3(targetPos.x, 38, targetPos.z + 20), 0.08);
      this.camera.lookAt(targetPos.x, 0, targetPos.z);
    }
  }

  // --- FARMING FIELD WORK & CROP HARVESTING ---
  private updateFarmingFieldWork(delta: number) {
    if (!this.inVehicle) return;

    // Check if tractor is inside any unlocked field
    const activeField = this.fields.find(
      (f) =>
        f.unlocked &&
        this.tractorPos.x >= f.bounds.minX &&
        this.tractorPos.x <= f.bounds.maxX &&
        this.tractorPos.z >= f.bounds.minZ &&
        this.tractorPos.z <= f.bounds.maxZ
    );

    if (!activeField) return;

    // Check work based on current hitched implement
    const isMoving = Math.abs(this.tractorSpeed) > 0.8;
    if (!isMoving) return;

    let fieldModified = false;

    if (this.currentImplement === 'plough' && this.implementLowered) {
      // Ploughing (Hal)
      if (activeField.soilState === 'unploughed' || activeField.soilState === 'harvested') {
        activeField.ploughedPercentage = Math.min(100, activeField.ploughedPercentage + delta * 12);
        if (activeField.ploughedPercentage >= 80) {
          activeField.soilState = 'ploughed';
        }
        fieldModified = true;
        this.onMissionProgress?.('plough', activeField.ploughedPercentage, activeField.id);
      }
    } else if ((this.currentImplement === 'cultivator' || this.currentImplement === 'rotavator') && this.implementLowered) {
      // Cultivating / Rotavator
      if (activeField.soilState === 'ploughed') {
        activeField.cultivatedPercentage = Math.min(100, activeField.cultivatedPercentage + delta * 15);
        if (activeField.cultivatedPercentage >= 80) {
          activeField.soilState = 'cultivated';
        }
        fieldModified = true;
      }
    } else if (this.currentImplement === 'seed_drill' && this.implementLowered) {
      // Planting Seeds
      if (activeField.soilState === 'cultivated') {
        activeField.seededPercentage = Math.min(100, activeField.seededPercentage + delta * 14);
        activeField.plantedCrop = this.selectedSeedCrop;
        if (activeField.seededPercentage >= 80) {
          activeField.soilState = 'seeded';
          activeField.growthProgress = 1;
        }
        fieldModified = true;
        this.onMissionProgress?.('seed', activeField.seededPercentage, activeField.id, this.selectedSeedCrop);
      }
    } else if (this.currentImplement === 'fertilizer_spreader' && this.implementLowered) {
      // Khaad broadcasting
      activeField.fertilizerLevel = Math.min(100, activeField.fertilizerLevel + delta * 20);
      fieldModified = true;
    } else if (this.currentImplement === 'sprayer' && this.implementLowered) {
      // Pesticide / Herbicide spray
      activeField.weedLevel = Math.max(0, activeField.weedLevel - delta * 25);
      activeField.pestLevel = Math.max(0, activeField.pestLevel - delta * 25);
      fieldModified = true;
      this.onMissionProgress?.('spray', 100, activeField.id);
    } else if (this.currentImplement === 'harvester_cutter') {
      // Harvesting mature crop
      if (activeField.growthProgress >= 90 && activeField.plantedCrop) {
        sound.playCropHarvestSound();
        activeField.harvestedPercentage = Math.min(100, activeField.harvestedPercentage + delta * 12);
        
        // Calculate harvested yield and load into trolley
        const cropInfo = CROPS_DATA[activeField.plantedCrop];
        const harvestedAmount = Math.round(cropInfo.baseYieldKg * activeField.acres * (delta * 0.12));
        
        this.trolleyCargo.crop = activeField.plantedCrop;
        this.trolleyCargo.amountKg += harvestedAmount;
        this.onTrolleyUpdate?.(this.trolleyCargo);

        if (activeField.harvestedPercentage >= 80) {
          activeField.soilState = 'harvested';
          activeField.growthProgress = 0;
          activeField.plantedCrop = null;
          activeField.ploughedPercentage = 0;
          activeField.cultivatedPercentage = 0;
          activeField.seededPercentage = 0;
        }
        fieldModified = true;
        this.onMissionProgress?.('harvest', activeField.harvestedPercentage, activeField.id);
      }
    }

    if (fieldModified) {
      this.worldBuilder.updateFieldVisuals(activeField);
      this.onFieldUpdate?.(activeField);
    }
  }

  // --- CROP GROWTH & NATURAL RAIN/TUBE WELL MOISTURE ---
  private updateCropsGrowth(delta: number) {
    const isRaining = this.playerStats.weather === 'rain' || this.playerStats.weather === 'storm';

    this.fields.forEach((field) => {
      if (!field.unlocked) return;

      // Natural moisture change
      if (isRaining) {
        field.moistureLevel = Math.min(100, field.moistureLevel + delta * 3.5);
      } else if (this.playerStats.waterPumpRunning) {
        // Tube well fills fields with water channels
        field.moistureLevel = Math.min(100, field.moistureLevel + delta * 2.8);
        this.onMissionProgress?.('irrigate', field.moistureLevel, field.id);
      } else {
        // Slow evaporation in Punjab sun
        field.moistureLevel = Math.max(10, field.moistureLevel - delta * 0.2);
      }

      // Crop growth progression
      if ((field.soilState === 'seeded' || field.growthProgress > 0) && field.plantedCrop) {
        const cropInfo = CROPS_DATA[field.plantedCrop];
        const growthSpeed = 100 / cropInfo.growthTimeSeconds;

        // Health multipliers: Moisture & Fertilizer boost growth
        const moistureBonus = field.moistureLevel >= cropInfo.waterReq ? 1.2 : 0.6;
        const fertBonus = field.fertilizerLevel >= cropInfo.fertReq ? 1.2 : 0.8;
        const weedPenalty = field.weedLevel > 40 ? 0.7 : 1.0;

        const deltaGrowth = delta * growthSpeed * moistureBonus * fertBonus * weedPenalty;
        const oldProgress = field.growthProgress;
        field.growthProgress = Math.min(100, field.growthProgress + deltaGrowth);

        if (field.growthProgress >= 90 && field.soilState !== 'harvest_ready') {
          field.soilState = 'harvest_ready';
        }

        // Rebuild 3D stalks when crossing growth thresholds (10%, 40%, 75%, 95%)
        if (Math.floor(field.growthProgress / 20) !== Math.floor(oldProgress / 20)) {
          this.worldBuilder.updateFieldVisuals(field);
          this.onFieldUpdate?.(field);
        }
      }
    });
  }

  // --- INTERACTION SYSTEM ---
  private checkInteractionPrompts() {
    let prompt: InteractionPrompt | null = null;
    const currentPos = this.inVehicle ? this.tractorPos : this.playerPos;

    // 1. Enter / Exit Tractor
    const distToTractor = this.playerPos.distanceTo(this.tractorPos);
    if (!this.inVehicle && distToTractor < 4.0) {
      prompt = { action: 'Drive Tractor (Millat MF)', keyLabel: 'E', type: 'enter_tractor' };
    } else if (this.inVehicle) {
      prompt = { action: 'Exit Tractor', keyLabel: 'E', type: 'exit_tractor' };
    }

    // 2. Tube Well Pump (Pos: -5, 0, -35)
    const distToTubeWell = currentPos.distanceTo(new THREE.Vector3(-5, 0, -35));
    if (distToTubeWell < 6.0) {
      prompt = {
        action: this.playerStats.waterPumpRunning ? 'Stop Tube Well Motor' : 'Start Tube Well Water Pump',
        keyLabel: 'F',
        type: 'tube_well'
      };
    }

    // 3. Grain Mandi / Storage Kanda (Pos: 40, 0, 50)
    const distToMandi = currentPos.distanceTo(new THREE.Vector3(40, 0, 50));
    if (distToMandi < 10.0 && this.trolleyCargo.amountKg > 0) {
      const cropName = this.trolleyCargo.crop ? CROPS_DATA[this.trolleyCargo.crop].name : 'Crops';
      prompt = {
        action: `Sell ${this.trolleyCargo.amountKg} kg ${cropName} at Mandi`,
        keyLabel: 'F',
        type: 'sell_mandi'
      };
    }

    // 4. Petrol Pump Station (Pos: -45, 0, 45)
    const distToPump = currentPos.distanceTo(new THREE.Vector3(-45, 0, 45));
    if (distToPump < 8.0 && this.playerStats.fuel < this.playerStats.maxFuel) {
      prompt = { action: 'Refuel Diesel (Pakistani PSO Pump)', keyLabel: 'F', type: 'refuel' };
    }

    // 5. Cattle Haveli Animal Yard (Pos: 25, 0, -25)
    const distToAnimals = currentPos.distanceTo(new THREE.Vector3(25, 0, -25));
    if (distToAnimals < 8.0 && !this.inVehicle) {
      prompt = { action: 'Feed & Milk Buffaloes & Dairy Cows', keyLabel: 'F', type: 'animals' };
    }

    this.onPromptChange?.(prompt);
  }

  // --- ACTIONS TRIGGERED VIA F / BUTTONS ---
  public triggerContextInteraction() {
    const currentPos = this.inVehicle ? this.tractorPos : this.playerPos;

    // Tube Well
    if (currentPos.distanceTo(new THREE.Vector3(-5, 0, -35)) < 6.0) {
      this.toggleTubeWell();
      return;
    }

    // Mandi Crop Sale
    if (currentPos.distanceTo(new THREE.Vector3(40, 0, 50)) < 10.0 && this.trolleyCargo.amountKg > 0) {
      this.sellTrolleyAtMandi();
      return;
    }

    // Petrol Refuel
    if (currentPos.distanceTo(new THREE.Vector3(-45, 0, 45)) < 8.0) {
      this.refuelTractor();
      return;
    }

    // Animal Haveli
    if (currentPos.distanceTo(new THREE.Vector3(25, 0, -25)) < 8.0) {
      this.interactWithAnimals();
      return;
    }
  }

  public toggleVehicle() {
    const dist = this.playerPos.distanceTo(this.tractorPos);
    if (!this.inVehicle && dist < 4.5) {
      this.inVehicle = true;
      this.worldBuilder.playerMesh.visible = false;
      if (this.worldBuilder.seatedDriverMesh) {
        this.worldBuilder.seatedDriverMesh.visible = true;
      }
      sound.startTractorEngine();
    } else if (this.inVehicle) {
      this.inVehicle = false;
      this.worldBuilder.playerMesh.visible = true;
      if (this.worldBuilder.seatedDriverMesh) {
        this.worldBuilder.seatedDriverMesh.visible = false;
      }
      this.tractorSpeed = 0;
      sound.stopTractorEngine();
      // Dismount to side of tractor
      this.playerPos.copy(this.tractorPos);
      this.playerPos.x += Math.cos(this.tractorRotY) * 2.0;
      this.playerPos.z -= Math.sin(this.tractorRotY) * 2.0;
      this.playerPos.y = 0;
      this.worldBuilder.playerMesh.position.copy(this.playerPos);
    }
  }

  public upgradeTractor(level: number) {
    this.worldBuilder.rebuildTractor(level);
    this.worldBuilder.updateAttachedImplement(this.currentImplement);
    if (this.worldBuilder.seatedDriverMesh) {
      this.worldBuilder.seatedDriverMesh.visible = this.inVehicle;
    }

    // Set performance stats per upgraded model
    const maxFuel = level === 4 ? 90 : level === 3 ? 70 : level === 2 ? 55 : 45;
    this.playerStats.maxFuel = maxFuel;
    this.playerStats.fuel = maxFuel;
    this.onStatsUpdate?.({ maxFuel, fuel: maxFuel });
  }

  public toggleTubeWell() {
    this.playerStats.waterPumpRunning = !this.playerStats.waterPumpRunning;
    sound.setTubeWellState(this.playerStats.waterPumpRunning);
    this.onStatsUpdate?.({ waterPumpRunning: this.playerStats.waterPumpRunning });
  }

  public toggleImplementLowered() {
    this.implementLowered = !this.implementLowered;
    sound.playHitchImplement();
  }

  public honkHorn() {
    sound.playTractorHorn();
  }

  public setAttachedImplement(implement: ImplementType) {
    this.currentImplement = implement;
    this.worldBuilder.updateAttachedImplement(implement);
    sound.playHitchImplement();
  }

  public refuelTractor() {
    const needed = this.playerStats.maxFuel - this.playerStats.fuel;
    const cost = Math.round(needed * 280); // PKR 280 per liter diesel
    if (this.playerStats.money >= cost) {
      this.playerStats.money -= cost;
      this.playerStats.fuel = this.playerStats.maxFuel;
      sound.playCashRegister();
      this.onStatsUpdate?.({
        money: this.playerStats.money,
        fuel: this.playerStats.fuel
      });
    }
  }

  public sellTrolleyAtMandi() {
    if (!this.trolleyCargo.crop || this.trolleyCargo.amountKg <= 0) return;

    const cropInfo = CROPS_DATA[this.trolleyCargo.crop];
    const maunds = this.trolleyCargo.amountKg / 40; // 40kg per maund
    const earned = Math.round(maunds * cropInfo.baseMarketPricePer40Kg);

    this.playerStats.money += earned;
    this.playerStats.totalEarnedMoney += earned;
    this.playerStats.totalCropsSoldKg += this.trolleyCargo.amountKg;
    this.playerStats.xp += Math.round(earned * 0.01);

    sound.playCashRegister();
    this.onMissionProgress?.('sell', this.trolleyCargo.amountKg);

    this.trolleyCargo = { crop: null, amountKg: 0 };
    this.onTrolleyUpdate?.(this.trolleyCargo);
    this.onStatsUpdate?.({
      money: this.playerStats.money,
      totalEarnedMoney: this.playerStats.totalEarnedMoney,
      totalCropsSoldKg: this.playerStats.totalCropsSoldKg,
      xp: this.playerStats.xp
    });
  }

  public interactWithAnimals() {
    // Collect milk / eggs
    sound.playCashRegister();
    const earnings = 8500; // PKR
    this.playerStats.money += earnings;
    this.playerStats.xp += 60;
    this.onMissionProgress?.('milk', 20);
    this.onStatsUpdate?.({
      money: this.playerStats.money,
      xp: this.playerStats.xp
    });
  }

  // Touch control helper methods for mobile and touch laptops
  public setVirtualJoystick(x: number, y: number) {
    this.keys['KeyW'] = y < -0.15;
    this.keys['KeyS'] = y > 0.15;
    this.keys['KeyA'] = x < -0.15;
    this.keys['KeyD'] = x > 0.15;
  }

  public stopVirtualJoystick() {
    this.keys['KeyW'] = false;
    this.keys['KeyS'] = false;
    this.keys['KeyA'] = false;
    this.keys['KeyD'] = false;
  }

  public rotateCameraBy(deltaX: number, deltaY: number) {
    this.cameraYaw += deltaX * 0.007;
    this.cameraPitch = Math.max(-0.6, Math.min(1.2, this.cameraPitch - deltaY * 0.005));
  }

  public resetCameraOrbit() {
    this.cameraYaw = 0;
    this.cameraPitch = 0.3;
  }

  public setThrottle(active: boolean) {
    this.keys['KeyW'] = active;
  }

  public setBrake(active: boolean) {
    this.keys['KeyS'] = active;
  }

  public setSteerLeft(active: boolean) {
    this.keys['KeyA'] = active;
  }

  public setSteerRight(active: boolean) {
    this.keys['KeyD'] = active;
  }

  public setHandbrake(active: boolean) {
    this.keys['Space'] = active;
  }

  public setSprint(active: boolean) {
    this.keys['ShiftLeft'] = active;
  }
}
