import * as THREE from 'three';

/**
 * High-performance procedural PBR texture generator.
 * Creates photorealistic 2D textures using HTML5 Canvas with smooth noise,
 * bump maps, and natural color variations for the Pakistani agricultural environment.
 */
export class ProceduralTextures {
  private static cache: Map<string, THREE.CanvasTexture> = new Map();

  // Helper: Pseudo-random simplex-like noise
  private static noise(x: number, y: number): number {
    const n = Math.sin(x * 12.9898 + y * 78.233) * 43758.5453;
    return n - Math.floor(n);
  }

  private static fbm(x: number, y: number, octaves = 4): number {
    let val = 0;
    let amp = 0.5;
    let freq = 1.0;
    for (let i = 0; i < octaves; i++) {
      val += ProceduralTextures.noise(x * freq, y * freq) * amp;
      amp *= 0.5;
      freq *= 2.0;
    }
    return val;
  }

  /**
   * 1. Rich Punjab Agricultural Soil Texture (Alluvial Loam)
   * With organic flecks, small clods, dry dust, and damp furrow crevices.
   */
  public static getSoilTexture(): THREE.CanvasTexture {
    if (this.cache.has('soil')) return this.cache.get('soil')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Base rich fertile Punjab brown
    ctx.fillStyle = '#6e4f32';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;

    for (let y = 0; y < 512; y++) {
      for (let x = 0; x < 512; x++) {
        const idx = (y * 512 + x) * 4;

        // Base furrow waves
        const furrow = Math.sin(y * 0.15) * 0.15;
        // Fine micro noise
        const n1 = (Math.random() - 0.5) * 40;
        const n2 = Math.sin(x * 0.08 + y * 0.04) * 25;
        const clump = Math.sin(x * 0.02) * Math.cos(y * 0.02) * 30;

        const baseR = 110 + furrow * 40 + n1 + n2 + clump;
        const baseG = 80 + furrow * 30 + (n1 + n2 + clump) * 0.75;
        const baseB = 52 + furrow * 20 + (n1 + n2 + clump) * 0.55;

        data[idx] = Math.min(255, Math.max(40, baseR));
        data[idx + 1] = Math.min(255, Math.max(30, baseG));
        data[idx + 2] = Math.min(255, Math.max(18, baseB));
        data[idx + 3] = 255;
      }
    }

    ctx.putImageData(imgData, 0, 0);

    // Add scattered organic mulch / dry straw specks
    ctx.fillStyle = 'rgba(180, 150, 100, 0.4)';
    for (let i = 0; i < 400; i++) {
      const rx = Math.random() * 512;
      const ry = Math.random() * 512;
      const len = 3 + Math.random() * 8;
      const ang = Math.random() * Math.PI;
      ctx.lineWidth = 1.5;
      ctx.strokeStyle = 'rgba(195, 165, 110, 0.5)';
      ctx.beginPath();
      ctx.moveTo(rx, ry);
      ctx.lineTo(rx + Math.cos(ang) * len, ry + Math.sin(ang) * len);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(12, 12);
    this.cache.set('soil', texture);
    return texture;
  }

  /**
   * 2. Soil Bump / Normal Map for 3D Micro Relief & Furrows
   */
  public static getSoilBumpMap(): THREE.CanvasTexture {
    if (this.cache.has('soil_bump')) return this.cache.get('soil_bump')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    const imgData = ctx.createImageData(512, 512);
    const data = imgData.data;

    for (let y = 0; y < 512; y++) {
      for (let x = 0; x < 512; x++) {
        const idx = (y * 512 + x) * 4;
        const furrow = (Math.sin(y * 0.18) + 1) * 0.5 * 90;
        const grain = Math.random() * 110;
        const v = Math.min(255, Math.max(0, furrow + grain));
        data[idx] = v;
        data[idx + 1] = v;
        data[idx + 2] = v;
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(12, 12);
    this.cache.set('soil_bump', texture);
    return texture;
  }

  /**
   * 3. Natural Field Grass & Green Ground Cover Texture
   * With organic blade texture, clover patches, and warm earth undertones.
   */
  public static getGrassTexture(): THREE.CanvasTexture {
    if (this.cache.has('grass')) return this.cache.get('grass')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Rich Punjabi meadow olive-green base
    ctx.fillStyle = '#4d6934';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;

    for (let y = 0; y < 512; y++) {
      for (let x = 0; x < 512; x++) {
        const idx = (y * 512 + x) * 4;
        const n = (Math.random() - 0.5) * 45;
        const patch = Math.sin(x * 0.03) * Math.cos(y * 0.03) * 30;

        const r = 68 + patch * 0.6 + n;
        const g = 105 + patch + n;
        const b = 45 + patch * 0.3 + n * 0.8;

        data[idx] = Math.min(255, Math.max(30, r));
        data[idx + 1] = Math.min(255, Math.max(50, g));
        data[idx + 2] = Math.min(255, Math.max(20, b));
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    // Draw fine natural blade strokes
    for (let i = 0; i < 1200; i++) {
      const bx = Math.random() * 512;
      const by = Math.random() * 512;
      const h = 4 + Math.random() * 8;
      const lean = (Math.random() - 0.5) * 4;
      ctx.strokeStyle = Math.random() > 0.4 ? 'rgba(92, 148, 55, 0.45)' : 'rgba(125, 160, 68, 0.35)';
      ctx.lineWidth = 1.2;
      ctx.beginPath();
      ctx.moveTo(bx, by);
      ctx.lineTo(bx + lean, by - h);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(16, 16);
    this.cache.set('grass', texture);
    return texture;
  }

  /**
   * 4. Authentic Pakistani Kiln-Baked Red Brick Soling Road (Lahori Eent)
   * With individual terracotta bricks, mortar cement joints, and wheel wear dirt.
   */
  public static getBrickRoadTexture(): THREE.CanvasTexture {
    if (this.cache.has('brick_road')) return this.cache.get('brick_road')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Sandy cement mortar base
    ctx.fillStyle = '#8a7761';
    ctx.fillRect(0, 0, 512, 512);

    const brickW = 48;
    const brickH = 22;
    const gap = 4;

    const brickShades = [
      '#a8432a', // deep terracotta
      '#ba4e32', // vibrant red kiln brick
      '#9c3e26', // dark burnt brick
      '#b3583b', // sandy clay brick
      '#8f3721'  // over-fired edge
    ];

    let row = 0;
    for (let y = 2; y < 512; y += brickH + gap) {
      const offset = (row % 2) * (brickW / 2 + gap / 2);
      row++;
      for (let x = -brickW; x < 512 + brickW; x += brickW + gap) {
        const bx = x + offset;
        const shade = brickShades[Math.floor(Math.random() * brickShades.length)];
        ctx.fillStyle = shade;
        ctx.fillRect(bx, y, brickW, brickH);

        // Brick surface noise/imperfections
        ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
        if (Math.random() > 0.3) {
          ctx.fillRect(bx + 4, y + 3, brickW - 8, brickH - 6);
        }
        ctx.fillStyle = 'rgba(255, 255, 255, 0.08)';
        ctx.fillRect(bx + 2, y + 1, brickW - 4, 3);
      }
    }

    // Add tire wear dust streak down the road center and sides
    const grad = ctx.createLinearGradient(0, 0, 512, 0);
    grad.addColorStop(0, 'rgba(120, 95, 65, 0.55)');
    grad.addColorStop(0.2, 'rgba(120, 95, 65, 0.15)');
    grad.addColorStop(0.5, 'rgba(140, 115, 80, 0.45)');
    grad.addColorStop(0.8, 'rgba(120, 95, 65, 0.15)');
    grad.addColorStop(1, 'rgba(120, 95, 65, 0.55)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 16);
    this.cache.set('brick_road', texture);
    return texture;
  }

  /**
   * 5. Pakistani Rural Dirt Cart Track (Katchi Sarak)
   * With tractor wheel ruts, packed dry clay, and loose sand ridges.
   */
  public static getDirtRoadTexture(): THREE.CanvasTexture {
    if (this.cache.has('dirt_road')) return this.cache.get('dirt_road')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Warm sand-clay background
    ctx.fillStyle = '#997c59';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;

    for (let y = 0; y < 512; y++) {
      for (let x = 0; x < 512; x++) {
        const idx = (y * 512 + x) * 4;

        // Two wheel rut depressions at x = 140 and x = 370
        const rut1 = Math.exp(-Math.pow((x - 140) / 45, 2));
        const rut2 = Math.exp(-Math.pow((x - 370) / 45, 2));
        const rut = Math.max(rut1, rut2);

        // Center grass / dust mound at x = 256
        const centerMound = Math.exp(-Math.pow((x - 256) / 50, 2));

        const n = (Math.random() - 0.5) * 35;
        const r = 153 - rut * 40 + centerMound * 10 + n;
        const g = 124 - rut * 35 + centerMound * 15 + n * 0.8;
        const b = 89 - rut * 28 + centerMound * 8 + n * 0.6;

        data[idx] = Math.min(255, Math.max(40, r));
        data[idx + 1] = Math.min(255, Math.max(30, g));
        data[idx + 2] = Math.min(255, Math.max(20, b));
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    // Tread impression marks along ruts
    ctx.strokeStyle = 'rgba(70, 50, 30, 0.25)';
    ctx.lineWidth = 3;
    for (let y = 0; y < 512; y += 16) {
      // Left rut chevron
      ctx.beginPath();
      ctx.moveTo(115, y);
      ctx.lineTo(140, y + 8);
      ctx.lineTo(165, y);
      ctx.stroke();

      // Right rut chevron
      ctx.beginPath();
      ctx.moveTo(345, y);
      ctx.lineTo(370, y + 8);
      ctx.lineTo(395, y);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 14);
    this.cache.set('dirt_road', texture);
    return texture;
  }

  /**
   * 6. Organic Tree Bark Texture for Neem, Shisham & Safeda
   */
  public static getBarkTexture(type: 'neem' | 'safeda' | 'palm' = 'neem'): THREE.CanvasTexture {
    const key = `bark_${type}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    if (type === 'safeda') {
      // Eucalyptus: pale gray/cream peeling bark with greenish patches
      ctx.fillStyle = '#b8b2a5';
      ctx.fillRect(0, 0, 256, 512);

      for (let i = 0; i < 60; i++) {
        const x = Math.random() * 256;
        const y = Math.random() * 512;
        const w = 15 + Math.random() * 35;
        const h = 40 + Math.random() * 90;
        ctx.fillStyle = Math.random() > 0.5 ? '#8e8b7f' : '#6d7560';
        ctx.fillRect(x, y, w, h);
      }
    } else if (type === 'palm') {
      // Date palm trunk with ringed fibrous diamond notches
      ctx.fillStyle = '#614833';
      ctx.fillRect(0, 0, 256, 512);

      for (let y = 0; y < 512; y += 20) {
        ctx.strokeStyle = '#3d2b1c';
        ctx.lineWidth = 4;
        ctx.beginPath();
        ctx.moveTo(0, y);
        for (let x = 0; x < 256; x += 32) {
          ctx.lineTo(x + 16, y + 10);
          ctx.lineTo(x + 32, y);
        }
        ctx.stroke();
      }
    } else {
      // Ancient Neem: rugged furrowed dark bark
      ctx.fillStyle = '#422f20';
      ctx.fillRect(0, 0, 256, 512);

      for (let x = 0; x < 256; x += 12) {
        ctx.strokeStyle = Math.random() > 0.5 ? '#2c1e13' : '#573f2c';
        ctx.lineWidth = 3 + Math.random() * 4;
        ctx.beginPath();
        ctx.moveTo(x, 0);
        let curX = x;
        for (let y = 0; y < 512; y += 24) {
          curX += (Math.random() - 0.5) * 8;
          ctx.lineTo(curX, y);
        }
        ctx.stroke();
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 7. Natural Leaf Cluster Texture with Alpha Mask (for lush dappled tree canopies)
   */
  public static getLeafCanopyTexture(colorHex = '#2d5e23'): THREE.CanvasTexture {
    const key = `leaf_${colorHex}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.clearRect(0, 0, 256, 256);

    // Draw dozens of organic leaf silhouettes with varied greens
    const colors = [colorHex, '#3b782f', '#254e1c', '#4a8e3b', '#204018'];

    for (let i = 0; i < 180; i++) {
      const lx = 40 + Math.random() * 176;
      const ly = 40 + Math.random() * 176;
      const radX = 8 + Math.random() * 14;
      const radY = 16 + Math.random() * 26;
      const rot = Math.random() * Math.PI * 2;

      ctx.save();
      ctx.translate(lx, ly);
      ctx.rotate(rot);

      ctx.fillStyle = colors[Math.floor(Math.random() * colors.length)];
      ctx.beginPath();
      ctx.ellipse(0, 0, radX, radY, 0, 0, Math.PI * 2);
      ctx.fill();

      // Delicate leaf vein
      ctx.strokeStyle = 'rgba(255, 255, 255, 0.2)';
      ctx.lineWidth = 1;
      ctx.beginPath();
      ctx.moveTo(0, -radY * 0.8);
      ctx.lineTo(0, radY * 0.8);
      ctx.stroke();

      ctx.restore();
    }

    const texture = new THREE.CanvasTexture(canvas);
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 8. Weathered Mud Plaster / Lippai Texture (Traditional Pakistani Haveli & Dera)
   */
  public static getMudPlasterTexture(): THREE.CanvasTexture {
    if (this.cache.has('mud_plaster')) return this.cache.get('mud_plaster')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Clay plaster base
    ctx.fillStyle = '#bfa588';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;

    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * 30;
      data[i] = Math.min(255, Math.max(0, 191 + n));
      data[i + 1] = Math.min(255, Math.max(0, 165 + n * 0.85));
      data[i + 2] = Math.min(255, Math.max(0, 136 + n * 0.7));
    }
    ctx.putImageData(imgData, 0, 0);

    // Chopped wheat straw (toori/bhoosa) fibers embedded in mud plaster
    ctx.strokeStyle = 'rgba(145, 115, 75, 0.6)';
    ctx.lineWidth = 1.2;
    for (let i = 0; i < 600; i++) {
      const sx = Math.random() * 512;
      const sy = Math.random() * 512;
      const len = 4 + Math.random() * 10;
      const angle = Math.random() * Math.PI;
      ctx.beginPath();
      ctx.moveTo(sx, sy);
      ctx.lineTo(sx + Math.cos(angle) * len, sy + Math.sin(angle) * len);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(4, 4);
    this.cache.set('mud_plaster', texture);
    return texture;
  }

  /**
   * 9. Weathered Concrete Texture for Tube Well Houz & Canals
   */
  public static getConcreteTexture(): THREE.CanvasTexture {
    if (this.cache.has('concrete')) return this.cache.get('concrete')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#9e9991';
    ctx.fillRect(0, 0, 512, 512);

    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;

    for (let i = 0; i < data.length; i += 4) {
      const n = (Math.random() - 0.5) * 35;
      data[i] = Math.min(255, Math.max(0, 158 + n));
      data[i + 1] = Math.min(255, Math.max(0, 153 + n));
      data[i + 2] = Math.min(255, Math.max(0, 145 + n));
    }
    ctx.putImageData(imgData, 0, 0);

    // Add moisture seepage and algae stains along bottom edge
    const grad = ctx.createLinearGradient(0, 0, 0, 512);
    grad.addColorStop(0, 'rgba(0,0,0,0)');
    grad.addColorStop(0.7, 'rgba(60, 75, 50, 0.1)');
    grad.addColorStop(1, 'rgba(45, 60, 35, 0.55)');
    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 512, 512);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set('concrete', texture);
    return texture;
  }

  /**
   * 10. Heavy Chevron Tractor Tire Rubber Tread Texture
   */
  public static getTireTreadTexture(): THREE.CanvasTexture {
    if (this.cache.has('tire_tread')) return this.cache.get('tire_tread')!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Dark charcoal rubber
    ctx.fillStyle = '#1c1d21';
    ctx.fillRect(0, 0, 256, 256);

    // Deep angled tractor lug bars
    ctx.fillStyle = '#2b2d33';
    ctx.strokeStyle = '#0e0f12';
    ctx.lineWidth = 3;

    for (let y = -30; y < 290; y += 42) {
      // Left bar
      ctx.beginPath();
      ctx.moveTo(10, y);
      ctx.lineTo(120, y + 25);
      ctx.lineTo(110, y + 42);
      ctx.lineTo(10, y + 18);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();

      // Right bar (alternating chevron)
      ctx.beginPath();
      ctx.moveTo(246, y + 21);
      ctx.lineTo(136, y + 46);
      ctx.lineTo(146, y + 63);
      ctx.lineTo(246, y + 39);
      ctx.closePath();
      ctx.fill();
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 8);
    this.cache.set('tire_tread', texture);
    return texture;
  }

  /**
   * 11. Animated Water Normal Map for Tube Well & Canals
   */
  public static getWaterNormalTexture(): THREE.CanvasTexture {
    if (this.cache.has('water_norm')) return this.cache.get('water_norm')!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    const imgData = ctx.createImageData(256, 256);
    const data = imgData.data;

    for (let y = 0; y < 256; y++) {
      for (let x = 0; x < 256; x++) {
        const idx = (y * 256 + x) * 4;
        const w1 = Math.sin(x * 0.1 + y * 0.08) * 0.5 + 0.5;
        const w2 = Math.cos(x * 0.06 - y * 0.12) * 0.5 + 0.5;
        const ripple = (w1 + w2) * 0.5;

        // Normal map standard vector (RGB = XYZ, where Z is up 128..255)
        data[idx] = Math.floor(128 + (w1 - 0.5) * 60);
        data[idx + 1] = Math.floor(128 + (w2 - 0.5) * 60);
        data[idx + 2] = Math.floor(200 + ripple * 55);
        data[idx + 3] = 255;
      }
    }
    ctx.putImageData(imgData, 0, 0);

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(4, 4);
    this.cache.set('water_norm', texture);
    return texture;
  }

  /**
   * 12. Realistic Human Farmer Face Texture (Pakistani Farmer)
   * With lifelike eyes, skin pores, natural shading, realistic mustache, and facial contours.
   */
  public static getHumanFaceTexture(): THREE.CanvasTexture {
    if (this.cache.has('human_face')) return this.cache.get('human_face')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Base warm South Asian Punjabi complexion with skin gradient
    const skinGrad = ctx.createRadialGradient(256, 256, 40, 256, 256, 260);
    skinGrad.addColorStop(0, '#cda27f'); // Forehead / nose highlight
    skinGrad.addColorStop(0.5, '#b98863'); // Cheeks
    skinGrad.addColorStop(1, '#9b6c4b'); // Jaw / temples
    ctx.fillStyle = skinGrad;
    ctx.fillRect(0, 0, 512, 512);

    // Subtle skin micro-pore noise
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const noise = (Math.random() - 0.5) * 12;
      data[i] = Math.min(255, Math.max(0, data[i] + noise));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise));
    }
    ctx.putImageData(imgData, 0, 0);

    // Realistic Eyes (Left & Right)
    const drawEye = (cx: number, cy: number, flip: boolean) => {
      // Eye socket shadow
      ctx.fillStyle = 'rgba(75, 45, 25, 0.35)';
      ctx.beginPath();
      ctx.ellipse(cx, cy - 4, 38, 24, 0, 0, Math.PI * 2);
      ctx.fill();

      // Eyeball (Off-white natural sclera with subtle blood vessel gradient)
      ctx.fillStyle = '#f8f4eb';
      ctx.beginPath();
      ctx.ellipse(cx, cy, 26, 15, 0, 0, Math.PI * 2);
      ctx.fill();

      // Dark brown Iris
      const irisGrad = ctx.createRadialGradient(cx, cy, 2, cx, cy, 11);
      irisGrad.addColorStop(0, '#3e2212');
      irisGrad.addColorStop(0.7, '#24140a');
      irisGrad.addColorStop(1, '#120a05');
      ctx.fillStyle = irisGrad;
      ctx.beginPath();
      ctx.arc(cx, cy, 10, 0, Math.PI * 2);
      ctx.fill();

      // Pupil
      ctx.fillStyle = '#0a0502';
      ctx.beginPath();
      ctx.arc(cx, cy, 4.5, 0, Math.PI * 2);
      ctx.fill();

      // Specular light reflection (Gloss)
      ctx.fillStyle = 'rgba(255, 255, 255, 0.85)';
      ctx.beginPath();
      ctx.arc(cx - 3, cy - 3, 2.5, 0, Math.PI * 2);
      ctx.fill();

      // Upper Eyelid crease and lashes
      ctx.strokeStyle = '#1b110a';
      ctx.lineWidth = 3.5;
      ctx.beginPath();
      ctx.arc(cx, cy - 2, 27, Math.PI * 1.15, Math.PI * 1.85);
      ctx.stroke();

      // Lower lash line
      ctx.strokeStyle = '#5a3820';
      ctx.lineWidth = 1.5;
      ctx.beginPath();
      ctx.arc(cx, cy + 3, 25, Math.PI * 0.15, Math.PI * 0.85);
      ctx.stroke();

      // Realistic Eyebrows
      ctx.strokeStyle = '#1a110a';
      ctx.lineWidth = 4;
      ctx.beginPath();
      ctx.moveTo(cx - (flip ? 32 : -32), cy - 28);
      ctx.quadraticCurveTo(cx, cy - 35, cx + (flip ? 32 : -32), cy - 26);
      ctx.stroke();

      // Individual brow hair strokes
      ctx.lineWidth = 1.5;
      for (let bx = cx - 28; bx <= cx + 28; bx += 4) {
        ctx.beginPath();
        ctx.moveTo(bx, cy - 30);
        ctx.lineTo(bx + (flip ? 3 : -3), cy - 34 - Math.random() * 4);
        ctx.stroke();
      }
    };

    drawEye(185, 210, false);
    drawEye(327, 210, true);

    // Realistic Shaded Nose
    // Nose bridge highlight
    ctx.fillStyle = 'rgba(235, 210, 185, 0.35)';
    ctx.beginPath();
    ctx.moveTo(250, 185);
    ctx.lineTo(262, 185);
    ctx.lineTo(268, 275);
    ctx.lineTo(244, 275);
    ctx.closePath();
    ctx.fill();

    // Nose sides & tip shading
    ctx.fillStyle = 'rgba(100, 60, 35, 0.4)';
    // Left nostril
    ctx.beginPath();
    ctx.ellipse(238, 282, 12, 7, -0.3, 0, Math.PI * 2);
    ctx.fill();
    // Right nostril
    ctx.beginPath();
    ctx.ellipse(274, 282, 12, 7, 0.3, 0, Math.PI * 2);
    ctx.fill();
    // Nostril holes
    ctx.fillStyle = '#1c0f08';
    ctx.beginPath();
    ctx.arc(242, 283, 4, 0, Math.PI * 2);
    ctx.arc(270, 283, 4, 0, Math.PI * 2);
    ctx.fill();

    // Iconic Groomed Pakistani Farmer Mustache (Moochh)
    const stacheGrad = ctx.createLinearGradient(160, 290, 352, 290);
    stacheGrad.addColorStop(0, '#100a06');
    stacheGrad.addColorStop(0.5, '#22150d');
    stacheGrad.addColorStop(1, '#100a06');
    ctx.fillStyle = stacheGrad;

    ctx.beginPath();
    ctx.moveTo(170, 320);
    ctx.bezierCurveTo(200, 290, 240, 292, 256, 302);
    ctx.bezierCurveTo(272, 292, 312, 290, 342, 320);
    ctx.bezierCurveTo(318, 335, 275, 330, 256, 312);
    ctx.bezierCurveTo(237, 330, 194, 335, 170, 320);
    ctx.closePath();
    ctx.fill();

    // Fine hair strokes on mustache
    ctx.strokeStyle = 'rgba(15, 10, 6, 0.8)';
    ctx.lineWidth = 1.2;
    for (let mx = 180; mx <= 330; mx += 3) {
      const my = 296 + Math.abs(mx - 256) * 0.15;
      ctx.beginPath();
      ctx.moveTo(mx, my);
      ctx.lineTo(mx + (mx > 256 ? 5 : -5), my + 14);
      ctx.stroke();
    }

    // Natural Lower Lip
    ctx.fillStyle = '#9e5a4e';
    ctx.beginPath();
    ctx.ellipse(256, 336, 28, 10, 0, 0, Math.PI * 2);
    ctx.fill();

    // Natural Stubble / Light Beard along jawline
    ctx.fillStyle = 'rgba(25, 18, 12, 0.45)';
    for (let j = 0; j < 800; j++) {
      const jx = 140 + Math.random() * 232;
      const jy = 340 + Math.random() * 140;
      if (Math.hypot(jx - 256, jy - 340) > 40) {
        ctx.fillRect(jx, jy, 1.5, 2.5);
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    this.cache.set('human_face', texture);
    return texture;
  }

  /**
   * 13. Realistic Cotton / Linen Kurta Kameez Fabric Texture
   */
  public static getKurtaFabricTexture(baseColorHex: string = '#2563eb'): THREE.CanvasTexture {
    const key = `kurta_${baseColorHex}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = baseColorHex;
    ctx.fillRect(0, 0, 256, 256);

    // Micro fabric weave
    ctx.strokeStyle = 'rgba(255, 255, 255, 0.08)';
    ctx.lineWidth = 1;
    for (let x = 0; x < 256; x += 3) {
      ctx.beginPath();
      ctx.moveTo(x, 0);
      ctx.lineTo(x, 256);
      ctx.stroke();
    }
    for (let y = 0; y < 256; y += 3) {
      ctx.beginPath();
      ctx.moveTo(0, y);
      ctx.lineTo(256, y);
      ctx.stroke();
    }

    // Subtle cloth wrinkles / folds
    ctx.fillStyle = 'rgba(0, 0, 0, 0.1)';
    for (let i = 0; i < 6; i++) {
      ctx.beginPath();
      ctx.ellipse(40 + i * 35, 128, 12, 120, 0.2, 0, Math.PI * 2);
      ctx.fill();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(2, 2);
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 14. Realistic Pakistani Turban (Pagri) Cloth Texture
   */
  public static getPagriFabricTexture(colorHex: string = '#047857'): THREE.CanvasTexture {
    const key = `pagri_${colorHex}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = colorHex;
    ctx.fillRect(0, 0, 256, 256);

    // Overlapping cloth wrap bands
    for (let y = 0; y < 256; y += 32) {
      ctx.fillStyle = 'rgba(0, 0, 0, 0.12)';
      ctx.fillRect(0, y, 256, 6);
      ctx.fillStyle = 'rgba(255, 255, 255, 0.12)';
      ctx.fillRect(0, y + 6, 256, 3);
    }

    // Golden Gota / Thread edge border
    ctx.fillStyle = '#f59e0b';
    ctx.fillRect(0, 246, 256, 10);
    ctx.fillStyle = '#fbbf24';
    for (let x = 0; x < 256; x += 12) {
      ctx.fillRect(x, 248, 6, 6);
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 15. Machinery Brand Decal Badges (MF 385, New Holland 640, Belarus, John Deere, Sonalika)
   */
  public static getBrandBadgeTexture(type: 'mf385' | 'nh640' | 'belarus' | 'jd' | 'sonalika' | 'rotavator'): THREE.CanvasTexture {
    const key = `badge_${type}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 128;
    const ctx = canvas.getContext('2d')!;

    if (type === 'mf385') {
      // Massey Ferguson 385 Badge
      ctx.fillStyle = '#1e293b';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#dc2626';
      ctx.fillRect(8, 8, 496, 112);

      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 36px Arial, sans-serif';
      ctx.fillText('MASSEY FERGUSON', 20, 60);

      ctx.fillStyle = '#fef08a';
      ctx.font = 'black 54px Impact, Arial, sans-serif';
      ctx.fillText('385', 400, 78);
    } else if (type === 'nh640') {
      // New Holland 640 / Al-Ghazi
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(16, 16, 480, 96);

      ctx.fillStyle = '#1d4ed8';
      ctx.font = 'bold 38px Arial, sans-serif';
      ctx.fillText('NEW HOLLAND', 28, 62);

      ctx.fillStyle = '#ea580c';
      ctx.font = 'black 52px Impact, sans-serif';
      ctx.fillText('640', 390, 78);
    } else if (type === 'belarus') {
      // Belarus 820
      ctx.fillStyle = '#991b1b';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#fef08a';
      ctx.font = 'bold 44px Impact, Arial, sans-serif';
      ctx.fillText('BELARUS 820', 100, 76);
    } else if (type === 'jd') {
      // John Deere
      ctx.fillStyle = '#15803d';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#facc15';
      ctx.font = 'bold 42px Arial, sans-serif';
      ctx.fillText('JOHN DEERE 6M', 70, 74);
    } else if (type === 'sonalika') {
      // Sonalika Cultivator / Tiller
      ctx.fillStyle = '#1d4ed8';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#ffffff';
      ctx.fillRect(10, 10, 492, 108);
      ctx.fillStyle = '#15803d';
      ctx.font = 'bold 48px Arial, sans-serif';
      ctx.fillText('SONALIKA TILLER', 45, 78);
    } else {
      // Rotavator
      ctx.fillStyle = '#ea580c';
      ctx.fillRect(0, 0, 512, 128);
      ctx.fillStyle = '#ffffff';
      ctx.font = 'bold 42px Arial, sans-serif';
      ctx.fillText('ROTAVATOR HEAVY', 50, 76);
    }

    const texture = new THREE.CanvasTexture(canvas);
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 16. Natural Cattle Leather & Fur Texture (Sahiwal Red Zebu, Nili-Ravi Buffalo, Desi Goat)
   */
  public static getCattleSkinTexture(type: 'sahiwal' | 'buffalo' | 'goat'): THREE.CanvasTexture {
    const key = `cattle_${type}`;
    if (this.cache.has(key)) return this.cache.get(key)!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    if (type === 'sahiwal') {
      // Warm rich reddish-chestnut coat with soft gradient and hair follicle noise
      const grad = ctx.createLinearGradient(0, 0, 0, 512);
      grad.addColorStop(0, '#8c3518');
      grad.addColorStop(0.6, '#9b4221');
      grad.addColorStop(1, '#662610');
      ctx.fillStyle = grad;
      ctx.fillRect(0, 0, 512, 512);

      // Fine hair grain
      const imgData = ctx.getImageData(0, 0, 512, 512);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 22;
        data[i] = Math.min(255, Math.max(0, data[i] + noise));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise * 0.7));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise * 0.5));
      }
      ctx.putImageData(imgData, 0, 0);

      // Soft cream-colored belly patch & dewlap highlights
      ctx.fillStyle = 'rgba(235, 205, 175, 0.18)';
      ctx.beginPath();
      ctx.ellipse(256, 420, 180, 70, 0, 0, Math.PI * 2);
      ctx.fill();
    } else if (type === 'buffalo') {
      // Dark slate charcoal hide with subtle wet skin sheen & dried mud splatters
      ctx.fillStyle = '#1c1f24';
      ctx.fillRect(0, 0, 512, 512);

      const imgData = ctx.getImageData(0, 0, 512, 512);
      const data = imgData.data;
      for (let i = 0; i < data.length; i += 4) {
        const noise = (Math.random() - 0.5) * 16;
        data[i] = Math.min(255, Math.max(0, data[i] + noise));
        data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + noise));
        data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + noise * 1.2));
      }
      ctx.putImageData(imgData, 0, 0);

      // Dried alluvial mud splatters from wallowing in ponds
      ctx.fillStyle = 'rgba(92, 65, 42, 0.28)';
      for (let m = 0; m < 45; m++) {
        const mx = Math.random() * 512;
        const my = 200 + Math.random() * 312;
        const mr = 4 + Math.random() * 18;
        ctx.beginPath();
        ctx.arc(mx, my, mr, 0, Math.PI * 2);
        ctx.fill();
      }
    } else {
      // Desi Goat (Spotted black and cream Kamori / Beetal)
      ctx.fillStyle = '#dfd7c5';
      ctx.fillRect(0, 0, 512, 512);
      ctx.fillStyle = '#261b14';
      for (let s = 0; s < 12; s++) {
        ctx.beginPath();
        ctx.ellipse(Math.random() * 512, Math.random() * 512, 30 + Math.random() * 60, 20 + Math.random() * 40, Math.random(), 0, Math.PI * 2);
        ctx.fill();
      }
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    this.cache.set(key, texture);
    return texture;
  }

  /**
   * 17. Dynamic Water Caustics & Ripple Texture
   */
  public static getWaterCausticsTexture(): THREE.CanvasTexture {
    if (this.cache.has('water_caustics')) return this.cache.get('water_caustics')!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    ctx.fillStyle = '#0284c7';
    ctx.fillRect(0, 0, 256, 256);

    // Voronoi-like caustic light webbing
    ctx.strokeStyle = 'rgba(224, 242, 254, 0.55)';
    ctx.lineWidth = 3;
    for (let i = 0; i < 30; i++) {
      ctx.beginPath();
      const x1 = Math.random() * 256;
      const y1 = Math.random() * 256;
      const x2 = x1 + (Math.random() - 0.5) * 80;
      const y2 = y1 + (Math.random() - 0.5) * 80;
      const cpX = (x1 + x2) / 2 + (Math.random() - 0.5) * 40;
      const cpY = (y1 + y2) / 2 + (Math.random() - 0.5) * 40;
      ctx.moveTo(x1, y1);
      ctx.quadraticCurveTo(cpX, cpY, x2, y2);
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(4, 4);
    this.cache.set('water_caustics', texture);
    return texture;
  }

  /**
   * 18. Weathered Asphalt Highway & Village Road with cracks & aggregate stones
   */
  public static getRealAsphaltTexture(): THREE.CanvasTexture {
    if (this.cache.has('real_asphalt')) return this.cache.get('real_asphalt')!;

    const canvas = document.createElement('canvas');
    canvas.width = 512;
    canvas.height = 512;
    const ctx = canvas.getContext('2d')!;

    // Dark grey sun-baked bituminous tar
    ctx.fillStyle = '#2b2e33';
    ctx.fillRect(0, 0, 512, 512);

    // Micro mineral aggregate
    const imgData = ctx.getImageData(0, 0, 512, 512);
    const data = imgData.data;
    for (let i = 0; i < data.length; i += 4) {
      const stoneNoise = (Math.random() - 0.5) * 35;
      data[i] = Math.min(255, Math.max(0, data[i] + stoneNoise));
      data[i + 1] = Math.min(255, Math.max(0, data[i + 1] + stoneNoise));
      data[i + 2] = Math.min(255, Math.max(0, data[i + 2] + stoneNoise));
    }
    ctx.putImageData(imgData, 0, 0);

    // Faded white central divider line
    ctx.fillStyle = 'rgba(230, 230, 220, 0.65)';
    ctx.fillRect(246, 0, 20, 512);

    // Fine asphalt cracks
    ctx.strokeStyle = 'rgba(15, 15, 18, 0.7)';
    ctx.lineWidth = 1.8;
    for (let c = 0; c < 12; c++) {
      let cx = Math.random() * 512;
      let cy = Math.random() * 512;
      ctx.beginPath();
      ctx.moveTo(cx, cy);
      for (let seg = 0; seg < 5; seg++) {
        cx += (Math.random() - 0.5) * 35;
        cy += 15 + Math.random() * 25;
        ctx.lineTo(cx, cy);
      }
      ctx.stroke();
    }

    const texture = new THREE.CanvasTexture(canvas);
    texture.wrapS = THREE.RepeatWrapping;
    texture.wrapT = THREE.RepeatWrapping;
    texture.repeat.set(1, 14);
    this.cache.set('real_asphalt', texture);
    return texture;
  }

  /**
   * 19. Natural Atmospheric Soft Cloud Texture
   */
  public static getCloudTexture(): THREE.CanvasTexture {
    if (this.cache.has('cloud')) return this.cache.get('cloud')!;

    const canvas = document.createElement('canvas');
    canvas.width = 256;
    canvas.height = 256;
    const ctx = canvas.getContext('2d')!;

    // Radial puff gradient
    const grad = ctx.createRadialGradient(128, 128, 10, 128, 128, 120);
    grad.addColorStop(0, 'rgba(255, 255, 255, 0.95)');
    grad.addColorStop(0.5, 'rgba(255, 250, 240, 0.6)');
    grad.addColorStop(0.8, 'rgba(245, 240, 230, 0.2)');
    grad.addColorStop(1, 'rgba(255, 255, 255, 0)');

    ctx.fillStyle = grad;
    ctx.fillRect(0, 0, 256, 256);

    const texture = new THREE.CanvasTexture(canvas);
    this.cache.set('cloud', texture);
    return texture;
  }
}
